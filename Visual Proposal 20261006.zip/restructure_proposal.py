from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUTPUT_PATH = Path(__file__).with_name("proposal_template_restructured.docx")
NAVY = "17365D"
BLUE = "D9EAF7"
LIGHT_BLUE = "EEF5FA"
LIGHT_GRAY = "F2F2F2"
WHITE = "FFFFFF"


def set_cell_shading(cell, fill):
    properties = cell._tc.get_or_add_tcPr()
    shading = properties.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        properties.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    properties = cell._tc.get_or_add_tcPr()
    margins = properties.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        properties.append(margins)
    for margin_name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        margin = margins.find(qn(f"w:{margin_name}"))
        if margin is None:
            margin = OxmlElement(f"w:{margin_name}")
            margins.append(margin)
        margin.set(qn("w:w"), str(value))
        margin.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    properties = row._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    properties.append(repeat)


def set_paragraph_spacing(paragraph, before=0, after=3, line=1.0):
    formatting = paragraph.paragraph_format
    formatting.space_before = Pt(before)
    formatting.space_after = Pt(after)
    formatting.line_spacing = line


def add_text(paragraph, text, bold=False, italic=False, color=None, size=12):
    run = paragraph.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run


def add_paragraph(document, text="", style=None, bold=False, italic=False, color=None, after=3):
    paragraph = document.add_paragraph(style=style)
    set_paragraph_spacing(paragraph, after=after)
    add_text(paragraph, text, bold=bold, italic=italic, color=color)
    return paragraph


def add_bullet(document, text, level=0):
    style = "List Bullet" if level == 0 else "List Bullet 2"
    paragraph = add_paragraph(document, text, style=style, after=2)
    paragraph.paragraph_format.left_indent = Inches(0.25 + level * 0.2)
    paragraph.paragraph_format.first_line_indent = Inches(-0.15)
    return paragraph


def add_numbered(document, text):
    paragraph = add_paragraph(document, text, style="List Number", after=2)
    paragraph.paragraph_format.left_indent = Inches(0.25)
    paragraph.paragraph_format.first_line_indent = Inches(-0.15)
    return paragraph


def add_section_heading(document, text, level=1):
    paragraph = document.add_paragraph()
    set_paragraph_spacing(paragraph, before=7 if level == 1 else 5, after=4)
    size = 16 if level == 1 else 13
    add_text(paragraph, text, bold=True, color=NAVY, size=size)
    paragraph.paragraph_format.keep_with_next = True
    return paragraph


def add_section_message(document, text):
    table = document.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    cell = table.cell(0, 0)
    set_cell_shading(cell, LIGHT_BLUE)
    set_cell_margins(cell, top=80, bottom=80)
    paragraph = cell.paragraphs[0]
    set_paragraph_spacing(paragraph, after=0)
    add_text(paragraph, "Section purpose: ", bold=True, color=NAVY)
    add_text(paragraph, text)
    return table


def add_guidance(document, text):
    table = document.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_shading(cell, LIGHT_GRAY)
    set_cell_margins(cell, top=70, bottom=70)
    paragraph = cell.paragraphs[0]
    set_paragraph_spacing(paragraph, after=0)
    add_text(paragraph, "Template guidance retained: ", bold=True, italic=True)
    add_text(paragraph, text, italic=True)
    return table


def add_table(document, headers, rows, widths=None):
    table = document.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    header = table.rows[0]
    set_repeat_table_header(header)
    for index, text in enumerate(headers):
        cell = header.cells[index]
        set_cell_shading(cell, NAVY)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        paragraph = cell.paragraphs[0]
        set_paragraph_spacing(paragraph, after=0)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_text(paragraph, text, bold=True, color=WHITE)
        if widths:
            cell.width = Inches(widths[index])
    for row_values in rows:
        row = table.add_row()
        for index, value in enumerate(row_values):
            cell = row.cells[index]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            paragraph = cell.paragraphs[0]
            set_paragraph_spacing(paragraph, after=0)
            add_text(paragraph, value)
            if widths:
                cell.width = Inches(widths[index])
    document.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_part_banner(document, title):
    table = document.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_shading(cell, NAVY)
    set_cell_margins(cell, top=110, bottom=110)
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(paragraph, after=0)
    add_text(paragraph, title, bold=True, color=WHITE, size=16)


def add_page_break(document):
    paragraph = document.add_paragraph()
    paragraph.add_run().add_break(WD_BREAK.PAGE)


def configure_document(document):
    section = document.sections[0]
    section.top_margin = Inches(0.55)
    section.bottom_margin = Inches(0.55)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)
    section.header_distance = Inches(0.25)
    section.footer_distance = Inches(0.25)

    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(12)
    normal.paragraph_format.space_after = Pt(3)
    normal.paragraph_format.line_spacing = 1.0

    for style_name in ("List Bullet", "List Bullet 2", "List Number"):
        style = styles[style_name]
        style.font.name = "Times New Roman"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        style.font.size = Pt(12)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_text(footer, "COMP7507 Project Proposal", color=NAVY, size=9)


def build_document():
    document = Document()
    configure_document(document)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(title, before=4, after=2)
    add_text(title, "COMP7507 Visualization and Visual Analytics", bold=True, color=NAVY, size=18)
    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(subtitle, after=8)
    add_text(subtitle, "Project Proposal", bold=True, color=NAVY, size=20)

    add_section_heading(document, "Important Notes", level=2)
    add_numbered(document, "The purpose of the proposal is to define the project scope and consolidate the group’s ideas. The group should investigate the feasibility of its plans and identify viable data sources early to reduce unnecessary data cleaning and processing.")
    add_numbered(document, "One proposal must be submitted for each group using this template. All group input should be in 12-point Times New Roman, black/automatic font. Part B must not exceed five pages.")
    add_numbered(document, "The teaching team will provide feedback within one week after submission. The group should continue working on the project after submission rather than wait for feedback before progressing.")

    add_section_heading(document, "Document Structure", level=2)
    add_paragraph(document, "The proposal is organized into four parts: basic information, proposed method, task planning, and references. Each part begins with a short purpose statement so readers can quickly understand what the section contains.")

    add_part_banner(document, "Part A — Basic Information")
    add_section_message(document, "Identify the group, its members, and the working project title.")
    add_table(document, ["Item", "Details"], [
        ("Group number", "1"),
        ("Project title", "The Situation of Public Resources across Different Districts in Hong Kong"),
        ("Original title wording (retained)", "The situation of the resource on different districts in Hong Kong"),
    ], widths=(1.6, 5.7))
    add_table(document, ["Name", "Student ID"], [
        ("Kwok Wai Lok", "3036372710"),
        ("Ng Chi Kin", "3036791631"),
        ("Wang Man Kit", "3036064569"),
        ("Cheung Tin Shing", "3036656893"),
        ("", ""),
    ], widths=(3.6, 3.6))

    add_page_break(document)
    add_part_banner(document, "Part B — Proposed Method (Maximum 5 Pages)")
    add_section_message(document, "Define the project’s analytical question, document the data to be used, and explain how the visual analysis will be carried out across all resource sectors.")

    add_section_heading(document, "1. Project Objectives", level=1)
    add_guidance(document, "In about 50 words, clearly state the problem to be solved or analyzed with data visualizations, why it is important, and how visualization will support understanding or action.")
    add_paragraph(document, "Using population statistics aligned with Hong Kong’s 18 district boundaries, this project will evaluate the distribution and use of public resources in each district. It will compare intended capacity with actual usage to identify shortages, overload, under-utilization, spatial imbalance, and possible structural issues in public-resource allocation. These patterns may also reflect broader challenges in Hong Kong’s political and administrative design.")

    add_section_heading(document, "2. Dataset Description", level=1)
    add_section_message(document, "Record each sector’s datasets, coverage, source, and intended analytical role. Contributor labels from the working draft are retained to preserve ownership records.")

    add_section_heading(document, "2.1 Hospital Resources", level=2)
    add_paragraph(document, "A broad set of hospital-related data will be used, including annual visits, hospital beds, inpatient usage, waiting times, and hospital and clinic locations. Hospital information comes from the Hospital Authority (ha.org.hk). District population and hospital-location context will be derived from the Census and Statistics Department. The datasets are current and are updated continuously.")

    add_section_heading(document, "2.2 Elderly Services and Community Support — Sam", level=2)
    add_paragraph(document, "The Social Welfare Department datasets cover elderly care and community support in Hong Kong. One dataset provides quarterly figures on residential care homes and the number of places by home type. Two further datasets list District Elderly Community Centres and Neighbourhood Elderly Centres, including names, addresses, and contact information.")
    add_paragraph(document, "Original scope record: elderly services and community support, including community centres and elderly centres.", italic=True)

    add_section_heading(document, "2.3 Public Library Services — Eddie", level=2)
    add_table(document, ["Dataset", "Coverage and source"], [
        ("District-level Library Usage Data (2020–2024)", "https://www.lcsd.gov.hk/en/common/images/en/doc/2025/CSTB324E.pdf"),
        ("LCSD Library Statistics", "Covers 2018–2024. After excluding mobile libraries, self-service stations, and online services, it contains 492 records for 71 historical physical libraries, with no missing or negative borrowing values. https://data.gov.hk/en-data/dataset/hk-lcsd-stats-lib-stats"),
        ("LCSD Library Locations", "Provides library names, locations, and geographic coordinates for Python-based mapping and accessibility analysis. https://data.gov.hk/en-data/dataset/hk-lcsd-csdi-libraries"),
        ("HKPL Library Facilities API", "After removing one test record named ‘Mock Library’, 72 physical libraries remain, with complete district information. https://data.gov.hk/en-data/dataset/hk-lcsd-lib-lib-computers"),
        ("C&SD Population by District", "Annual population and age-group data for all 18 districts, supporting indicators such as borrowing per 10,000 residents. https://data.gov.hk/en-data/dataset/hk-censtatd-tablechart-110-06811"),
        ("2021 Population Census by DCCA", "Covers 452 small areas with demographic, education, employment, and housing variables together with geographic boundaries. https://data.gov.hk/en-data/dataset/hk-censtatd-census_geo-2021-population-census-by-dcca"),
        ("C&SD Household Income", "Supports analysis of associations between income and borrowing intensity. https://data.gov.hk/en-data/dataset/hk-censtatd-tablechart-130-06804"),
    ], widths=(2.2, 5.1))

    add_section_heading(document, "2.4 Public Transport: Bus and MTR — Ryan", level=2)
    add_table(document, ["Dataset", "Source"], [
        ("2021 Population Census: statistics and boundaries of District Council districts", "https://data.gov.hk/tc-data/dataset/hk-censtatd-census_geo-2021-population-census-by-dcd"),
        ("Routes, fares, and usage of MTR and bus services: bus routes and fares", "https://data.gov.hk/tc-data/dataset/hk-td-tis_23-routes-fares-geojson"),
        ("Routes, fares, and usage of MTR and bus services: MTR routes, fares, and barrier-free facilities", "https://data.gov.hk/tc-data/dataset/mtr-data-routes-fares-barrier-free-facilities"),
        ("Routes, fares, and usage of MTR and bus services: Monthly Traffic and Transport Digest", "https://data.gov.hk/tc-data/dataset/hk-td-tis_10-monthly-traffic-and-transport-digest"),
    ], widths=(4.0, 3.3))

    add_section_heading(document, "2.5 Recreation and Sports Facilities — Jacky", level=2)
    add_paragraph(document, "The proposed scope covers recreation resources such as parks and sports facilities. The working draft records ‘five fields respective dataset for each of us’; the exact five datasets and their source links remain to be confirmed before submission.")

    add_section_heading(document, "3. Methodology", level=1)
    add_section_message(document, "Explain how each sector’s data will be cleaned, assigned to districts, normalized by population or demand, and translated into comparable maps, charts, and dashboard views.")

    add_section_heading(document, "3.1 Shared Analytical Framework", level=2)
    add_bullet(document, "Assign facilities and services to Hong Kong’s 18 districts using locations and district boundaries.")
    add_bullet(document, "Group comparable facility types within each district so cross-district comparisons use a common basis.")
    add_bullet(document, "Combine capacity or quota, district population, actual usage, accessibility, and waiting-time indicators.")
    add_bullet(document, "Identify under-utilized facilities, overloaded facilities, underserved districts, and supply–demand mismatches.")
    add_bullet(document, "Develop each field’s methodology first, then combine the results into one report and one integrated dashboard.")

    add_section_heading(document, "3.2 Hospital Resources", level=2)
    add_paragraph(document, "Facilities will be assigned to one of the 18 districts according to location rather than Hospital Authority clusters. Because districts may contain different facility types and quantities, facilities will be grouped into comparable categories. Daily use, number of visits, average waiting time, quota, district population, and intended usage will be combined to determine whether facilities are below intended use or overloaded.")

    add_section_heading(document, "3.3 Elderly Services and Community Support — Sam", level=2)
    add_paragraph(document, "Python and Pandas will assign each centre to one of the 18 districts by location and group elderly services centres and community centres for comparison. The analysis will assess whether community-centre supply is sufficient for residents aged 65 and over and will show the ageing-population trend.")
    add_bullet(document, "Choropleth map of population aged 65 and over, overlaid with elderly services centres and community centres.")
    add_bullet(document, "Bar charts comparing each district’s older population with the number of centres in each group.")
    add_bullet(document, "Rate chart of older residents per centre to identify districts relatively short of centres.")
    add_bullet(document, "Time series of the ageing population by district.")
    add_paragraph(document, "Matplotlib, Seaborn, Plotly, and Folium will support visualization. The output will be an interactive Python dashboard in Streamlit or Dash.")

    add_section_heading(document, "3.4 Public Library Services — Eddie", level=2)
    add_paragraph(document, "The library analysis will examine the spatial equity and supply–demand mismatch of public library services in Hong Kong. Python will support both processing and visualization, using Matplotlib, Seaborn, Plotly, GeoPandas, and Folium.")
    add_bullet(document, "Use time-series charts and district maps to compare attendance, borrowing, and post-pandemic recovery from 2020 to 2024.")
    add_bullet(document, "Map library locations, numbers, opening hours, and service coverage to identify limited provision or poor spatial accessibility.")
    add_bullet(document, "Use choropleth maps to show population, age structure, household income, and other demographic factors associated with demand.")
    add_bullet(document, "Create supply–demand quadrant charts, utilization-gap maps, and interactive district comparisons.")
    add_paragraph(document, "The final output will visualize library supply–demand mismatches. Interactive maps will show locations, accessibility, community demand, and utilization pressure; Plotly quadrant charts will compare demand and supply; and time-series charts will show changes in district attendance and borrowing to identify underserved, over-pressured, and under-utilized areas.")

    add_section_heading(document, "3.5 Public Transport — Ryan", level=2)
    add_paragraph(document, "Geographical mapping will show the distribution of MTR stations and bus routes. Interactive graphs will present per-capita transport allocations from several perspectives:")
    add_bullet(document, "Per-capita allocation: the number of residents sharing one MTR station or bus route in each district.")
    add_bullet(document, "Comparative analysis: total MTR stations and bus routes across districts.")
    add_bullet(document, "Socioeconomic correlation: relationships between transport availability and district population, average salaries, and employment status.")

    add_section_heading(document, "3.6 Recreation and Sports Facilities — Jacky", level=2)
    add_paragraph(document, "Python heatmaps, choropleth maps, charts, and plots will be used to analyze usage pressure, facility counts by district, accessibility, and age-related needs or issues.")

    add_page_break(document)
    add_part_banner(document, "Part C — List of Tasks")
    add_section_message(document, "Turn the proposed analysis into an actionable schedule by recording responsibilities, milestone dates, integration work, and final deliverables.")

    add_section_heading(document, "1. Division of Labour", level=1)
    add_table(document, ["Recorded owner", "Responsibility"], [
        ("Matthew", "Hospital sector"),
        ("Sam", "Elderly services and community support sector"),
        ("Eddie", "Library sector"),
        ("Jacky", "Recreation and sports facilities sector"),
    ], widths=(2.0, 5.3))
    add_paragraph(document, "Additional ownership record retained from Part B: Ryan is named as responsible for public transport (bus and MTR). Confirm whether Ryan is an additional member or a nickname corresponding to one of the four listed group members before submission.", italic=True)

    add_section_heading(document, "2. Timeline", level=1)
    add_table(document, ["Date", "Milestone"], [
        ("23/9", "First meeting: clarify the project objective and research the Hong Kong Government datasets that define the project scope."),
        ("30/9", "Finish the dataset description and methodology for each sector; discuss the results and begin the project proposal."),
        ("5/10", "Finish individual parts of the proposal."),
        ("10/10", "Unify all individual parts into one report."),
        ("17/10", "Each member finishes a preliminary dashboard; hold a meeting to discuss how to combine the dashboards."),
        ("24/10", "Finish the combined-dashboard design."),
        ("7/11", "Finish development of the combined dashboard."),
        ("14/11", "Finalize the dashboard."),
        ("21/11", "Finish demo preparation."),
        ("30/11", "Finish the group report."),
    ], widths=(1.1, 6.2))

    add_section_heading(document, "3. Actionable Task Sequence", level=1)
    add_table(document, ["Stage", "Task", "Primary responsibility"], [
        ("1", "Confirm sector scope, datasets, source links, and district-boundary compatibility.", "All members; sector owners lead"),
        ("2", "Clean and validate sector data; remove test or non-comparable records where documented.", "Each sector owner"),
        ("3", "Geocode facilities and assign records to the 18 districts.", "Each sector owner"),
        ("4", "Calculate comparable population, capacity, usage, accessibility, waiting-time, and supply–demand indicators.", "Each sector owner"),
        ("5", "Build preliminary sector visualizations and dashboards.", "Each sector owner"),
        ("6", "Agree on shared visual encodings, filters, district definitions, and dashboard layout.", "Whole group"),
        ("7", "Integrate, test, and finalize the combined dashboard.", "Whole group"),
        ("8", "Prepare the demonstration and complete the group report.", "Whole group"),
    ], widths=(0.6, 4.6, 2.1))
    add_guidance(document, "Provide a detailed plan containing (1) a list of specific, actionable tasks, (2) a reasonable duration for each task in days or weeks, and (3) the group member or members responsible. A Gantt chart or table format may be used.")

    add_page_break(document)
    add_part_banner(document, "Part D — References")
    add_section_message(document, "Consolidate every cited dataset and source in a consistent academic style so the analysis can be traced and reproduced.")
    add_guidance(document, "Put references in academic style here.")

    add_section_heading(document, "Hospital Authority Datasets", level=1)
    hospital_references = [
        "Hospital Authority. (n.d.). Primary care attendances [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/pc-attnd-en.json",
        "Hospital Authority. (n.d.). Specialist outpatient attendances [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/sop-attnd-en.json",
        "Hospital Authority. (n.d.). Accident and emergency attendances [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/ae-attnd-en.json",
        "Hospital Authority. (n.d.). Number of patient days by cluster/hospital [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/patientday-en.json",
        "Hospital Authority. (n.d.). Number of hospital beds by specialty and cluster/hospital [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/hosp-bed-en.json",
        "Hospital Authority. (n.d.). Family medicine clinic locations [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/facility-fmc.json",
        "Hospital Authority. (n.d.). Hospital locations [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/facility-hosp.json",
        "Hospital Authority. (n.d.). Specialist outpatient clinic locations [Data set]. Hong Kong Hospital Authority Open Data. Retrieved October 1, 2026, from https://www.ha.org.hk/opendata/facility-sop.json",
    ]
    for reference in hospital_references:
        add_paragraph(document, reference, after=4)

    add_section_heading(document, "Library and Demographic Dataset Links", level=1)
    for reference in [
        "Leisure and Cultural Services Department. (2025). District-level library usage data, 2020–2024. https://www.lcsd.gov.hk/en/common/images/en/doc/2025/CSTB324E.pdf",
        "Leisure and Cultural Services Department. (n.d.). LCSD library statistics [Data set]. https://data.gov.hk/en-data/dataset/hk-lcsd-stats-lib-stats",
        "Leisure and Cultural Services Department. (n.d.). LCSD library locations [Data set]. https://data.gov.hk/en-data/dataset/hk-lcsd-csdi-libraries",
        "Hong Kong Public Libraries. (n.d.). Library facilities API [Data set]. https://data.gov.hk/en-data/dataset/hk-lcsd-lib-lib-computers",
        "Census and Statistics Department. (n.d.). Population by district [Data set]. https://data.gov.hk/en-data/dataset/hk-censtatd-tablechart-110-06811",
        "Census and Statistics Department. (2021). Population Census by DCCA [Data set]. https://data.gov.hk/en-data/dataset/hk-censtatd-census_geo-2021-population-census-by-dcca",
        "Census and Statistics Department. (n.d.). Household income [Data set]. https://data.gov.hk/en-data/dataset/hk-censtatd-tablechart-130-06804",
    ]:
        add_paragraph(document, reference, after=4)

    add_section_heading(document, "Public Transport and District-Boundary Dataset Links", level=1)
    for reference in [
        "Census and Statistics Department. (2021). Population Census: statistics and boundaries of District Council districts [Data set]. https://data.gov.hk/tc-data/dataset/hk-censtatd-census_geo-2021-population-census-by-dcd",
        "Transport Department. (n.d.). Routes and fares in GeoJSON format [Data set]. https://data.gov.hk/tc-data/dataset/hk-td-tis_23-routes-fares-geojson",
        "MTR Corporation. (n.d.). MTR routes, fares, and barrier-free facilities [Data set]. https://data.gov.hk/tc-data/dataset/mtr-data-routes-fares-barrier-free-facilities",
        "Transport Department. (n.d.). Monthly Traffic and Transport Digest [Data set]. https://data.gov.hk/tc-data/dataset/hk-td-tis_10-monthly-traffic-and-transport-digest",
    ]:
        add_paragraph(document, reference, after=4)

    add_section_heading(document, "References Still to Be Completed", level=1)
    add_bullet(document, "Social Welfare Department source links for residential care homes, District Elderly Community Centres, and Neighbourhood Elderly Centres were described but not recorded in the original proposal.")
    add_bullet(document, "Recreation and sports facility dataset names and source links were not recorded in the original proposal.")

    document.core_properties.title = "COMP7507 Project Proposal — Restructured"
    document.core_properties.subject = "Distribution and usage of public resources across Hong Kong districts"
    document.core_properties.author = "Group 1"
    document.core_properties.comments = "Restructured from proposal_template.docx without removing source records."
    document.save(OUTPUT_PATH)
    return OUTPUT_PATH


if __name__ == "__main__":
    print(build_document())