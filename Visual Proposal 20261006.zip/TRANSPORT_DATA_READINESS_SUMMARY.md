# Hong Kong Public Transport Analysis: Data Readiness Summary

## Project goal

Visualize the distribution of MTR stations and bus routes across Hong Kong, then produce interactive district-level analyses covering:

- public-transport allocation per capita;
- comparisons of MTR stations and bus routes across districts; and
- relationships between transport availability and population, income, and employment indicators.

## Current data inventory

| File | Contents | Assessment |
|---|---|---|
| [Hong Kong Districts Data.CSV](./Hong%20Kong%20Districts%20Data.CSV) | District-level 2021 census and socioeconomic indicators | Suitable for population and socioeconomic analysis |
| [Hong Kong Bus.json](./Hong%20Kong%20Bus.json) | Bus-stop point features and route-stop records | Suitable for bus-stop mapping and district allocation |
| [HK Bus GeoJson.geojson](./HK%20Bus%20GeoJson.geojson) | Bus-route line geometry | Suitable for offline processing; too large for direct browser use |
| [Hong Kong MTR.csv](./Hong%20Kong%20MTR.csv) | MTR lines, stations, directions, and sequences | Useful as a network inventory, but not a geographic dataset |
| [hksar_18_district_boundary.gml](./hksar_18_district_boundary.gml) | Hong Kong's 18 District Council boundary polygons | Suitable for district maps and spatial joins |

## Validated data findings

### District socioeconomic data

The district CSV contains the 18 District Council districts plus a `Land total` aggregate. Exclude `Land total` from district comparisons.

The usable district-level indicators include:

- total population;
- labour force;
- working population;
- employment-status breakdowns;
- median monthly income from main employment; and
- median monthly income for economically active domestic households.

The source is the 2021 Population Census. The file provides median income rather than average salary. Use the term **median monthly employment income** in visualizations and documentation.

Unemployment can be derived as:

```text
unemployed population = labour force - working population
```

This should be clearly labelled as a derived measure.

### Bus data

`Hong Kong Bus.json` contains:

- 56,209 route-stop records;
- 4,488 unique stop IDs;
- 1,622 service route IDs;
- 1,025 public-facing route names;
- point coordinates;
- operator, route, stop, fare, service-mode, and update-date fields.

The bus points use standard GeoJSON coordinate order:

```text
longitude, latitude
```

The dataset's `district` property is blank for all records. This is no longer a blocker because district membership can be derived through a spatial join against the district boundary polygons.

### Bus-route geometry

`HK Bus GeoJson.geojson` contains 2,246 route-line features and is approximately 1.5 GB. It has route IDs, operators, route endpoint details, and line geometry.

Do not load this raw file directly into a browser map. Preprocess it by simplifying geometry, filtering to selected routes, creating vector tiles, or calculating district-level aggregate measures offline.

### MTR data

`Hong Kong MTR.csv` contains:

- 100 unique station IDs;
- 97 unique English station names;
- 10 MTR lines; and
- line-direction station sequences.

It does not contain station coordinates, location geometry, addresses, or district identifiers. It supports an MTR network/sequence diagram but cannot independently support a geographic MTR map or station counts by district.

### District boundary data

`hksar_18_district_boundary.gml` contains:

- exactly 18 district polygon features;
- English and Chinese district names;
- a district code; and
- WGS 84 coordinates declared as `EPSG:4326`.

Its 18 district names match the 18 district names in the census file after removing the ` District` suffix from the boundary layer names. No manual district name mapping is required.

The GML coordinate values use the GML axis convention:

```text
latitude, longitude
```

GeoJSON and most web-map libraries expect:

```text
longitude, latitude
```

Confirm axis handling when loading or converting the GML. If a converted polygon layer appears in the wrong location, swap the coordinate axes before continuing.

## What is now achievable

With the district boundary GML, bus-stop data, and district census data, the following are achievable:

1. An interactive district map with boundary polygons and bus-stop layers.
2. A spatial join that assigns each bus stop to its containing district.
3. District-level counts of unique bus stops.
4. District-level counts of unique bus services/routes.
5. Per-capita bus availability metrics.
6. District comparison charts and choropleth maps.
7. Descriptive correlations between bus availability and population, employment, or income indicators.

## Recommended metric definitions

Use consistent definitions throughout the project:

| Metric | Definition |
|---|---|
| Bus stops in a district | Count of unique `stopId` point locations within the district polygon |
| Bus routes serving a district | Count of unique `routeId` values with at least one stop within the district polygon |
| Bus stops per 100,000 residents | `unique bus stops / population * 100,000` |
| Bus routes per 100,000 residents | `unique routes / population * 100,000` |
| MTR stations in a district | Count of unique station points within the district polygon, after station coordinates are obtained |
| Derived unemployed population | `labour force - working population` |

Use per 100,000 residents rather than “one route or station per person,” because the measure is clearer and easier to compare between districts.

## Remaining data requirement

To complete the full MTR and bus analysis, obtain a geocoded MTR station dataset containing:

- station coordinates or station point geometry; and
- a reliable station ID or English station name that can be joined to `Hong Kong MTR.csv`.

Once this is available, use the same point-in-polygon spatial join applied to bus stops to assign each MTR station to a district.

## Recommended Python tools

Use:

```text
GeoPandas + Shapely + Folium + Plotly
```

| Library | Use |
|---|---|
| `geopandas` | Read GML/GeoJSON, manage spatial data, and run spatial joins |
| `shapely` | Spatial geometry operations |
| `folium` | Standalone interactive Leaflet HTML maps |
| `plotly` | Interactive comparison and correlation charts |
| `dash` | Optional dashboard application framework |
| `pyogrio` | Faster geospatial file reading where needed |

Recommended processing flow:

```text
District GML boundaries
        +
Bus-stop point GeoJSON
        +
District census data
        |
        v
Spatial join and district aggregation
        |
        v
Per-capita transport indicators
        |
        v
Folium map and Plotly charts
```

For the initial map, use OpenStreetMap as the basemap, district polygons as the boundary layer, and filtered or clustered bus stops. Render full bus-route geometry only after preprocessing or after a user selects a route.

## Analysis limitations

- Census indicators are from 2021, while bus records contain update dates ranging from 2020 to 2026. State this time mismatch in the methodology and visualizations.
- Do not interpret correlations as proof that transport supply causes income or employment outcomes.
- A route serving a district does not necessarily mean all residents have equal access to it. Stop density, walking distance, frequency, service hours, and capacity are not represented by the current metrics.
- MTR station mapping and MTR-based per-capita measures remain unavailable until station coordinates are added.

## Overall readiness

The project is now ready for the **bus-focused** map, per-capita allocation, district comparison, and socioeconomic correlation components.

The project is not yet ready for complete MTR geographic and district-level analysis because the current MTR file has no station coordinates. Adding a geocoded MTR station dataset is the remaining essential data step.
