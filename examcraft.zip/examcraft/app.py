from examcraft.ui.app import main

main()
