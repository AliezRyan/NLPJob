# ExamCraft Agentic Intake and Planning Foundation

A runnable foundation for the Group 7 project, not a finished exam generator.
The proposal and technical specification remain unchanged in the parent folder.
Treat this `examcraft/` directory as the Python project root.

**New installation or unpacked source archive:** follow the
[setup guide](#quick-start-windows-powershell) below. Virtual environments and
generated caches are intentionally not included in the source package.

**System workflow:** [Human, AI and system interactions](SYSTEM_WORKFLOW.md) |
[Offline visual diagrams](SYSTEM_WORKFLOW.html). These distinguish the full target
workflow from the intake and planning foundation that currently runs.

## Review findings and course alignment

The [COMP7608B project guideline](../COMP7608B_LLM_Project_Guideline.pdf) requires a
working, user-oriented agentic system with meaningful decisions, tools/resources,
end-to-end execution, evaluation, runnable code and explained limitations.
Multi-agent collaboration is optional; using LangGraph or naming five agents is
not, by itself, evidence of agentic behavior. Final evaluation/report details remain TBA.

The proposal and [technical specification](../ExamCraft%20Tech%20Spec.html) remain
the product scope. The following findings distinguish implemented foundations
from unfinished requirements:

| Review finding | Current status | Remaining work |
| --- | --- | --- |
| Fixed pipeline with no feedback-driven decisions | Replaced by a bounded `retrieve` / `draft` / `stop` planning loop | Grounded Writers, independent Critic and question repair/replanning |
| Collection and processing AI were hidden in the overview | Explicit bounded Source Collector and Document Processor roles now run before source review | Live HKU navigation/download design after approved entry URLs are supplied; authentication deferred |
| Planner only saw document beginnings | Selected-source keyword retrieval can search all extracted pages; overview is an explicit tool action | Better chunk boundaries, retrieval evaluation, optional BM25/dense retrieval |
| Schemas only represented a blueprint | Typed planning decisions, evidence, feedback and trace events added | Versioned question, critique, exam, approval and practice contracts |
| Partially extracted PDFs appeared usable without warning | Low-text page warnings are recorded and shown in review | OCR/layout handling and stronger extraction-quality checks |
| Tests were mistaken for quality evaluation | Software regression tests remain separate from the planned experiments | Held-out cases, baselines, instructor labels, quality/latency/cost metrics |
| Lifecycle and budgets were incomplete | All model roles share consent, HTTP-attempt and token accounting; stage limits and private traces remain | Currency budgets, end-to-end deadlines, richer structured errors and TTL cleanup |

These choices reflect [Lecture 4](../COMP7608B_Lec04.pdf) on the agent/harness loop,
[Lecture 5](../COMP7608B_Lec05.pdf) on context and tool execution,
[Lecture 6](../COMP7608B_Lecture_06.pdf) on scoped memory and evidence retrieval,
and [Lecture 3](../Lecture_3_Training_and_Learning.pdf) on held-out evaluation and
verifier limitations. Fine-tuning, MCP, GraphRAG, permanent memory and a database
are not prerequisites for this project.

**Start here for the detailed development roadmap: [Implementation plan](plan.md).**
It contains 12 dependency-ordered steps, 36 actionable tasks, acceptance criteria,
suggested workstream owners and local requirement-to-task mappings. Planned work
is not described as implemented.

## What works

- Streamlit: queued manual upload, optional HKU source requests, early intake consent,
  processing warnings/proposed metadata, source review, draft blueprint and reset.
- LangGraph: HKU-only collection and tool-directed document processing nodes before
  the material-review interrupt, model-directed evidence retrieval, deterministic
  draft gates, bounded feedback/replanning, explicit stop routes, parallel Writer
  handoffs and a join before the placeholder Critic.
- Source Collector: chooses a configured requested HKU ExamBase/Moodle connector,
  observes outcomes and finishes within fixed limits. Missing URLs return upload fallback.
- Document Processor: chooses an approved PDF/TXT parser, inspects extracted evidence,
  then proposes structured metadata. OCR requests receive an explicit unavailable observation.
- OpenRouter: collection, processing and planning use one consented provider client
  and shared request/token ledger. The Planner still has its own four-decision limit.
- Demo mode: no API calls; deterministic connector/parser selection, unknown semantic
  metadata, then overview-and-draft planning. It tests control flow, not AI quality.
- PDF and UTF-8 TXT extraction with page references, low-text warnings, limits and deduplication.
- Page-boundary-preserving, fixed-size chunks with stable IDs; selected-document filtering
  before keyword-overlap ranking and a bounded evidence context.
- Playwright source collection is **HKU only**, through the two custom connector names.
  Configured public HTML entries retain host/IP checks, interception and DNS pinning.
  URLs are deliberately unconfigured by default; no arbitrary public web collection exists.
- Per-session in-memory checkpoints with an explicit serializer type allowlist, temporary
  canonical JSON, action outcomes, planner/retrieval timing and reported provider token counts.
- Blueprint JSON download, automated tests, lint and a GitHub Actions CI draft.

**Not implemented:** question generation, semantic validation, independent Critic solving,
question repair/replanning loops, ranked exam assembly, approval, student/answer-key projections,
PDF export, timed practice, grading, feedback, OCR, Docling, institutional login,
and live HKU exam-PDF search/navigation/download flows.
Writer/Critic/Editor modules are intentional extension points, not fake completed agents.
Every terminal path has `ready_for_export=False`. A draft passing the allocation/evidence
gate is not a validated exam and does not establish semantic source support.

## Agentic intake and planning flow

```text
Queue manual files and/or request HKU ExamBase/Moodle
  -> early sharing consent before ANY external AI call
  -> bounded Source Collector -> configured HKU-only Playwright or upload fallback
  -> bounded Document Processor -> approved extraction tool -> proposed metadata
  -> material-review interrupt and selected-source confirmation
  -> Planner decision
  retrieve -> selected-source tool -> evidence/no-match observation -> Planner
  draft    -> marks/source/evidence-presence gate
                rejected -> validation feedback -> Planner
                accepted -> parallel Writer handoffs -> placeholder Critic/Editor -> draft view
  stop, provider failure, repeated retrieval, or exhausted limits -> stopped view
```

The model proposes actions; Python validates and executes only registered HKU
collection, parsing and local retrieval operations. The model receives bounded evidence, feedback
and remaining limits, never generic browser, shell or filesystem permissions.
Processing sees consented queued inputs before selection; planning sees only selected
materials. AI classification is labeled as a proposal and never rewrites source pages.
Retrieval results retain document, page and chunk IDs. An empty search is an
observation, not permission to invent evidence. Repeating an unchanged search stops.

Draft gates check requested marks, selected source IDs and whether evidence was
retrieved for every selected document. They do **not** check factual correctness.
The first overview passage is not comprehensive document coverage; the planner may
need targeted searches or must stop when the evidence/limits are insufficient.
Source text is bounded by characters, not a model-specific token-window guarantee.

## Quick start (Windows PowerShell)

Python 3.13 is the tested development version. The source targets Python 3.11+.
Use Python 3.13 for the documented setup. Internet access is needed to download
dependencies, but Demo mode does not require an API key or a model download.

### 1. Extract the archive and open the project directory

Open PowerShell in the `examcraft` directory containing [app.py](app.py) and
[pyproject.toml](pyproject.toml). If your terminal is in its parent directory:

```powershell
Set-Location .\examcraft
```

Install Python 3.13 if necessary, then confirm that the Windows Python launcher
can find it:

```powershell
py -3.13 --version
```

If `py` is not recognized, install Python 3.13 with the Windows Python launcher,
then reopen PowerShell. A source-only archive does not include Python or installed
dependencies.

### 2. Create the virtual environment and install dependencies

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

The install reads the pinned dependencies and development tools from
[pyproject.toml](pyproject.toml). Reuse an existing working virtual environment
instead of recreating it; after the packaging cleanup, create it again as shown
above. Activation is not required because every command uses its interpreter
explicitly.

### 3. Start the application

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Open http://127.0.0.1:8501. Keep the server bound to localhost; this scaffold is
not a production deployment. Press `Ctrl+C` in the terminal to stop it.

### 4. Verify the setup without an API key

1. Leave **AI mode** set to **Demo**.
2. Open **Sample** and click **Load sample notes**.
3. Click **Review materials** to run deterministic extraction and reach source review.
4. Keep the sample selected and click **Create blueprint**.
5. Confirm that **Draft blueprint** and the agent workflow trace appear.

Manual PDF/TXT upload and this Demo path do not need Chromium. A draft blueprint
is the expected result; question generation and exam export remain unimplemented.

### 5. Optional: install Chromium for HKU collection or browser tests

```powershell
.\.venv\Scripts\python.exe -m playwright install chromium
```

Only custom HKU ExamBase/Moodle connectors may use Playwright for source collection.
Their entry URLs and authentication remain deferred; installing Chromium alone
does not enable live HKU exam retrieval. All other sources use manual upload.

For automated checks, see [Development checks](#development-checks). Without
Chromium, use the documented `not browser` test selection.

### 6. Optional: configure OpenRouter

Demo needs no local secrets file. For external AI mode, follow
[OpenRouter configuration](#openrouter-configuration) below, supply your own key
and give the required sharing consent. Never include a real key in an archive.

### Other operating systems

On macOS/Linux, use `python3 -m venv .venv` and `.venv/bin/python` for the same commands.
Linux browser installations may also need `python -m playwright install --with-deps chromium`.

## OpenRouter configuration

Create a local `.env` from [.env.example](.env.example), without overwriting an
existing secrets file:

```powershell
if (-not (Test-Path -LiteralPath .env)) {
    Copy-Item -LiteralPath .env.example -Destination .env
}
```

Edit the local file and set `OPENROUTER_API_KEY` yourself, then restart the app.
Never commit a real key or paste it into group chat. Environment variables also work.

```dotenv
OPENROUTER_API_KEY=your-private-key
OPENROUTER_MODEL=openai/gpt-4.1-mini
HKU_EXAMBASE_ENTRY_URL=
HKU_MOODLE_ENTRY_URL=
```

Select **OpenRouter** in the sidebar. Before **Review materials**, explicitly authorize
AI intake: collection can share the course code and source request, and processing
can share metadata and bounded excerpts from every queued input. Later material
selection restricts planning; it cannot undo earlier intake sharing. A second
confirmation at **Create blueprint** authorizes the selected planning scope.
Confirm institutional permissions and provider data-handling terms before using course materials.
`data_collection=deny` is requested, but it is not a guarantee of zero retention.

The adapter uses the OpenAI-compatible Chat Completions endpoint at
`https://openrouter.ai/api/v1`. Choose a currently available model/endpoint that supports
JSON-schema structured output. Provider routing requires support for the supplied parameters.
Availability, credits and compatibility must be verified with your own account.
No live paid API request is needed by the automated tests.

### Shared limits and usage

| Setting | Default | Meaning |
| --- | --- | --- |
| `MAX_AI_REQUESTS` | `24` | Shared HTTP-attempt allowance across collection, processing and planning, including retries |
| `MAX_AI_TOKENS` | `100000` | Shared accounted tokens; known usage replaces estimates, missing/failed usage retains reservations |
| `MAX_COLLECTION_STEPS` | `3` | Source Collector decisions; each configured requested HKU connector is attempted at most once |
| `MAX_PROCESSING_STEPS` | `3` | Processing decisions per input, including tool errors or premature finish decisions |
| `MAX_PLANNING_STEPS` | `4` | Maximum planner decisions, including rejected drafts and failed requests |
| `MAX_RETRIEVAL_REQUESTS` | `2` | Maximum executed evidence requests |
| `RETRIEVAL_CHUNK_CHARACTERS` | `1200` | Fixed-size chunk limit; chunks never cross a page |
| `RETRIEVAL_LIMIT` | `8` | Maximum keyword-search results; overview takes one passage per selected document |
| `MAX_PROMPT_CHARACTERS` | `16000` | Evidence-text allowance, shared across selected documents |
| `MAX_OUTPUT_TOKENS` | `1200` | Output-token limit per provider request |
| `MODEL_TIMEOUT_SECONDS` | `45` | SDK request timeout; not an overall run deadline |
| `MIN_PAGE_CHARACTERS` | `50` | Low-text warning threshold; not proof that extraction succeeded |

See [.env.example](.env.example). Each logical model request permits at most one
retry for a transient API failure. SDK retries are disabled so every actual attempt
reserves the same shared allowance. Failed/unknown usage is not treated as free.
The reservation uses UTF-8 payload/schema size, output allowance and overhead; it is
a conservative estimate, not a model-specific tokenizer guarantee. Maximum file
count does not guarantee every file fits the remaining model budget.
There is no automatic new run after failure or exhaustion.

The trace records provider-reported input/output tokens when available; missing
usage stays unknown, not zero. Demo reports zero tokens. Unmeasured durations are
also unknown. These measurements and limits are **not a currency-cost budget**.
Add pricing-aware currency checks and an end-to-end deadline before activating the
remaining question-generation roles. No live paid API request is needed by automated tests.

## Document sources

Manual upload supports text PDFs and UTF-8 `.txt` files. Encrypted, malformed,
oversized or wholly textless documents are rejected. Low-text pages in otherwise
accepted documents produce visible warnings; image/diagram content can still be
missing even when a page has enough extracted text to avoid a warning.
Canonical JSON includes proposed metadata, processing mode and source provenance,
using content-derived IDs rather than user filenames. Queued original bytes remain
in run memory until intake; they are not serialized into graph checkpoints or stored
by the workspace service. The queue is cleared after intake/reset. Streamlit upload
widgets may retain their session buffer until reset.

The supplied Lecture 3 PDF is about 11.4 MB and 130 pages, so it exceeds both
the default 10 MiB parser limit and 100-page limit. Its diagram-heavy pages also
show why raising limits alone is not extraction support. If changing upload
limits, align `MAX_FILE_BYTES`, `MAX_PDF_PAGES` and Streamlit's `server.maxUploadSize`
in [.streamlit/config.toml](.streamlit/config.toml); do not silently remove safeguards.

### HKU-only Playwright policy

Only custom `hku_exambase` and `hku_moodle` connectors exist. Their entry URLs
must use HTTPS and an `hku.hk` hostname, without credentials or alternate ports.
Every navigation/redirect must also stay on that connector's exact configured host
and resolve to public addresses. Models cannot supply URLs, selectors or browser code.
The former `COLLECTION_ALLOWED_HOSTS` setting and generic URL textbox are removed.

**Entry URLs will be prepared later and remain blank now. Authentication is also
deferred.** Unconfigured connectors never launch a browser. Login forms, access
failures and unsupported downloads return explicit manual-upload guidance. Do not
add credentials, browser cookies, automatic sign-in or MFA handling.

The current configured-entry adapter supports public HTML only. Actual ExamBase/Moodle
search selectors, course navigation and exam-PDF downloads require a later custom
design against approved URLs; no live HKU integration is claimed. All other institutions,
public websites and sources are **manual-upload only** at this stage.

The Chromium-only connector uses CDP interception so every redirected request is checked
before continuing. Extend it through separately reviewed, deterministic connectors;
never execute model-generated browser code or selectors.

## Structure and ownership

```text
app.py                       Streamlit entry point
pyproject.toml               Pinned direct dependencies and tooling
src/examcraft/
    config.py                Typed settings; local .env loading
    schemas/models.py        Shared document, request, blueprint and task contracts
    schemas/intake.py        In-memory inputs and typed collection/processing decisions
    schemas/planning.py      Decisions, evidence context, observations and usage events
    ingestion/documents.py   PDF/TXT parsing
    ingestion/hku_policy.py  Immutable institutional restriction and connector names
    ingestion/connectors/hku.py
    providers/openrouter.py  Consented shared attempt/token ledger and role requests
    agents/source_collection.py
    agents/document_processing.py
    agents/planner.py        Role instructions, Planner.decide protocol and demo policy
    agents/writers.py        Objective/analytical generation extension points
    agents/critic.py         Independent review extension point
    agents/editor_selector.py
    graph/state.py           Typed state and parallel-output reducer
    graph/routing.py         Explicit decision, retrieval and validation routes
    graph/workflow.py        Bounded loop, interrupt, handoffs and checkpointing
    retrieval/evidence.py    Selected-source chunks, lexical search and context budget
    validators/planning.py   Deterministic draft-allocation/evidence-presence gate
    services/session.py      Run lifecycle, consent and workflow control
    services/intake.py       Bounded intake tool loops and canonical metadata storage
    services/workspace.py    Temporary document storage and cleanup
    ui/app.py                Streamlit screens
    assets/                  Local visual assets
tests/                       Domain, workflow, provider, UI and browser fixture tests
plan.md                      Remaining implementation tasks and acceptance criteria
checkpoints/                 Plan traceability only; not runtime checkpoints
.github/workflows/ci.yml      Standalone-project CI draft
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for four suggested workstreams and module contracts.
No particular group member has been assigned ownership yet.
There is no empty `evaluation/` scaffold: implementing runnable evaluation is an
explicit roadmap task, not a capability implied by a directory name.

## Development checks

Run from this project directory:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m ruff check .
.\.venv\Scripts\python.exe -m ruff format --check .
```

The `browser` tests launch real Chromium but fulfill responses locally, without contacting
HKU or external course sites. For a quick check without the Chromium binary:

```powershell
.\.venv\Scripts\python.exe -m pytest -q -m "not browser"
```

Direct dependencies are pinned to the versions tested for this baseline. Transitive
dependencies are resolved by pip; a full cross-platform lockfile remains future work.
The CI draft assumes `examcraft/` becomes the Git repository root. If your repository root
is its parent, move the workflow to the parent's `.github/workflows/` and set the job's
working directory and dependency-cache path to `examcraft`.

## Lifecycle and limits

Each Streamlit session owns its graph, thread ID, documents and temporary directory.
**New run** deletes its checkpoints and temporary JSON, and clears the UI state.
Closing a run revokes the shared client's consent and stops later intake actions;
an already in-flight network operation may finish, but its result is not accepted.
No SQL, Redis, permanent vector database or shared user-history store is used.
The current checkpointer still stores full document objects as well as run evidence;
moving large content to workspace references is planned before increasing scale.
Python also attempts temporary-directory cleanup when the owning object is finalized.
Server restarts do not restore runs. Browser reconnection is not guaranteed to restore a session.

Crash-safe startup/periodic TTL cleanup, authentication, deployment isolation, network egress
controls and sandboxed PDF parsing are future production work. Do not deploy this draft
as an untrusted public upload service. Avoid sensitive documents until these controls
and provider permissions have been reviewed. No document content or API keys are deliberately logged.

## Troubleshooting

- Missing Chromium: run `python -m playwright install chromium` using the project interpreter.
- Corporate certificate error during download: have IT verify the trusted certificate chain.
  On compatible Node runtimes, a temporary `NODE_OPTIONS=--use-system-ca` can let the
  installer use the Windows certificate store. Do not disable TLS verification.
- HKU collection unavailable: entry URLs/login are deferred; use manual upload.
  Configuring a public HKU HTML entry does not implement institutional search or PDF downloads.
- OpenRouter failure: check the model's structured-output support, credits and key locally;
  create a new run after correcting the configuration.
- Planning stopped: read the stop reason and trace. Change the selected materials or
  configuration in a new run; do not treat a stopped run as a validated partial exam.
- Port occupied: run `python -m streamlit run app.py --server.port 8502`.