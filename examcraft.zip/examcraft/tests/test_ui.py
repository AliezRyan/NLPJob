from pathlib import Path
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from examcraft.schemas.planning import PlannerTurn, PlanningDecision


def test_demo_ui_flow_and_reset():
    app = AppTest.from_file(str(Path(__file__).parents[1] / "app.py"), default_timeout=20)
    app.run(timeout=20)
    assert not app.exception
    assert "Web source" not in [tab.label for tab in app.tabs]
    assert "HKU collection" in [tab.label for tab in app.tabs]
    assert not any(field.label == "Authorized public HTTPS page" for field in app.text_input)
    assert app.button(key="begin_review").disabled
    app.button(key="load_sample").click().run()
    app.button(key="begin_review").click().run()
    assert not app.exception
    app.button(key="create_blueprint").click().run(timeout=20)
    assert not app.exception
    assert app.header[0].value == "Draft blueprint"
    assert app.session_state.run.result["ready_for_export"] is False
    assert app.session_state.run.result["planning_steps"] == 2
    assert app.session_state.run.result["retrieval_requests"] == 1
    old_workspace = app.session_state.run.workspace.path
    app.button(key="new_run").click().run()
    assert not app.exception
    assert not old_workspace.exists()
    assert app.header[0].value == "Course materials"
    app.session_state.run.close()


def test_ai_intake_button_requires_early_sharing_consent():
    app = AppTest.from_file(str(Path(__file__).parents[1] / "app.py"), default_timeout=20)
    app.run(timeout=20)
    app.button(key="load_sample").click().run()
    app.radio(key="ui_mode").set_value("OpenRouter").run()
    assert not app.exception
    assert app.button(key="begin_review").disabled
    assert app.checkbox(key="ui_intake_consent").value is False
    assert app.session_state.run.phase == "materials"
    app.session_state.run.close()


def test_stopped_planning_is_not_presented_as_a_blueprint():
    app = AppTest.from_file(str(Path(__file__).parents[1] / "app.py"), default_timeout=20)
    app.run(timeout=20)
    app.button(key="load_sample").click().run()
    with patch("examcraft.services.session.DemoPlanner") as planner:
        planner.return_value.decide.return_value = PlannerTurn(
            decision=PlanningDecision(
                action="stop",
                reason="The selected material is insufficient.",
                query=None,
                blueprint=None,
            ),
            input_tokens=0,
            output_tokens=0,
        )
        app.button(key="begin_review").click().run()
    app.button(key="create_blueprint").click().run(timeout=20)
    assert not app.exception
    assert app.header[0].value == "Planning stopped"
    assert "blueprint" not in app.session_state.run.result
    assert app.session_state.run.result["ready_for_export"] is False
    app.session_state.run.close()
