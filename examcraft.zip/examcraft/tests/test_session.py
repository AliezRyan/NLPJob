from unittest.mock import patch

import pytest
from pydantic import SecretStr

from examcraft.config import Settings
from examcraft.ingestion.documents import parse_document
from examcraft.schemas.models import ExamRequest
from examcraft.schemas.planning import PlannerTurn, PlanningDecision
from examcraft.services.session import RunSession


def test_runs_are_isolated_and_document_limits_apply():
    settings = Settings(_env_file=None, max_files=1)
    first = RunSession(settings)
    second = RunSession(settings)
    try:
        source = parse_document("notes.txt", b"Course evidence", settings)
        assert first.add_document(source)
        assert not first.add_document(source)
        assert second.documents == []
        assert first.run_id != second.run_id
        with pytest.raises(ValueError, match="document limit"):
            first.add_document(parse_document("more.txt", b"Other evidence", settings))
    finally:
        first.close()
        second.close()


def test_live_planning_requires_explicit_consent():
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-only-placeholder"))
    run = RunSession(settings)
    try:
        document = parse_document("notes.txt", b"Course evidence", settings)
        run.add_document(document)
        with patch("examcraft.services.session.OpenRouterPlanner") as planner:
            run.start_review(ExamRequest(course_code="TEST101"), "OpenRouter")
            with pytest.raises(ValueError, match="approval"):
                list(run.create_blueprint([document.document_id], consent=False))
            planner.return_value.decide.assert_not_called()
    finally:
        run.close()


def test_stopped_planning_does_not_open_the_blueprint_screen():
    settings = Settings(_env_file=None)
    run = RunSession(settings)
    try:
        document = parse_document("notes.txt", b"Course evidence", settings)
        run.add_document(document)
        with patch("examcraft.services.session.DemoPlanner") as planner:
            planner.return_value.decide.return_value = PlannerTurn(
                decision=PlanningDecision(
                    action="stop",
                    reason="There is insufficient evidence.",
                    query=None,
                    blueprint=None,
                ),
                input_tokens=0,
                output_tokens=0,
            )
            run.start_review(ExamRequest(course_code="TEST101"), "Demo")
            list(run.create_blueprint([document.document_id]))
        assert run.phase == "stopped"
        assert run.result["status"] == "planning_stopped"
        assert "blueprint" not in run.result
        assert run.result["ready_for_export"] is False
    finally:
        run.close()
