from unittest.mock import patch

import pytest
from pydantic import SecretStr, ValidationError

from examcraft.agents.document_processing import DemoDocumentProcessor
from examcraft.agents.source_collection import DemoSourceCollector
from examcraft.config import Settings
from examcraft.providers.openrouter import ModelUnavailableError, OpenRouterClient
from examcraft.schemas.intake import (
    AgentTurn,
    MaterialInput,
    ProcessingDecision,
)
from examcraft.schemas.models import DocumentMetadata, ExamRequest
from examcraft.services.intake import IntakeRunner
from examcraft.services.session import RunSession
from examcraft.services.workspace import RunWorkspace


@pytest.mark.parametrize(
    "url",
    [
        "https://docs.python.org/",
        "https://hku.hk.evil.example/",
        "https://evilhku.hk/",
        "http://moodle.hku.hk/",
        "https://user:password@moodle.hku.hk/",
        "https://moodle.hku.hk:8443/",
        r"https://evil\moodle.hku.hk/",
    ],
)
def test_non_hku_or_unsafe_entry_configuration_is_rejected(url):
    with pytest.raises(ValidationError):
        Settings(_env_file=None, hku_moodle_entry_url=url)


def test_manual_upload_never_starts_playwright():
    run = RunSession(Settings(_env_file=None))
    try:
        assert run.stage_upload("other-university.txt", b"Authorized uploaded evidence.")
        with patch("examcraft.services.intake.collect_hku_page") as browser:
            run.start_review(ExamRequest(course_code="TEST101"), "Demo")
            browser.assert_not_called()
        assert run.phase == "review"
        assert run.documents[0].metadata.document_type == "unknown"
        assert run.documents[0].processing_mode == "demo"
        assert run.documents[0].source == "upload"
        assert run.pending_materials == []
        assert any(event.stage == "processing" for event in run.result["events"])
    finally:
        run.close()


def test_processed_metadata_round_trips_through_strict_checkpoints(monkeypatch):
    monkeypatch.setenv("LANGGRAPH_STRICT_MSGPACK", "true")
    run = RunSession(Settings(_env_file=None))
    try:
        run.stage_upload("notes.txt", b"Course evidence to preserve.")
        run.start_review(ExamRequest(course_code="TEST101"), "Demo")
        restored = run.graph.get_state(run.graph_config).values["documents"][0]
        assert isinstance(restored.metadata, DocumentMetadata)
        assert restored.pages[0].text == "Course evidence to preserve."
    finally:
        run.close()


def test_unconfigured_hku_sources_fall_back_without_browsing():
    run = RunSession(Settings(_env_file=None))
    try:
        with patch("examcraft.services.intake.collect_hku_page") as browser:
            run.start_review(
                ExamRequest(course_code="TEST101"),
                "Demo",
                hku_sources=["hku_exambase", "hku_moodle"],
            )
            browser.assert_not_called()
        assert run.phase == "stopped"
        assert run.result["status"] == "intake_stopped"
        assert any("not configured" in item.lower() for item in run.result["intake_warnings"])
        assert run.result["ready_for_export"] is False
    finally:
        run.close()


def test_external_intake_requires_consent_before_any_model_or_browser_call():
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-placeholder"))
    run = RunSession(settings)
    try:
        run.stage_upload("notes.txt", b"Private course evidence")
        with (
            patch("examcraft.providers.openrouter.OpenAI") as api,
            patch("examcraft.services.intake.collect_hku_page") as browser,
        ):
            with pytest.raises(ValueError, match="consent"):
                run.start_review(ExamRequest(course_code="TEST101"), "OpenRouter")
            api.assert_not_called()
            browser.assert_not_called()
        assert run.phase == "materials"
    finally:
        run.close()


def test_configured_hku_connector_is_chosen_by_the_collection_agent():
    settings = Settings(
        _env_file=None, hku_exambase_entry_url="https://exambase.hku.hk/course/TEST101"
    )
    run = RunSession(settings)
    material = MaterialInput(
        filename="hku_exambase.txt",
        content=b"TEST101 authorized HKU page evidence.",
        source="playwright",
        source_connector="hku_exambase",
        source_url=settings.hku_exambase_entry_url,
    )
    try:
        with patch("examcraft.services.intake.collect_hku_page", return_value=material) as browser:
            run.start_review(
                ExamRequest(course_code="TEST101"), "Demo", hku_sources=["hku_exambase"]
            )
            browser.assert_called_once_with("hku_exambase", settings)
        assert run.phase == "review"
        assert run.documents[0].source_connector == "hku_exambase"
        assert run.documents[0].source_url == settings.hku_exambase_entry_url
        assert any(event.stage == "collection" for event in run.result["events"])
    finally:
        run.close()


def test_processing_agent_cannot_finish_without_extraction():
    metadata = DocumentMetadata(
        document_type="lecture_notes",
        title=None,
        author=None,
        year=None,
        topics=["Assessment"],
        summary="AI-proposed classification.",
    )

    class ScriptedProcessor:
        def __init__(self):
            self.contexts = []
            self.decisions = iter(
                [
                    ProcessingDecision(
                        action="finish", reason="Premature metadata", tool=None, metadata=metadata
                    ),
                    ProcessingDecision(
                        action="extract", reason="Read evidence", tool="utf8", metadata=None
                    ),
                    ProcessingDecision(
                        action="finish",
                        reason="Use extracted evidence",
                        tool=None,
                        metadata=metadata,
                    ),
                ]
            )

        def decide(self, context):
            self.contexts.append(context)
            return AgentTurn(decision=next(self.decisions), input_tokens=0, output_tokens=0)

    processor = ScriptedProcessor()
    workspace = RunWorkspace()
    try:
        runner = IntakeRunner(
            Settings(_env_file=None),
            workspace,
            [MaterialInput(filename="notes.txt", content=b"Extracted source evidence.")],
            [],
            "TEST101",
            DemoSourceCollector(),
            processor,
            "ai",
        )
        documents, warnings, events = runner.process([])
        assert not warnings
        assert "extract" in processor.contexts[1].feedback[0].lower()
        assert documents[0].pages[0].text == "Extracted source evidence."
        assert documents[0].metadata.topics == ["Assessment"]
        assert documents[0].processing_mode == "ai"
        assert any(event.outcome == "tool_utf8" for event in events)
    finally:
        workspace.close()


def test_document_processing_failure_is_visible_not_success_shaped():
    run = RunSession(Settings(_env_file=None))
    try:
        run.stage_upload("invalid.pdf", b"%PDF-not-a-valid-document")
        run.start_review(ExamRequest(course_code="TEST101"), "Demo")
        assert run.phase == "stopped"
        assert run.documents == []
        assert run.result["intake_warnings"]
        assert run.result["ready_for_export"] is False
    finally:
        run.close()


def test_unavailable_ocr_is_an_observation_and_keeps_a_quality_warning():
    class OcrProcessor:
        def decide(self, context):
            if context.extracted and not context.feedback:
                return AgentTurn(
                    decision=ProcessingDecision(
                        action="extract",
                        tool="ocr",
                        metadata=None,
                        reason="Inspect unavailable OCR handling.",
                    ),
                    input_tokens=0,
                    output_tokens=0,
                )
            if context.feedback:
                assert "OCR is not configured" in context.feedback[0]
            return DemoDocumentProcessor().decide(context)

    workspace = RunWorkspace()
    try:
        runner = IntakeRunner(
            Settings(_env_file=None),
            workspace,
            [MaterialInput(filename="notes.txt", content=b"Readable source evidence.")],
            [],
            "TEST101",
            DemoSourceCollector(),
            OcrProcessor(),
            "demo",
        )
        documents, warnings, events = runner.process([])
        assert not warnings
        assert "unavailable OCR" in documents[0].processing_warnings[-1]
        assert any(event.outcome == "ocr_unavailable" for event in events)
    finally:
        workspace.close()


def test_shared_client_checks_consent_and_budget_before_network():
    settings = Settings(
        _env_file=None,
        openrouter_api_key=SecretStr("test-placeholder"),
        max_ai_tokens=1000,
    )
    client = OpenRouterClient(settings)
    context = ExamRequest(course_code="TEST101")
    with patch("examcraft.providers.openrouter.OpenAI") as api:
        with pytest.raises(ModelUnavailableError, match="consent"):
            client.request(ProcessingDecision, "Process course material", context, "processing")
        client.grant_consent(True)
        with pytest.raises(ModelUnavailableError, match="token budget"):
            client.request(ProcessingDecision, "Process course material", context, "processing")
        api.assert_not_called()


def test_collected_materials_do_not_enable_other_sources():
    settings = Settings(_env_file=None)
    workspace = RunWorkspace()
    try:
        with pytest.raises(ValueError, match="Only HKU"):
            IntakeRunner(
                settings,
                workspace,
                [],
                ["other_source"],
                "TEST101",
                DemoSourceCollector(),
                DemoDocumentProcessor(),
                "demo",
            )
    finally:
        workspace.close()


def test_closing_the_client_revokes_future_requests():
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-placeholder"))
    client = OpenRouterClient(settings, consent=True)
    client.close()
    with patch("examcraft.providers.openrouter.OpenAI") as api:
        with pytest.raises(ModelUnavailableError, match="closed"):
            client.request(
                ProcessingDecision,
                "Processing",
                ExamRequest(course_code="TEST101"),
                "processing",
            )
        api.assert_not_called()
    with pytest.raises(ValueError, match="closed run"):
        client.grant_consent(True)
