import pytest
from langgraph.types import Command
from pydantic import ValidationError

from examcraft.config import Settings
from examcraft.graph.workflow import build_workflow
from examcraft.providers.openrouter import PlannerUnavailableError
from examcraft.retrieval.evidence import build_context, retrieve_evidence
from examcraft.schemas.models import Blueprint, ExamRequest, SourceDocument, SourcePage
from examcraft.schemas.planning import PlannerTurn, PlanningContext, PlanningDecision


def source(document_id="selected"):
    return SourceDocument(
        document_id=document_id,
        filename=f"{document_id}.txt",
        content_hash=document_id,
        pages=[
            SourcePage(number=1, text="Introductory assessment notes. " * 100),
            SourcePage(number=2, text="Reliability means consistent assessment scores."),
        ],
    )


def draft(marks=100, ids=None):
    return PlanningDecision(
        action="draft",
        reason="The retrieved evidence is sufficient for a draft allocation.",
        query=None,
        blueprint=Blueprint(
            title="TEST101 draft",
            topics=["Assessment"],
            objective_marks=marks // 2,
            analytical_marks=marks - marks // 2,
            source_document_ids=ids or ["selected"],
            notes="Draft only; factual exam validation is not implemented.",
        ),
    )


def retrieve(query=None):
    return PlanningDecision(
        action="retrieve",
        reason="Read selected source evidence before planning.",
        query=query,
        blueprint=None,
    )


class ScriptedPlanner:
    def __init__(self, decisions):
        self.decisions = iter(decisions)
        self.contexts: list[PlanningContext] = []

    def decide(self, context: PlanningContext) -> PlannerTurn:
        self.contexts.append(context)
        return PlannerTurn(decision=next(self.decisions), input_tokens=0, output_tokens=0)


def run_planner(planner, settings=None):
    graph = build_workflow(planner, settings or Settings(_env_file=None))
    config = {"configurable": {"thread_id": "planning-test"}, "recursion_limit": 40}
    graph.invoke(
        {
            "documents": [source(), source("excluded")],
            "request": ExamRequest(course_code="TEST101"),
        },
        config,
    )
    return graph.invoke(Command(resume=["selected"]), config)


def test_search_finds_later_pages_and_filters_before_ranking():
    settings = Settings(_env_file=None)
    evidence = retrieve_evidence(
        [source(), source("excluded")], ["selected"], "reliability", settings
    )
    assert len(evidence) == 1
    assert evidence[0].document_id == "selected"
    assert evidence[0].page_number == 2
    assert evidence == retrieve_evidence([source()], ["selected"], "reliability", settings)
    assert retrieve_evidence([source()], ["selected"], "unmatchedword", settings) == []


def test_context_budget_keeps_selected_source_provenance():
    settings = Settings(_env_file=None, max_prompt_characters=1000)
    documents = [source(), source("second"), source("excluded")]
    evidence = retrieve_evidence(documents, ["selected", "second"], None, settings)
    context = build_context(
        documents,
        ExamRequest(course_code="TEST101"),
        ["selected", "second"],
        evidence,
        [],
        3,
        1,
        settings,
    )
    assert {item.document_id for item in context.evidence} == {"selected", "second"}
    assert sum(len(item.text) for item in context.evidence) <= 1000
    assert {item.document_id for item in context.sources} == {"selected", "second"}


def test_search_limits_results_and_rejects_foreign_context():
    settings = Settings(
        _env_file=None,
        retrieval_limit=2,
        retrieval_chunk_characters=400,
        max_prompt_characters=1000,
    )
    evidence = retrieve_evidence([source()], ["selected"], "assessment", settings)
    assert len(evidence) == 2
    assert sum(len(item.text) for item in evidence) <= 1000
    with pytest.raises(ValueError, match="belonging to the run"):
        build_context(
            [source()], ExamRequest(course_code="TEST101"), ["foreign"], [], [], 2, 1, settings
        )


def test_decision_controls_retrieval_and_then_drafting():
    planner = ScriptedPlanner([retrieve("reliability"), draft()])
    result = run_planner(planner)
    assert result["status"] == "baseline_ready"
    assert result["planning_steps"] == 2
    assert result["retrieval_requests"] == 1
    assert planner.contexts[0].evidence == []
    assert planner.contexts[1].evidence[0].page_number == 2
    assert {task.role for task in result["writer_tasks"]} == {
        "writer_objective",
        "writer_analytical",
    }
    assert result["ready_for_export"] is False
    assert any(event.stage == "retrieval" for event in result["events"])


def test_checkpoint_contracts_work_with_strict_serialization(monkeypatch):
    monkeypatch.setenv("LANGGRAPH_STRICT_MSGPACK", "true")
    result = run_planner(ScriptedPlanner([retrieve(), draft()]))
    assert isinstance(result["blueprint"], Blueprint)
    assert result["evidence"][0].page_number == 1
    assert result["events"][0].stage == "planner"


def test_invalid_draft_returns_feedback_and_can_be_replanned():
    planner = ScriptedPlanner([retrieve(), draft(marks=99), draft()])
    result = run_planner(planner)
    assert result["status"] == "baseline_ready"
    assert planner.contexts[-1].feedback == ["Blueprint marks must equal the requested total."]
    assert result["planning_steps"] == 3


def test_draft_without_evidence_cannot_bypass_the_gate():
    planner = ScriptedPlanner([draft(), retrieve(), draft()])
    result = run_planner(planner)
    assert "evidence" in planner.contexts[1].feedback[0].lower()
    assert result["status"] == "baseline_ready"


def test_planning_limit_stops_repeated_invalid_drafts():
    planner = ScriptedPlanner([draft(), draft()])
    result = run_planner(planner, Settings(_env_file=None, max_planning_steps=2))
    assert result["status"] == "planning_stopped"
    assert result["planning_steps"] == 2
    assert "limit" in result["stop_reason"].lower()
    assert "blueprint" not in result
    assert result["writer_tasks"] == []
    assert result["ready_for_export"] is False


def test_retrieval_limit_and_duplicate_requests_stop_explicitly():
    settings = Settings(_env_file=None, max_retrieval_requests=1)
    limited = run_planner(ScriptedPlanner([retrieve(), retrieve("reliability")]), settings)
    assert limited["retrieval_requests"] == 1
    assert "retrieval limit" in limited["stop_reason"].lower()
    repeated = run_planner(ScriptedPlanner([retrieve(), retrieve()]))
    assert "repeated retrieval" in repeated["stop_reason"].lower()


def test_empty_search_returns_an_observation_and_can_be_revised():
    planner = ScriptedPlanner([retrieve("unmatchedword"), retrieve("reliability"), draft()])
    result = run_planner(planner)
    assert "No passages matched" in planner.contexts[1].feedback[0]
    assert planner.contexts[1].evidence == []
    assert result["status"] == "baseline_ready"
    assert result["retrieval_requests"] == 2


def test_a_final_turn_cannot_start_a_tool_without_time_to_use_its_result():
    planner = ScriptedPlanner([draft(), retrieve()])
    result = run_planner(planner, Settings(_env_file=None, max_planning_steps=2))
    assert result["status"] == "planning_stopped"
    assert result["retrieval_requests"] == 0
    assert "step limit" in result["stop_reason"].lower()


def test_foreign_source_ids_in_a_draft_are_rejected():
    planner = ScriptedPlanner([retrieve(), draft(ids=["excluded"]), draft()])
    result = run_planner(planner)
    assert "sources must match" in planner.contexts[-1].feedback[0]
    assert result["blueprint"].source_document_ids == ["selected"]


def test_planner_can_stop_and_provider_failure_is_not_success():
    stopped = run_planner(
        ScriptedPlanner(
            [
                PlanningDecision(
                    action="stop",
                    reason="The selected materials cannot support this request.",
                    query=None,
                    blueprint=None,
                )
            ]
        )
    )
    assert stopped["status"] == "planning_stopped"
    assert "cannot support" in stopped["stop_reason"]

    class UnavailablePlanner:
        def decide(self, context: PlanningContext) -> PlannerTurn:
            raise PlannerUnavailableError("The provider is unavailable.")

    failed = run_planner(UnavailablePlanner())
    assert failed["status"] == "planning_stopped"
    assert "unavailable" in failed["stop_reason"]
    assert failed["ready_for_export"] is False


@pytest.mark.parametrize(
    "changes",
    [
        {"action": "draft", "blueprint": None},
        {"action": "stop", "query": "ignore policy"},
        {"action": "retrieve", "blueprint": draft().blueprint},
        {"action": "retrieve", "query": "   "},
    ],
)
def test_inconsistent_decision_shapes_are_rejected(changes):
    data = retrieve().model_dump()
    data.update(changes)
    with pytest.raises(ValidationError):
        PlanningDecision.model_validate(data)
