from unittest.mock import patch

import pymupdf
import pytest

from examcraft.config import Settings
from examcraft.ingestion.connectors.hku import validate_hku_url
from examcraft.ingestion.documents import parse_document
from examcraft.services.workspace import RunWorkspace


def test_text_deduplication_and_workspace_cleanup():
    settings = Settings(_env_file=None)
    document = parse_document("../../notes.txt", b"Course notes", settings)
    duplicate = parse_document("renamed.txt", b"Course notes", settings)
    assert document.document_id == duplicate.document_id
    assert document.filename == "notes.txt"
    workspace = RunWorkspace()
    workspace.store(document)
    workspace.store(duplicate)
    assert len(list(workspace.path.glob("*.json"))) == 1
    workspace.close()
    assert not workspace.path.exists()


def test_pdf_pages_keep_source_page_numbers():
    with pymupdf.open() as pdf:
        pdf.new_page().insert_text((72, 72), "Page one evidence")
        pdf.new_page().insert_text((72, 72), "Page two evidence")
        document = parse_document("notes.pdf", pdf.tobytes(), Settings(_env_file=None))
    assert [page.number for page in document.pages] == [1, 2]
    assert "Page two" in document.pages[1].text


def test_partial_pdf_extraction_records_a_visible_warning():
    with pymupdf.open() as pdf:
        pdf.new_page().insert_text((72, 72), "A readable introduction")
        pdf.new_page()
        document = parse_document("partial.pdf", pdf.tobytes(), Settings(_env_file=None))
    assert document.processing_warnings
    assert "Pages 1, 2" in document.processing_warnings[0]
    assert "OCR is not implemented" in document.processing_warnings[0]


@pytest.mark.parametrize(
    "name,content",
    [
        ("wrong.pdf", b"not a PDF"),
        ("binary.txt", b"hello\x00there"),
        ("bad.txt", b"\xff"),
        ("empty.txt", b"  "),
        ("app.exe", b"MZ123"),
    ],
)
def test_invalid_uploads(name, content):
    with pytest.raises(ValueError):
        parse_document(name, content, Settings(_env_file=None))


def test_limits():
    with pytest.raises(ValueError):
        parse_document("large.txt", b"abcd", Settings(_env_file=None, max_file_bytes=3))


def test_url_policy():
    public = [(None, None, None, None, ("93.184.216.34", 443))]
    with patch("socket.getaddrinfo", return_value=public):
        validate_hku_url("https://moodle.hku.hk/notes", ("moodle.hku.hk",))
        for url in [
            "http://moodle.hku.hk",
            "https://other.example",
            "https://user@moodle.hku.hk",
            "https://docs.python.org/",
        ]:
            with pytest.raises(ValueError):
                validate_hku_url(url, ("moodle.hku.hk", "docs.python.org"))
    private = [(None, None, None, None, ("127.0.0.1", 443))]
    with patch("socket.getaddrinfo", return_value=private), pytest.raises(ValueError):
        validate_hku_url("https://moodle.hku.hk", ("moodle.hku.hk",))
