import json
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import httpx
import pytest
from openai import APIConnectionError
from pydantic import SecretStr

from examcraft.agents.planner import DemoPlanner
from examcraft.config import Settings
from examcraft.providers.openrouter import (
    ModelUnavailableError,
    OpenRouterClient,
    OpenRouterPlanner,
    PlannerUnavailableError,
)
from examcraft.retrieval.evidence import build_context, retrieve_evidence
from examcraft.schemas.intake import CollectionDecision
from examcraft.schemas.models import ExamRequest, SourceDocument, SourcePage


def planning_context(settings):
    source = SourceDocument(
        document_id="selected",
        filename="notes.txt",
        content_hash="hash",
        pages=[SourcePage(number=1, text="Untrusted course content")],
    )
    evidence = retrieve_evidence([source], ["selected"], None, settings)
    return build_context(
        [source], ExamRequest(course_code="TEST101"), ["selected"], evidence, [], 2, 1, settings
    )


def response(content, finish_reason="stop", usage=None):
    return SimpleNamespace(
        choices=[
            SimpleNamespace(finish_reason=finish_reason, message=SimpleNamespace(content=content))
        ],
        usage=usage,
    )


def test_openrouter_structured_contract_usage_and_call_limit():
    settings = Settings(
        _env_file=None, openrouter_api_key=SecretStr("test-only-placeholder"), max_planning_steps=2
    )
    context = planning_context(settings)
    decision = DemoPlanner().decide(context).decision
    client = MagicMock()
    client.chat.completions.create.return_value = response(
        decision.model_dump_json(),
        usage=SimpleNamespace(prompt_tokens=120, completion_tokens=40),
    )
    with patch("examcraft.providers.openrouter.OpenAI") as constructor:
        constructor.return_value.__enter__.return_value = client
        planner = OpenRouterPlanner(settings, consent=True)
        turn = planner.decide(context)
        assert turn.decision == decision
        assert (turn.input_tokens, turn.output_tokens) == (120, 40)
        planner.decide(context)
        with pytest.raises(PlannerUnavailableError, match="call limit"):
            planner.decide(context)
    assert constructor.call_args.kwargs["base_url"] == "https://openrouter.ai/api/v1"
    assert constructor.call_args.kwargs["max_retries"] == 0
    arguments = client.chat.completions.create.call_args.kwargs
    assert arguments["response_format"]["type"] == "json_schema"
    assert "Untrusted course content" not in arguments["messages"][0]["content"]
    payload = json.loads(arguments["messages"][1]["content"])
    assert payload["evidence"][0]["document_id"] == "selected"


@pytest.mark.parametrize(
    "content,finish_reason",
    [
        ("not JSON", "stop"),
        ('{"action":"draft","reason":"missing draft","query":null,"blueprint":null}', "stop"),
        ("{}", "length"),
    ],
)
def test_invalid_or_incomplete_decisions_fail_explicitly(content, finish_reason):
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-only-placeholder"))
    client = MagicMock()
    client.chat.completions.create.return_value = response(content, finish_reason)
    with patch("examcraft.providers.openrouter.OpenAI") as constructor:
        constructor.return_value.__enter__.return_value = client
        with pytest.raises(PlannerUnavailableError):
            OpenRouterPlanner(settings, consent=True).decide(planning_context(settings))


def test_missing_usage_is_not_reported_as_zero():
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-only-placeholder"))
    context = planning_context(settings)
    client = MagicMock()
    client.chat.completions.create.return_value = response(
        DemoPlanner().decide(context).decision.model_dump_json()
    )
    with patch("examcraft.providers.openrouter.OpenAI") as constructor:
        constructor.return_value.__enter__.return_value = client
        turn = OpenRouterPlanner(settings, consent=True).decide(context)
    assert turn.input_tokens is None
    assert turn.output_tokens is None


def test_missing_key_fails_without_network():
    with pytest.raises(ValueError, match="OPENROUTER_API_KEY"):
        OpenRouterPlanner(Settings(_env_file=None, openrouter_api_key=SecretStr("")))


def test_shared_attempt_limit_applies_across_roles():
    settings = Settings(
        _env_file=None,
        openrouter_api_key=SecretStr("test-placeholder"),
        max_ai_requests=1,
    )
    client = OpenRouterClient(settings, consent=True)
    decision = CollectionDecision(action="finish", connector=None, reason="Use manual upload.")
    transport = MagicMock()
    transport.chat.completions.create.return_value = response(decision.model_dump_json())
    with patch("examcraft.providers.openrouter.OpenAI") as constructor:
        constructor.return_value.__enter__.return_value = transport
        client.request(
            CollectionDecision, "Collection role", ExamRequest(course_code="TEST101"), "collection"
        )
        with pytest.raises(ModelUnavailableError, match="request limit"):
            client.request(
                CollectionDecision, "Another role", ExamRequest(course_code="TEST101"), "processing"
            )
    assert transport.chat.completions.create.call_count == 1
    assert client.attempts == 1
    assert client.accounted_tokens > 0


def test_transient_retry_consumes_another_shared_attempt():
    settings = Settings(_env_file=None, openrouter_api_key=SecretStr("test-placeholder"))
    client = OpenRouterClient(settings, consent=True)
    decision = CollectionDecision(action="finish", connector=None, reason="Use manual upload.")
    transport = MagicMock()
    transport.chat.completions.create.side_effect = [
        APIConnectionError(request=httpx.Request("POST", "https://openrouter.ai/api/v1")),
        response(decision.model_dump_json()),
    ]
    with patch("examcraft.providers.openrouter.OpenAI") as constructor:
        constructor.return_value.__enter__.return_value = transport
        result = client.request(
            CollectionDecision, "Collection role", ExamRequest(course_code="TEST101"), "collection"
        )
    assert result.decision == decision
    assert client.attempts == 2
    assert transport.chat.completions.create.call_count == 2
