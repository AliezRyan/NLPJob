import base64
from unittest.mock import patch

import pytest
from playwright.async_api import CDPSession

from examcraft.config import Settings
from examcraft.ingestion.connectors.hku import collect_hku_page


def test_unconfigured_and_non_hku_entries_never_launch_a_browser():
    with patch("examcraft.ingestion.connectors.hku.async_playwright") as browser:
        with pytest.raises(ValueError, match="not configured"):
            collect_hku_page("hku_moodle", Settings(_env_file=None))
        invalid = Settings.model_construct(hku_moodle_entry_url="https://docs.python.org/")
        with pytest.raises(ValueError, match="hku.hk"):
            collect_hku_page("hku_moodle", invalid)
        browser.assert_not_called()


@pytest.mark.browser
@pytest.mark.parametrize(
    "redirect_target",
    [None, "https://denied.invalid/private", "https://moodle.hku.hk/private"],
)
def test_chromium_collection_with_offline_responses(redirect_target):
    original_send = CDPSession.send
    continued = []
    blocked = []

    async def fixture_send(session, method, params=None):
        if method == "Fetch.continueRequest":
            continued.append(params["requestId"])
            headers = [{"name": "Content-Type", "value": "text/html"}]
            if redirect_target:
                headers.append({"name": "Location", "value": redirect_target})
            return await original_send(
                session,
                "Fetch.fulfillRequest",
                {
                    "requestId": params["requestId"],
                    "responseCode": 302 if redirect_target else 200,
                    "responseHeaders": headers,
                    "body": base64.b64encode(
                        b"<html><body>Course fixture evidence</body></html>"
                    ).decode(),
                },
            )
        if method == "Fetch.failRequest":
            blocked.append(params["requestId"])
        return await original_send(session, method, params)

    settings = Settings(_env_file=None, hku_exambase_entry_url="https://exambase.hku.hk/notes")
    public = [(None, None, None, None, ("93.184.216.34", 443))]
    with (
        patch("socket.getaddrinfo", return_value=public),
        patch.object(CDPSession, "send", fixture_send),
    ):
        if redirect_target:
            with pytest.raises(ValueError, match="HKU collection failed"):
                collect_hku_page("hku_exambase", settings)
            assert blocked
        else:
            document = collect_hku_page("hku_exambase", settings)
            assert document.content.decode() == "Course fixture evidence"
            assert document.source == "playwright"
            assert document.source_connector == "hku_exambase"
            assert document.source_url == "https://exambase.hku.hk/notes"
    assert len(continued) == 1
