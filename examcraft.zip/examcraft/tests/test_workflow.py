import pytest
from langgraph.types import Command

from examcraft.agents.planner import DemoPlanner
from examcraft.graph.workflow import build_workflow
from examcraft.schemas.models import ExamRequest, SourceDocument, SourcePage


def document(document_id="selected"):
    return SourceDocument(
        document_id=document_id,
        filename=f"{document_id}.txt",
        content_hash=document_id,
        pages=[SourcePage(number=1, text="A sample course source.")],
    )


def test_review_interrupt_and_selected_source_planning():
    graph = build_workflow(DemoPlanner())
    config = {"configurable": {"thread_id": "test"}}
    result = graph.invoke(
        {
            "documents": [document(), document("excluded")],
            "request": ExamRequest(course_code="TEST101", total_marks=99),
        },
        config,
    )
    assert result["__interrupt__"]
    result = graph.invoke(Command(resume=["selected"]), config)
    assert result["blueprint"].source_document_ids == ["selected"]
    assert result["blueprint"].objective_marks + result["blueprint"].analytical_marks == 99
    assert result["status"] == "baseline_ready"
    assert {task.role for task in result["writer_tasks"]} == {
        "writer_objective",
        "writer_analytical",
    }
    assert result["review_status"] == "not_implemented"
    assert result["ready_for_export"] is False


@pytest.mark.parametrize("selection", [[], ["foreign"], "selected", [{}]])
def test_invalid_selection_is_rejected(selection):
    graph = build_workflow(DemoPlanner())
    config = {"configurable": {"thread_id": "test"}}
    graph.invoke({"documents": [document()], "request": ExamRequest(course_code="TEST101")}, config)
    with pytest.raises(ValueError, match="Select at least"):
        graph.invoke(Command(resume=selection), config)
