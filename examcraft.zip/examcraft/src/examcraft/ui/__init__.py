"""Streamlit presentation; domain logic belongs in services and graph modules."""
