from pathlib import Path

import streamlit as st
from pydantic import ValidationError

from examcraft.config import Settings
from examcraft.ingestion.connectors.hku import configured_hku_sources
from examcraft.ingestion.hku_policy import HKU_SOURCE_LABELS
from examcraft.providers.openrouter import PlannerUnavailableError
from examcraft.schemas.models import ExamRequest
from examcraft.services.session import RunSession

SAMPLE_NOTES = b"""Foundations of assessment
Validity concerns whether an assessment measures the intended learning outcomes.
Reliability concerns consistency of scores across occasions or markers.
Formative assessment gives feedback during learning. Summative assessment evaluates
achievement at the end of a unit. A blueprint maps topics, question types and marks
to the intended outcomes. Clear rubrics support consistent marking.
"""

NODE_LABELS = {
    "collect_materials": "HKU-only collection checked",
    "process_materials": "Document-processing tools and metadata completed",
    "stop_intake": "Material intake stopped; manual upload required",
    "review_materials": "Sources confirmed",
    "planner": "Planner selected an action",
    "retrieve_evidence": "Selected-source evidence retrieved",
    "validate_blueprint": "Draft allocation checked",
    "stop_planning": "Planning stopped without approval",
    "writer_objective": "Objective writer handoff prepared",
    "writer_analytical": "Analytical writer handoff prepared",
    "critic": "Critic implementation pending",
    "editor_selector": "Assembly implementation pending",
}


def main() -> None:
    st.set_page_config(page_title="ExamCraft", page_icon=":material/school:", layout="wide")
    if "run" not in st.session_state:
        try:
            st.session_state.run = RunSession(Settings())
        except ValidationError:
            st.error("Invalid application configuration. Check the project environment settings.")
            st.stop()
    run: RunSession = st.session_state.run
    with st.sidebar:
        logo = Path(__file__).resolve().parents[1] / "assets" / "examcraft.png"
        if logo.exists():
            st.image(str(logo), width=48)
        st.title("ExamCraft")
        st.caption("GROUP 7 / DEVELOPMENT BASELINE")
        mode = st.radio(
            "AI mode", ["Demo", "OpenRouter"], key="ui_mode", disabled=run.phase != "materials"
        )
        if mode == "OpenRouter":
            st.caption(run.settings.openrouter_model)
            st.caption(
                f"Collection, processing and planning share up to "
                f"{run.settings.max_ai_requests} HTTP attempts and a "
                f"{run.settings.max_ai_tokens:,}-token accounting budget."
            )
            if not run.settings.openrouter_api_key.get_secret_value():
                st.warning("OpenRouter API key is not configured.")
        st.divider()
        st.caption(f"Run {run.run_id[:8]}")
        st.write(
            f"Materials: {len(run.documents) + len(run.pending_materials)} / "
            f"{run.settings.max_files}"
        )
        st.write(f"Stage: {run.phase.title()}")
        if st.button("New run", icon=":material/restart_alt:", key="new_run"):
            run.close()
            for key in list(st.session_state):
                if key == "run" or key.startswith("ui_"):
                    del st.session_state[key]
            st.rerun()
    if run.phase == "materials":
        _materials(run, mode)
    elif run.phase == "review":
        _review(run)
    elif run.phase == "blueprint":
        _blueprint(run)
    elif run.phase == "stopped":
        st.header(
            "Material processing stopped"
            if run.result.get("status") == "intake_stopped"
            else "Planning stopped"
        )
        st.warning(run.result["stop_reason"])
        for warning in run.result.get("intake_warnings", []):
            st.warning(warning)
        st.info("No exam was approved. Start a new run to change the materials or configuration.")
        _planning_trace(run)
    elif run.phase == "intake":
        st.header("Processing materials")
        st.info("Material intake is already running. No additional request has been started.")
    else:
        st.header("Planning paused")
        st.error("This run could not complete. No exam was approved.")


def _materials(run: RunSession, mode: str) -> None:
    st.header("Course materials")
    upload_tab, hku_tab, sample_tab = st.tabs(["Upload files", "HKU collection", "Sample"])
    with upload_tab:
        uploads = st.file_uploader(
            "PDF or UTF-8 text", type=["pdf", "txt"], accept_multiple_files=True, key="ui_uploads"
        )
        if st.button("Add files", icon=":material/upload_file:", disabled=not uploads):
            added = 0
            for uploaded in uploads:
                try:
                    added += run.stage_upload(uploaded.name, uploaded.getvalue())
                except (ValueError, OSError) as error:
                    st.text(f"Could not add: {uploaded.name}")
                    st.warning(
                        "Document validation failed."
                        if isinstance(error, ValidationError)
                        else str(error)
                    )
            st.success(
                f"{added} file(s) queued. Extraction and classification start at material review. "
                "Duplicate content was skipped."
            )
    with hku_tab:
        st.caption(
            "Playwright is available only through custom HKU ExamBase and Moodle connectors. "
            "Other sources must use manual upload. Entry URLs and authentication are deferred."
        )
        entries = configured_hku_sources(run.settings)
        for source, label in HKU_SOURCE_LABELS.items():
            st.text(
                f"{label}: {'configured public entry' if source in entries else 'not configured'}"
            )
        hku_sources = st.multiselect(
            "Optional HKU sources",
            options=list(HKU_SOURCE_LABELS),
            format_func=HKU_SOURCE_LABELS.__getitem__,
            key="ui_hku_sources",
        )
        st.info(
            "No generic URL or non-HKU browser collection is available. The current HKU adapter "
            "reads configured public HTML only. "
            "Exam PDF navigation/downloads will be designed later."
        )
    with sample_tab:
        st.subheader("Foundations of assessment")
        st.text("Validity, reliability, formative assessment and marking rubrics.")
        if st.button(
            "Load sample notes",
            icon=":material/note_add:",
            key="load_sample",
            disabled=len(run.documents) + len(run.pending_materials) >= run.settings.max_files,
        ):
            added = run.stage_upload("assessment-notes.txt", SAMPLE_NOTES, "sample")
            st.success("Sample queued." if added else "Sample is already in this run.")
    st.divider()
    if run.pending_materials:
        st.dataframe(
            [
                {"Queued file": item.filename, "Source": item.source, "Bytes": len(item.content)}
                for item in run.pending_materials
            ],
            hide_index=True,
            width="stretch",
        )
    if run.documents:
        _source_table(run)
    elif not run.pending_materials:
        st.info("No source materials in this run.")
    intake_consent = False
    if mode == "OpenRouter":
        st.warning(
            "Before source selection, AI collection/processing can send the course code, file "
            "metadata and bounded excerpts from every queued input to OpenRouter. "
            "This may incur charges. Later source selection restricts planning; "
            "it cannot undo data already shared for processing."
        )
        intake_consent = st.checkbox(
            "I authorize external AI processing of these queued materials and the HKU request.",
            key="ui_intake_consent",
        )
    with st.form("exam_settings"):
        st.subheader("Exam settings")
        course_code = st.text_input("Course code", value="DEMO101", max_chars=100, key="ui_course")
        duration_column, marks_column = st.columns(2)
        duration = duration_column.number_input("Duration (minutes)", 5, 240, 60, key="ui_duration")
        marks = marks_column.number_input("Total marks", 1, 300, 100, key="ui_marks")
        submitted = st.form_submit_button(
            "Review materials",
            icon=":material/arrow_forward:",
            disabled=(
                not (run.documents or run.pending_materials or hku_sources)
                or (mode == "OpenRouter" and not intake_consent)
            ),
            key="begin_review",
        )
    if submitted:
        try:
            with st.spinner("Collecting permitted HKU materials and processing queued files"):
                run.start_review(
                    ExamRequest(
                        course_code=course_code.strip(),
                        duration_minutes=duration,
                        total_marks=marks,
                    ),
                    mode,
                    consent=intake_consent,
                    hku_sources=hku_sources,
                )
            st.rerun()
        except (ValueError, OSError):
            st.error("Check the course settings and, for OpenRouter, the API key configuration.")


def _source_table(run: RunSession) -> None:
    st.dataframe(
        [
            {
                "File": document.filename,
                "Pages": len(document.pages),
                "Source": document.source,
                "HKU connector": document.source_connector,
                "Type": document.metadata.document_type if document.metadata else "unclassified",
                "Processing mode": document.processing_mode,
                "Characters": sum(len(page.text) for page in document.pages),
                "Warnings": len(document.processing_warnings),
            }
            for document in run.documents
        ],
        hide_index=True,
        width="stretch",
    )


def _review(run: RunSession) -> None:
    st.header("Review sources")
    for warning in run.result.get("intake_warnings", []):
        st.warning(warning)
    names = {document.document_id: document.filename for document in run.documents}
    selected = st.multiselect(
        "Selected materials",
        options=list(names),
        default=list(names),
        format_func=names.__getitem__,
        key="ui_selected",
    )
    _source_table(run)
    for document in run.documents:
        with st.expander(document.filename):
            if document.source_url:
                st.text(document.source_url)
            for warning in document.processing_warnings:
                st.warning(warning)
            if document.metadata is not None:
                st.caption(
                    f"Classification mode: {document.processing_mode}. "
                    "AI metadata is a proposal, not independently verified evidence."
                )
                st.text(document.metadata.summary)
                if document.metadata.topics:
                    st.text("Proposed topics: " + ", ".join(document.metadata.topics))
            st.code(document.pages[0].text[:2000], language=None, wrap_lines=True)
    consent = False
    if run.mode == "OpenRouter":
        st.warning("This action sends source excerpts to OpenRouter and may incur API charges.")
        consent = st.checkbox(
            "I am authorized to share these materials with OpenRouter and its model provider.",
            key="ui_consent",
        )
    disabled = not selected or (run.mode == "OpenRouter" and not consent)
    if st.button(
        "Create blueprint",
        type="primary",
        icon=":material/account_tree:",
        disabled=disabled,
        key="create_blueprint",
    ):
        try:
            with st.status("Planning", expanded=True) as status:
                for node in run.create_blueprint(selected, consent):
                    status.write(NODE_LABELS.get(node, node))
                status.update(
                    label="Blueprint ready" if run.phase == "blueprint" else "Planning stopped",
                    state="complete" if run.phase == "blueprint" else "error",
                )
            st.rerun()
        except (ValueError, PlannerUnavailableError):
            st.error("Planning could not complete. Check configuration and start a new run.")
    _planning_trace(run)


def _blueprint(run: RunSession) -> None:
    blueprint = run.result["blueprint"]
    st.header("Draft blueprint")
    st.text(blueprint.title)
    st.warning("Question generation, independent critique and exam assembly are not implemented.")
    objective, analytical, sources = st.columns(3)
    objective.metric("Objective marks", blueprint.objective_marks)
    analytical.metric("Analytical marks", blueprint.analytical_marks)
    sources.metric("Selected sources", len(blueprint.source_document_ids))
    st.subheader("Topics")
    for topic in blueprint.topics:
        st.text(topic)
    st.text(blueprint.notes)
    st.subheader("Agent handoffs")
    st.dataframe(
        [
            {
                "Role": task.role,
                "Marks": task.marks,
                "Types": ", ".join(task.question_types),
                "Status": task.status,
            }
            for task in run.result["writer_tasks"]
        ],
        hide_index=True,
        width="stretch",
    )
    st.download_button(
        "Download blueprint JSON",
        blueprint.model_dump_json(indent=2),
        file_name="blueprint.json",
        mime="application/json",
        icon=":material/download:",
    )
    _planning_trace(run)


def _planning_trace(run: RunSession) -> None:
    st.subheader("Agent workflow trace")
    st.caption(
        f"Planner turns: {run.result.get('planning_steps', 0)} / "
        f"{run.settings.max_planning_steps}; retrieval requests: "
        f"{run.result.get('retrieval_requests', 0)} / {run.settings.max_retrieval_requests}. "
        "Demo mode is a deterministic policy, not an LLM quality evaluation."
    )
    events = run.result.get("events", [])
    st.dataframe(
        [
            {
                "Stage": event.stage,
                "Outcome": event.outcome,
                "Milliseconds": round(event.elapsed_ms, 1)
                if event.elapsed_ms is not None
                else None,
                "Input tokens": event.input_tokens,
                "Output tokens": event.output_tokens,
            }
            for event in events
        ],
        hide_index=True,
        width="stretch",
    )
    st.caption(
        "Missing token counts mean the provider did not report usage. "
        "Shared accounting retains a conservative reservation for unreported or failed attempts. "
        "This is not a currency-cost budget or an end-to-end deadline."
    )
    if run.client is not None:
        st.caption(
            f"Shared provider attempts: {run.client.attempts} / {run.settings.max_ai_requests}; "
            f"accounted tokens: {run.client.accounted_tokens:,} / "
            f"{run.settings.max_ai_tokens:,}."
        )
    with st.expander("Retrieved evidence references"):
        for chunk in run.result.get("evidence", []):
            st.text(f"{chunk.document_id} / page {chunk.page_number} / chunk {chunk.chunk_id}")
