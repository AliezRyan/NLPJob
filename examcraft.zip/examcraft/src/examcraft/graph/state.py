from operator import add
from typing import Annotated, TypedDict

from examcraft.schemas.models import Blueprint, ExamRequest, SourceDocument, WriterTask
from examcraft.schemas.planning import PlanningDecision, RunEvent, SourceChunk


class WorkflowState(TypedDict, total=False):
    documents: list[SourceDocument]
    intake_warnings: list[str]
    request: ExamRequest
    selected_ids: list[str]
    decision: PlanningDecision
    evidence: list[SourceChunk]
    feedback: list[str]
    planning_steps: int
    retrieval_requests: int
    retrieval_queries: list[str]
    stop_reason: str
    events: Annotated[list[RunEvent], add]
    blueprint: Blueprint
    writer_tasks: Annotated[list[WriterTask], add]
    review_status: str
    ready_for_export: bool
    status: str
