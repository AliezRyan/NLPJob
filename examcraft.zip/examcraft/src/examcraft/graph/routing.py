from typing import Literal

from examcraft.graph.state import WorkflowState


def route_planner(
    state: WorkflowState,
) -> Literal["retrieve_evidence", "validate_blueprint", "stop_planning"]:
    if state.get("stop_reason") or state["decision"].action == "stop":
        return "stop_planning"
    return "retrieve_evidence" if state["decision"].action == "retrieve" else "validate_blueprint"


def route_retrieval(state: WorkflowState) -> Literal["planner", "stop_planning"]:
    return "stop_planning" if state.get("stop_reason") else "planner"


def route_validation(state: WorkflowState) -> str | list[str]:
    if state.get("stop_reason"):
        return "stop_planning"
    if state.get("feedback"):
        return "planner"
    return ["writer_objective", "writer_analytical"]
