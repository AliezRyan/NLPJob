from time import perf_counter

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from examcraft.agents.critic import review_questions
from examcraft.agents.editor_selector import assemble_exams
from examcraft.agents.planner import Planner
from examcraft.agents.writers import write_analytical, write_objective
from examcraft.config import Settings
from examcraft.graph.routing import route_planner, route_retrieval, route_validation
from examcraft.graph.state import WorkflowState
from examcraft.providers.openrouter import PlannerUnavailableError
from examcraft.retrieval.evidence import build_context, retrieve_evidence
from examcraft.schemas.models import (
    Blueprint,
    DocumentMetadata,
    ExamRequest,
    SourceDocument,
    SourcePage,
    WriterTask,
)
from examcraft.schemas.planning import PlanningDecision, RunEvent, SourceChunk
from examcraft.services.intake import IntakeRunner
from examcraft.validators.planning import validate_draft


def build_workflow(
    planner: Planner, settings: Settings | None = None, intake: IntakeRunner | None = None
):
    limits = settings or Settings(_env_file=None)

    def collect_materials(state: WorkflowState) -> dict:
        warnings, events = intake.collect(state.get("documents", [])) if intake else ([], [])
        return {
            "intake_warnings": warnings,
            "events": events,
            "ready_for_export": False,
            "status": "collecting_materials",
        }

    def process_materials(state: WorkflowState) -> dict:
        if intake is None:
            return {"status": "materials_processed"}
        documents, warnings, events = intake.process(state.get("documents", []))
        return {
            "documents": documents,
            "intake_warnings": [*state.get("intake_warnings", []), *warnings],
            "events": events,
            "status": "materials_processed",
        }

    def route_materials(state: WorkflowState) -> str:
        return "review_materials" if state.get("documents") else "stop_intake"

    def stop_intake(_state: WorkflowState) -> dict:
        return {
            "status": "intake_stopped",
            "stop_reason": (
                "No usable material remains. Review the intake warnings and upload an authorized "
                "PDF or text file in a new run. HKU URLs and authentication are deferred."
            ),
            "ready_for_export": False,
            "events": [RunEvent(stage="stop", outcome="intake_stopped")],
        }

    def review_materials(state: WorkflowState) -> dict:
        selected = interrupt(
            {
                "type": "material_review",
                "document_ids": [document.document_id for document in state["documents"]],
            }
        )
        available = {document.document_id for document in state["documents"]}
        if (
            not isinstance(selected, list)
            or not selected
            or any(not isinstance(item, str) for item in selected)
            or not set(selected).issubset(available)
        ):
            raise ValueError("Select at least one document belonging to this run.")
        return {
            "selected_ids": list(dict.fromkeys(selected)),
            "status": "planning",
            "ready_for_export": False,
            "planning_steps": 0,
            "retrieval_requests": 0,
            "retrieval_queries": [],
            "evidence": [],
            "feedback": [],
            "events": [],
        }

    def plan_exam(state: WorkflowState) -> dict:
        steps = state["planning_steps"]
        if steps >= limits.max_planning_steps:
            return {"stop_reason": "Planner step limit reached; no exam was approved."}
        context = build_context(
            state["documents"],
            state["request"],
            state["selected_ids"],
            state["evidence"],
            state["feedback"],
            limits.max_planning_steps - steps,
            limits.max_retrieval_requests - state["retrieval_requests"],
            limits,
        )
        started = perf_counter()
        try:
            turn = planner.decide(context)
        except PlannerUnavailableError as error:
            return {
                "planning_steps": steps + 1,
                "stop_reason": str(error),
                "events": [
                    RunEvent(
                        stage="planner",
                        outcome="provider_error",
                        elapsed_ms=(perf_counter() - started) * 1000,
                    )
                ],
            }
        return {
            "decision": turn.decision,
            "planning_steps": steps + 1,
            "events": [
                RunEvent(
                    stage="planner",
                    outcome=turn.decision.action,
                    elapsed_ms=(perf_counter() - started) * 1000,
                    input_tokens=turn.input_tokens,
                    output_tokens=turn.output_tokens,
                )
            ],
        }

    def retrieve_sources(state: WorkflowState) -> dict:
        if state["planning_steps"] >= limits.max_planning_steps:
            return {"stop_reason": "Planner step limit reached before another retrieval."}
        if state["retrieval_requests"] >= limits.max_retrieval_requests:
            return {"stop_reason": "Retrieval limit reached; no exam was approved."}
        query = state["decision"].query
        key = " ".join(query.casefold().split()) if query is not None else ""
        if key in state["retrieval_queries"]:
            return {
                "stop_reason": "Repeated retrieval request without new evidence; planning stopped."
            }
        started = perf_counter()
        chunks = retrieve_evidence(state["documents"], state["selected_ids"], query, limits)
        merged = {chunk.chunk_id: chunk for chunk in state["evidence"]}
        for chunk in chunks:
            merged.pop(chunk.chunk_id, None)
            merged[chunk.chunk_id] = chunk
        return {
            "evidence": list(merged.values()),
            "retrieval_requests": state["retrieval_requests"] + 1,
            "retrieval_queries": [*state["retrieval_queries"], key],
            "feedback": [] if chunks else ["No passages matched the search. Refine it or stop."],
            "events": [
                RunEvent(
                    stage="retrieval",
                    outcome=f"found_{len(chunks)}_chunks" if chunks else "no_matches",
                    elapsed_ms=(perf_counter() - started) * 1000,
                )
            ],
        }

    def validate_blueprint(state: WorkflowState) -> dict:
        blueprint = state["decision"].blueprint
        if blueprint is None:
            raise ValueError("A draft decision must contain a blueprint.")
        issues = validate_draft(
            blueprint, state["request"], state["selected_ids"], state["evidence"]
        )
        update: dict[str, object] = {
            "feedback": issues,
            "events": [RunEvent(stage="validation", outcome="rejected" if issues else "accepted")],
        }
        if issues:
            if state["planning_steps"] >= limits.max_planning_steps:
                update["stop_reason"] = (
                    "Planner step limit reached after draft validation failures."
                )
        else:
            update["blueprint"] = blueprint
            update["status"] = "blueprint_ready"
        return update

    def stop_planning(state: WorkflowState) -> dict:
        return {
            "status": "planning_stopped",
            "ready_for_export": False,
            "stop_reason": state.get("stop_reason") or state["decision"].reason,
            "events": [RunEvent(stage="stop", outcome="planning_stopped")],
        }

    builder = StateGraph(WorkflowState)
    builder.add_node("collect_materials", collect_materials)
    builder.add_node("process_materials", process_materials)
    builder.add_node("stop_intake", stop_intake)
    builder.add_node("review_materials", review_materials)
    builder.add_node("planner", plan_exam)
    builder.add_node("retrieve_evidence", retrieve_sources)
    builder.add_node("validate_blueprint", validate_blueprint)
    builder.add_node("stop_planning", stop_planning)
    builder.add_node("writer_objective", write_objective)
    builder.add_node("writer_analytical", write_analytical)
    builder.add_node("critic", review_questions)
    builder.add_node("editor_selector", assemble_exams)
    builder.add_edge(START, "collect_materials")
    builder.add_edge("collect_materials", "process_materials")
    builder.add_conditional_edges(
        "process_materials", route_materials, ["review_materials", "stop_intake"]
    )
    builder.add_edge("stop_intake", END)
    builder.add_edge("review_materials", "planner")
    builder.add_conditional_edges(
        "planner", route_planner, ["retrieve_evidence", "validate_blueprint", "stop_planning"]
    )
    builder.add_conditional_edges(
        "retrieve_evidence", route_retrieval, ["planner", "stop_planning"]
    )
    builder.add_conditional_edges(
        "validate_blueprint",
        route_validation,
        ["planner", "stop_planning", "writer_objective", "writer_analytical"],
    )
    builder.add_edge("stop_planning", END)
    builder.add_edge(["writer_objective", "writer_analytical"], "critic")
    builder.add_edge("critic", "editor_selector")
    builder.add_edge("editor_selector", END)
    checkpoint_types = (
        SourceDocument,
        DocumentMetadata,
        SourcePage,
        ExamRequest,
        Blueprint,
        WriterTask,
        PlanningDecision,
        SourceChunk,
        RunEvent,
    )
    serializer = JsonPlusSerializer(
        allowed_msgpack_modules=[(model.__module__, model.__name__) for model in checkpoint_types]
    )
    return builder.compile(checkpointer=InMemorySaver(serde=serializer))
