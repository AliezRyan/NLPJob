"""Run-scoped services shared by UI and orchestration."""
