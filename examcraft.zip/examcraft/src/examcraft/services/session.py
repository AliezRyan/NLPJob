from collections.abc import Iterator
from pathlib import PureWindowsPath
from typing import Literal
from uuid import uuid4

from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command

from examcraft.agents.document_processing import DemoDocumentProcessor, OpenRouterDocumentProcessor
from examcraft.agents.planner import DemoPlanner
from examcraft.agents.source_collection import DemoSourceCollector, OpenRouterSourceCollector
from examcraft.config import Settings
from examcraft.graph.state import WorkflowState
from examcraft.graph.workflow import build_workflow
from examcraft.ingestion.documents import inspect_document
from examcraft.ingestion.hku_policy import HKU_SOURCE_LABELS, HKUSource
from examcraft.providers.openrouter import OpenRouterClient, OpenRouterPlanner
from examcraft.schemas.intake import MaterialInput
from examcraft.schemas.models import ExamRequest, SourceDocument
from examcraft.services.intake import IntakeRunner
from examcraft.services.workspace import RunWorkspace


class RunSession:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.run_id = uuid4().hex
        self.workspace = RunWorkspace()
        self.documents: list[SourceDocument] = []
        self.pending_materials: list[MaterialInput] = []
        self.intake: IntakeRunner | None = None
        self.client: OpenRouterClient | None = None
        self.graph: CompiledStateGraph | None = None
        self.result: WorkflowState = {}
        self.phase = "materials"
        self.mode = "Demo"

    @property
    def graph_config(self) -> dict:
        return {
            "configurable": {"thread_id": self.run_id},
            "recursion_limit": self.settings.max_planning_steps * 3 + 16,
        }

    def stage_upload(
        self,
        filename: str,
        content: bytes,
        source: Literal["upload", "sample"] = "upload",
    ) -> bool:
        if self.phase != "materials":
            raise ValueError("Start a new run to change the reviewed materials.")
        name = PureWindowsPath(filename).name
        if not name or len(name) > 255:
            raise ValueError("Use a filename between 1 and 255 characters.")
        inspect_document(name, content, self.settings)
        material = MaterialInput(filename=name, content=content, source=source)
        known = {item.content_hash for item in self.documents}
        known.update(item.content_hash for item in self.pending_materials)
        if material.content_hash in known:
            return False
        if len(self.documents) + len(self.pending_materials) >= self.settings.max_files:
            raise ValueError("The run has reached its document limit.")
        self.pending_materials.append(material)
        return True

    def add_document(self, document: SourceDocument) -> bool:
        if self.phase != "materials":
            raise ValueError("Start a new run to change the reviewed materials.")
        if any(existing.content_hash == document.content_hash for existing in self.documents):
            return False
        if len(self.documents) + len(self.pending_materials) >= self.settings.max_files:
            raise ValueError("The run has reached its document limit.")
        self.workspace.store(document)
        self.documents.append(document)
        return True

    def start_review(
        self,
        request: ExamRequest,
        mode: str,
        consent: bool = False,
        hku_sources: list[HKUSource] | None = None,
    ) -> None:
        requested = list(dict.fromkeys(hku_sources or []))
        if any(source not in HKU_SOURCE_LABELS for source in requested):
            raise ValueError("Only custom HKU ExamBase and Moodle collection is available.")
        if self.phase != "materials" or (
            not self.documents and not self.pending_materials and not requested
        ):
            raise ValueError("Add source materials before starting a review.")
        if mode not in {"Demo", "OpenRouter"}:
            raise ValueError("Unknown model mode.")
        if mode == "OpenRouter":
            self.client = OpenRouterClient(self.settings)
            if self.pending_materials or requested:
                self.client.grant_consent(consent)
            planner = OpenRouterPlanner(self.settings, client=self.client)
            collector = OpenRouterSourceCollector(self.client)
            processor = OpenRouterDocumentProcessor(self.client)
        else:
            planner = DemoPlanner()
            collector = DemoSourceCollector()
            processor = DemoDocumentProcessor()
        self.intake = IntakeRunner(
            self.settings,
            self.workspace,
            self.pending_materials,
            requested,
            request.course_code,
            collector,
            processor,
            "ai" if mode == "OpenRouter" else "demo",
        )
        self.graph = build_workflow(planner, self.settings, self.intake)
        self.mode = mode
        self.phase = "intake"
        try:
            result = self.graph.invoke(
                {"documents": self.documents, "request": request}, self.graph_config
            )
            self.result = self.graph.get_state(self.graph_config).values
            self.documents = list(self.result.get("documents", []))
            if result.get("__interrupt__"):
                self.phase = "review"
            elif self.result.get("status") == "intake_stopped":
                self.phase = "stopped"
            else:
                raise RuntimeError("The intake workflow ended without review or an explicit stop.")
        except Exception:
            self.phase = "error"
            raise
        finally:
            self.pending_materials.clear()

    def create_blueprint(self, selected_ids: list[str], consent: bool = False) -> Iterator[str]:
        if self.graph is None or self.phase != "review":
            raise ValueError("The material review is not active.")
        if not selected_ids:
            raise ValueError("Select at least one source document.")
        if self.mode == "OpenRouter" and not consent:
            raise ValueError("OpenRouter requires approval to send the selected source excerpts.")
        if self.mode == "OpenRouter":
            if self.client is None:
                raise RuntimeError("The run has no shared provider client.")
            self.client.grant_consent(consent)
        try:
            for update in self.graph.stream(
                Command(resume=selected_ids), self.graph_config, stream_mode="updates"
            ):
                yield from update.keys()
            self.result = self.graph.get_state(self.graph_config).values
            if self.result["status"] == "baseline_ready":
                self.phase = "blueprint"
            elif self.result["status"] == "planning_stopped":
                self.phase = "stopped"
            else:
                raise RuntimeError("The workflow ended without a recognized planning outcome.")
        except Exception:
            self.phase = "error"
            raise

    def close(self) -> None:
        if self.client is not None:
            self.client.close()
        if self.intake is not None:
            self.intake.close()
        try:
            if self.graph is not None and self.graph.checkpointer is not None:
                self.graph.checkpointer.delete_thread(self.run_id)
        finally:
            self.graph = None
            self.documents.clear()
            self.pending_materials.clear()
            self.intake = None
            self.client = None
            self.result.clear()
            self.workspace.close()
            self.phase = "closed"
