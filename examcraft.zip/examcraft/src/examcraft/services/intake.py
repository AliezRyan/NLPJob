from time import perf_counter
from typing import Literal

from examcraft.agents.document_processing import DocumentProcessor
from examcraft.agents.source_collection import SourceCollector
from examcraft.config import Settings
from examcraft.ingestion.connectors.hku import (
    collect_hku_page,
    configured_hku_sources,
)
from examcraft.ingestion.documents import inspect_document, parse_document
from examcraft.ingestion.hku_policy import HKU_SOURCE_LABELS, HKUSource
from examcraft.providers.openrouter import ModelUnavailableError
from examcraft.schemas.intake import CollectionContext, MaterialInput, ProcessingContext
from examcraft.schemas.models import SourceDocument, SourcePage
from examcraft.schemas.planning import RunEvent
from examcraft.services.workspace import RunWorkspace


class IntakeRunner:
    def __init__(
        self,
        settings: Settings,
        workspace: RunWorkspace,
        materials: list[MaterialInput],
        requested_sources: list[HKUSource],
        course_code: str,
        collector: SourceCollector,
        processor: DocumentProcessor,
        mode: Literal["demo", "ai"],
    ) -> None:
        if any(source not in HKU_SOURCE_LABELS for source in requested_sources):
            raise ValueError("Only HKU ExamBase and Moodle may use Playwright.")
        self.settings = settings
        self.workspace = workspace
        self.materials = list(materials)
        self.requested = list(dict.fromkeys(requested_sources))
        self.course_code = course_code
        self.collector = collector
        self.processor = processor
        self.mode = mode
        self.closed = False

    def close(self) -> None:
        self.closed = True
        self.materials.clear()

    def collect(self, documents: list[SourceDocument]) -> tuple[list[str], list[RunEvent]]:
        warnings: list[str] = []
        events: list[RunEvent] = []
        if not self.requested:
            return warnings, events
        configured = configured_hku_sources(self.settings)
        available = [source for source in self.requested if source in configured]
        for source in self.requested:
            if source not in configured:
                warnings.append(
                    f"{HKU_SOURCE_LABELS[source]} is not configured. Use manual upload; "
                    "entry URLs and authentication will be prepared later."
                )
        if not available:
            return warnings, [RunEvent(stage="collection", outcome="not_configured")]
        attempted: list[HKUSource] = []
        observations: list[str] = []
        for step in range(self.settings.max_collection_steps):
            if self.closed:
                warnings.append("Collection stopped because the run was closed.")
                break
            started = perf_counter()
            try:
                turn = self.collector.decide(
                    CollectionContext(
                        course_code=self.course_code,
                        requested=self.requested,
                        available=available,
                        attempted=attempted,
                        observations=observations,
                        remaining_steps=self.settings.max_collection_steps - step,
                    )
                )
            except ModelUnavailableError as error:
                warnings.append(f"Collection agent stopped: {error}")
                events.append(RunEvent(stage="collection", outcome="provider_stopped"))
                break
            events.append(
                RunEvent(
                    stage="collection",
                    outcome=turn.decision.action,
                    elapsed_ms=(perf_counter() - started) * 1000,
                    input_tokens=turn.input_tokens,
                    output_tokens=turn.output_tokens,
                )
            )
            if turn.decision.action == "finish":
                break
            source = turn.decision.connector
            if source is None or source not in available or source in attempted:
                warnings.append("Collection proposed an unavailable or repeated HKU connector.")
                break
            if len(documents) + len(self.materials) >= self.settings.max_files:
                warnings.append("The material limit prevents another HKU collection request.")
                break
            attempted.append(source)
            try:
                material = collect_hku_page(source, self.settings)
                if self.closed:
                    warnings.append("The run closed before collected material could be accepted.")
                    break
                known = {item.content_hash for item in self.materials}
                known.update(item.content_hash for item in documents)
                if material.content_hash not in known:
                    self.materials.append(material)
                observations.append(f"{HKU_SOURCE_LABELS[source]} returned a public HTML material.")
                events.append(RunEvent(stage="collection", outcome=f"tool_{source}"))
            except (ValueError, OSError) as error:
                message = f"{HKU_SOURCE_LABELS[source]} unavailable: {error}"
                warnings.append(message)
                observations.append(message)
                events.append(RunEvent(stage="collection", outcome="upload_fallback"))
        else:
            warnings.append(
                "The collection decision limit was reached; continue with usable inputs."
            )
        return warnings, events

    def _process_one(
        self, material: MaterialInput, events: list[RunEvent]
    ) -> tuple[SourceDocument | None, str | None]:
        media_type = inspect_document(material.filename, material.content, self.settings)
        document: SourceDocument | None = None
        feedback: list[str] = []
        attempted_tools: set[str] = set()
        for step in range(self.settings.max_processing_steps):
            if self.closed:
                return None, "Document processing stopped because the run was closed."
            excerpts = []
            remaining = self.settings.max_prompt_characters
            if document is not None:
                for page in document.pages:
                    text = page.text[:remaining]
                    if text:
                        excerpts.append(SourcePage(number=page.number, text=text))
                        remaining -= len(text)
                    if remaining <= 0:
                        break
            started = perf_counter()
            turn = self.processor.decide(
                ProcessingContext(
                    filename=material.filename,
                    media_type=media_type,
                    extracted=document is not None,
                    page_excerpts=excerpts,
                    warnings=document.processing_warnings if document is not None else [],
                    feedback=feedback,
                    remaining_steps=self.settings.max_processing_steps - step,
                )
            )
            decision = turn.decision
            events.append(
                RunEvent(
                    stage="processing",
                    outcome=decision.action,
                    elapsed_ms=(perf_counter() - started) * 1000,
                    input_tokens=turn.input_tokens,
                    output_tokens=turn.output_tokens,
                )
            )
            if decision.action == "stop":
                return None, f"Processing stopped for {material.filename}: {decision.reason}"
            if decision.action == "finish":
                if document is None:
                    feedback = ["Extract evidence with an approved tool before finishing."]
                    continue
                return document.model_copy(
                    update={"metadata": decision.metadata, "processing_mode": self.mode}
                ), None
            tool = decision.tool
            if step + 1 >= self.settings.max_processing_steps:
                return (
                    None,
                    f"Processing step limit prevents another extraction for {material.filename}.",
                )
            if tool is None or tool in attempted_tools:
                return None, f"Repeated or missing extraction tool for {material.filename}."
            attempted_tools.add(tool)
            if tool == "ocr":
                feedback = [
                    "OCR is not configured. Use extracted text with warnings or request upload."
                ]
                if document is not None:
                    document.processing_warnings.append(
                        "The processing agent requested unavailable OCR. Inspect the original "
                        "or upload a text version; image content remains unverified."
                    )
                events.append(RunEvent(stage="processing", outcome="ocr_unavailable"))
                continue
            expected = "pymupdf" if media_type == "pdf" else "utf8"
            if tool != expected:
                feedback = [
                    f"The inspected file type requires {expected}; other parsers are denied."
                ]
                events.append(RunEvent(stage="processing", outcome="tool_denied"))
                continue
            document = parse_document(
                material.filename, material.content, self.settings, material.source
            ).model_copy(
                update={
                    "source_connector": material.source_connector,
                    "source_url": material.source_url,
                }
            )
            feedback = []
            events.append(RunEvent(stage="processing", outcome=f"tool_{tool}"))
        return None, f"Processing step limit reached for {material.filename}; use another upload."

    def process(
        self, existing: list[SourceDocument]
    ) -> tuple[list[SourceDocument], list[str], list[RunEvent]]:
        documents = list(existing)
        warnings: list[str] = []
        events: list[RunEvent] = []
        try:
            for material in self.materials:
                if len(documents) >= self.settings.max_files:
                    warnings.append(
                        "The material limit was reached; remaining inputs were not processed."
                    )
                    break
                try:
                    document, warning = self._process_one(material, events)
                except (ValueError, OSError, ModelUnavailableError) as error:
                    warnings.append(f"Could not process {material.filename}: {error}")
                    events.append(RunEvent(stage="processing", outcome="failed"))
                    continue
                if warning:
                    warnings.append(warning)
                if document is None:
                    continue
                if self.closed:
                    warnings.append("The run closed before processed material could be stored.")
                    break
                if any(item.content_hash == document.content_hash for item in documents):
                    warnings.append(f"Duplicate input skipped: {material.filename}")
                    continue
                self.workspace.store(document)
                documents.append(document)
        finally:
            self.materials.clear()
        return documents, warnings, events
