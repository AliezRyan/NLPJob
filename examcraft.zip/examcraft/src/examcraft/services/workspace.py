from pathlib import Path
from tempfile import TemporaryDirectory

from examcraft.schemas.models import SourceDocument


class RunWorkspace:
    def __init__(self) -> None:
        self._temporary = TemporaryDirectory(prefix="examcraft-")
        self.path = Path(self._temporary.name).resolve()

    def store(self, document: SourceDocument) -> None:
        document_id = document.document_id
        if len(document_id) != 24 or any(
            character not in "0123456789abcdef" for character in document_id
        ):
            raise ValueError("Invalid document identifier.")
        target = (self.path / f"{document_id}.json").resolve()
        if target.parent != self.path:
            raise ValueError("Invalid workspace path.")
        temporary = target.with_suffix(".pending")
        temporary.write_text(document.model_dump_json(indent=2), encoding="utf-8")
        temporary.replace(target)

    def close(self) -> None:
        self._temporary.cleanup()
