from examcraft.schemas.models import Blueprint, ExamRequest
from examcraft.schemas.planning import SourceChunk


def validate_draft(
    blueprint: Blueprint,
    request: ExamRequest,
    selected_ids: list[str],
    evidence: list[SourceChunk],
) -> list[str]:
    issues = []
    try:
        blueprint.validate_against(request, selected_ids)
    except ValueError as error:
        issues.append(str(error))
    if not set(selected_ids).issubset({chunk.document_id for chunk in evidence}):
        issues.append("Retrieve evidence from every selected material before drafting.")
    return issues
