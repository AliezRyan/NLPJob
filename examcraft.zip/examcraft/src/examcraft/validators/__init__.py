"""Deterministic workflow gates, separate from semantic agent judgments."""
