"""Run-scoped, selected-source evidence retrieval."""
