import re
from hashlib import sha256

from examcraft.config import Settings
from examcraft.schemas.models import ExamRequest, SourceDocument
from examcraft.schemas.planning import PlanningContext, SourceChunk, SourceSummary


def _chunks(documents: list[SourceDocument], settings: Settings) -> list[SourceChunk]:
    chunks = []
    size = settings.retrieval_chunk_characters
    for document in documents:
        for page in document.pages:
            for start in range(0, len(page.text), size):
                text = page.text[start : start + size].strip()
                if text:
                    identity = f"{document.document_id}:{page.number}:{start}"
                    chunks.append(
                        SourceChunk(
                            chunk_id=sha256(identity.encode()).hexdigest()[:24],
                            document_id=document.document_id,
                            page_number=page.number,
                            text=text,
                        )
                    )
    return chunks


def _budget_evidence(
    chunks: list[SourceChunk], selected_ids: list[str], budget: int
) -> list[SourceChunk]:
    result = []
    per_document = budget // len(selected_ids)
    for document_id in selected_ids:
        remaining = per_document
        for chunk in chunks:
            if chunk.document_id == document_id and remaining > 0:
                text = chunk.text[:remaining]
                result.append(chunk.model_copy(update={"text": text}))
                remaining -= len(text)
    return result


def retrieve_evidence(
    documents: list[SourceDocument],
    selected_ids: list[str],
    query: str | None,
    settings: Settings,
) -> list[SourceChunk]:
    available = {document.document_id for document in documents}
    if not selected_ids or not set(selected_ids).issubset(available):
        raise ValueError("Retrieval requires selected documents belonging to the run.")
    selected = [document for document in documents if document.document_id in selected_ids]
    chunks = _chunks(selected, settings)
    if query is None:
        first_per_document: dict[str, SourceChunk] = {}
        for chunk in chunks:
            first_per_document.setdefault(chunk.document_id, chunk)
        candidates = list(first_per_document.values())
    else:
        terms = set(re.findall(r"\w+", query.casefold()))
        ranked = [
            (len(terms.intersection(re.findall(r"\w+", chunk.text.casefold()))), chunk)
            for chunk in chunks
        ]
        ranked.sort(key=lambda item: item[0], reverse=True)
        candidates = [chunk for score, chunk in ranked if score > 0][: settings.retrieval_limit]
    return _budget_evidence(candidates, selected_ids, settings.max_prompt_characters)


def build_context(
    documents: list[SourceDocument],
    request: ExamRequest,
    selected_ids: list[str],
    evidence: list[SourceChunk],
    feedback: list[str],
    remaining_steps: int,
    remaining_retrievals: int,
    settings: Settings,
) -> PlanningContext:
    if not selected_ids or not set(selected_ids).issubset(
        {document.document_id for document in documents}
    ):
        raise ValueError("A planning context requires selected materials belonging to the run.")
    return PlanningContext(
        request=request,
        sources=[
            SourceSummary(
                document_id=document.document_id,
                filename=document.filename,
                page_count=len(document.pages),
                processing_warnings=document.processing_warnings,
                proposed_metadata=document.metadata,
                processing_mode=document.processing_mode,
            )
            for document in documents
            if document.document_id in selected_ids
        ],
        evidence=_budget_evidence(
            list(reversed(evidence)), selected_ids, settings.max_prompt_characters
        ),
        feedback=feedback,
        remaining_steps=remaining_steps,
        remaining_retrievals=remaining_retrievals,
    )
