import json
from threading import Lock
from time import sleep
from typing import TypeVar

from openai import APIConnectionError, APIError, APIStatusError, OpenAI
from pydantic import BaseModel, ValidationError

from examcraft.agents.planner import PLANNER_PROMPT
from examcraft.config import Settings
from examcraft.schemas.intake import AgentTurn
from examcraft.schemas.models import Contract
from examcraft.schemas.planning import PlannerTurn, PlanningContext, PlanningDecision

ResponseT = TypeVar("ResponseT", bound=Contract)


class ModelUnavailableError(RuntimeError):
    pass


class PlannerUnavailableError(ModelUnavailableError):
    pass


class OpenRouterClient:
    """One consent and attempt/token ledger shared by all model roles in a run."""

    def __init__(self, settings: Settings, consent: bool = False) -> None:
        if not settings.openrouter_api_key.get_secret_value().strip():
            raise ValueError("Set OPENROUTER_API_KEY in the project .env file.")
        self.settings = settings
        self.consent = consent
        self.closed = False
        self.attempts = 0
        self.accounted_tokens = 0
        self._lock = Lock()

    def grant_consent(self, consent: bool) -> None:
        with self._lock:
            if self.closed:
                raise ValueError("This provider client belongs to a closed run.")
            if not consent:
                raise ValueError(
                    "Explicit sharing consent is required before external AI processing."
                )
            self.consent = True

    def close(self) -> None:
        with self._lock:
            self.closed = True
            self.consent = False

    def _reserve(self, tokens: int) -> None:
        with self._lock:
            if self.closed:
                raise ModelUnavailableError("The run was closed; provider requests are disabled.")
            if not self.consent:
                raise ModelUnavailableError("External AI sharing consent has not been granted.")
            if self.attempts >= self.settings.max_ai_requests:
                raise ModelUnavailableError("The shared AI request limit has been reached.")
            if self.accounted_tokens + tokens > self.settings.max_ai_tokens:
                raise ModelUnavailableError("The shared AI token budget has been exhausted.")
            self.attempts += 1
            self.accounted_tokens += tokens

    def request(
        self,
        output_type: type[ResponseT],
        instructions: str,
        context: BaseModel,
        role: str,
    ) -> AgentTurn[ResponseT]:
        payload = context.model_dump_json()
        schema = output_type.model_json_schema()
        reservation = (
            len(instructions.encode("utf-8"))
            + len(payload.encode("utf-8"))
            + len(json.dumps(schema).encode("utf-8"))
            + self.settings.max_output_tokens
            + 1024
        )
        for attempt in range(2):
            self._reserve(reservation)
            try:
                with OpenAI(
                    api_key=self.settings.openrouter_api_key.get_secret_value(),
                    base_url="https://openrouter.ai/api/v1",
                    timeout=self.settings.model_timeout_seconds,
                    max_retries=0,
                ) as client:
                    response = client.chat.completions.create(
                        model=self.settings.openrouter_model,
                        messages=[
                            {"role": "system", "content": instructions},
                            {"role": "user", "content": payload},
                        ],
                        temperature=0.2,
                        max_tokens=self.settings.max_output_tokens,
                        response_format={
                            "type": "json_schema",
                            "json_schema": {
                                "name": role,
                                "strict": True,
                                "schema": schema,
                            },
                        },
                        extra_body={
                            "provider": {"require_parameters": True, "data_collection": "deny"}
                        },
                    )
            except APIError as error:
                transient = isinstance(error, APIConnectionError) or (
                    isinstance(error, APIStatusError)
                    and (error.status_code in {408, 409, 429} or error.status_code >= 500)
                )
                if transient and attempt == 0:
                    sleep(0.5)
                    continue
                raise ModelUnavailableError(
                    "OpenRouter request failed. Check access, credit, model support or retry "
                    "in a new run. No exam has been approved."
                ) from None
            usage = response.usage
            if self.closed:
                raise ModelUnavailableError(
                    "The run was closed; no further AI results are accepted."
                )
            input_tokens = usage.prompt_tokens if usage is not None else None
            output_tokens = usage.completion_tokens if usage is not None else None
            if (input_tokens is not None and input_tokens < 0) or (
                output_tokens is not None and output_tokens < 0
            ):
                raise ModelUnavailableError("The provider returned invalid token usage.")
            if input_tokens is not None and output_tokens is not None:
                with self._lock:
                    self.accounted_tokens += input_tokens + output_tokens - reservation
                    if self.accounted_tokens > self.settings.max_ai_tokens:
                        raise ModelUnavailableError(
                            "The shared AI token budget has been exhausted."
                        )
            if not response.choices or response.choices[0].finish_reason != "stop":
                raise ModelUnavailableError(
                    "The model did not finish a complete structured decision."
                )
            try:
                decision = output_type.model_validate_json(
                    response.choices[0].message.content or ""
                )
            except ValidationError:
                raise ModelUnavailableError(
                    "The model returned an invalid structured decision; processing stopped."
                ) from None
            return AgentTurn(
                decision=decision, input_tokens=input_tokens, output_tokens=output_tokens
            )
        raise ModelUnavailableError("The bounded provider retry did not complete.")


class OpenRouterPlanner:
    def __init__(
        self,
        settings: Settings,
        client: OpenRouterClient | None = None,
        consent: bool = False,
    ) -> None:
        self.settings = settings
        self.client = client if client is not None else OpenRouterClient(settings, consent)
        self.calls = 0

    def decide(self, context: PlanningContext) -> PlannerTurn:
        if self.calls >= self.settings.max_planning_steps:
            raise PlannerUnavailableError("This run has reached its planner call limit.")
        if not context.sources:
            raise ValueError("The planner needs selected documents.")
        self.calls += 1
        try:
            turn = self.client.request(
                PlanningDecision, PLANNER_PROMPT, context, "planning_decision"
            )
        except ModelUnavailableError as error:
            raise PlannerUnavailableError(str(error)) from None
        return PlannerTurn(
            decision=turn.decision,
            input_tokens=turn.input_tokens,
            output_tokens=turn.output_tokens,
        )
