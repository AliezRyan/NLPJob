"""Provider adapters; never import Streamlit or browser tools here."""
