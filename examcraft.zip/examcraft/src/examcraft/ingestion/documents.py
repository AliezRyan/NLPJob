from hashlib import sha256
from pathlib import PureWindowsPath
from typing import Literal

import pymupdf

from examcraft.config import Settings
from examcraft.schemas.models import SourceDocument, SourcePage


def inspect_document(filename: str, content: bytes, settings: Settings) -> Literal["pdf", "text"]:
    if not content or len(content) > settings.max_file_bytes:
        raise ValueError("The file is empty or exceeds the configured size limit.")
    suffix = PureWindowsPath(filename).suffix.lower()
    if suffix == ".pdf":
        if not content.startswith(b"%PDF-"):
            raise ValueError("This file does not have a PDF signature.")
        return "pdf"
    if suffix != ".txt":
        raise ValueError("Only PDF and UTF-8 TXT files are supported in this baseline.")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("Text files must use UTF-8 encoding.") from None
    if any(ord(character) < 32 and character not in "\t\n\r" for character in text):
        raise ValueError("The text file contains binary control characters.")
    return "text"


def parse_document(
    filename: str,
    content: bytes,
    settings: Settings,
    source: Literal["upload", "playwright", "sample"] = "upload",
) -> SourceDocument:
    name = PureWindowsPath(filename).name
    media_type = inspect_document(name, content, settings)
    if media_type == "pdf":
        pages = _pdf_pages(content, settings)
    else:
        pages = [SourcePage(number=1, text=content.decode("utf-8-sig"))]
    if not any(page.text.strip() for page in pages):
        raise ValueError("No usable text found. Scanned PDFs need the future OCR connector.")
    if sum(len(page.text) for page in pages) > settings.max_document_characters:
        raise ValueError("The extracted text exceeds the configured document limit.")
    low_text_pages = [
        str(page.number) for page in pages if len(page.text.strip()) < settings.min_page_characters
    ]
    warnings = []
    if low_text_pages:
        warnings.append(
            f"Pages {', '.join(low_text_pages)} contain fewer than "
            f"{settings.min_page_characters} extracted characters. They may be blank or "
            "image-based; inspect the original. OCR is not implemented."
        )
    content_hash = sha256(content).hexdigest()
    return SourceDocument(
        document_id=content_hash[:24],
        filename=name,
        content_hash=content_hash,
        pages=pages,
        source=source,
        processing_warnings=warnings,
    )


def _pdf_pages(content: bytes, settings: Settings) -> list[SourcePage]:
    try:
        with pymupdf.open(stream=content, filetype="pdf") as document:
            if document.needs_pass:
                raise ValueError("Password-protected PDFs are not supported.")
            if document.page_count > settings.max_pdf_pages:
                raise ValueError("The PDF exceeds the configured page limit.")
            pages = []
            total_characters = 0
            for index, page in enumerate(document):
                text = page.get_text()
                total_characters += len(text)
                if total_characters > settings.max_document_characters:
                    raise ValueError("The PDF exceeds the extracted text limit.")
                pages.append(SourcePage(number=index + 1, text=text))
            return pages
    except (pymupdf.FileDataError, pymupdf.EmptyFileError, RuntimeError):
        raise ValueError("The PDF could not be parsed.") from None
