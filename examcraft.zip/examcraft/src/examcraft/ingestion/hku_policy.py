import re
from typing import Literal
from urllib.parse import urlsplit

HKUSource = Literal["hku_exambase", "hku_moodle"]
HKU_SOURCE_LABELS: dict[HKUSource, str] = {
    "hku_exambase": "HKU ExamBase",
    "hku_moodle": "HKU Moodle",
}


def validate_hku_entry_url(url: str) -> str:
    parsed = urlsplit(url)
    hostname = parsed.hostname or ""
    if (
        parsed.scheme != "https"
        or re.fullmatch(r"[a-z0-9.-]+", hostname) is None
        or not (hostname == "hku.hk" or hostname.endswith(".hku.hk"))
        or parsed.username is not None
        or parsed.password is not None
        or parsed.port not in (None, 443)
        or parsed.fragment
    ):
        raise ValueError(
            "HKU connectors require an HTTPS hku.hk URL without credentials or fragments."
        )
    return url
