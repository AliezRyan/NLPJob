import asyncio
import ipaddress
import socket
from urllib.parse import urlsplit

from playwright.async_api import Error as PlaywrightError
from playwright.async_api import async_playwright

from examcraft.config import Settings
from examcraft.ingestion.hku_policy import HKU_SOURCE_LABELS, HKUSource, validate_hku_entry_url
from examcraft.schemas.intake import MaterialInput


class HKUCollectionError(ValueError):
    pass


def configured_hku_sources(settings: Settings) -> dict[HKUSource, str]:
    sources: dict[HKUSource, str] = {}
    if settings.hku_exambase_entry_url:
        sources["hku_exambase"] = settings.hku_exambase_entry_url
    if settings.hku_moodle_entry_url:
        sources["hku_moodle"] = settings.hku_moodle_entry_url
    return sources


def validate_hku_url(url: str, allowed_hosts: tuple[str, ...]) -> None:
    validate_hku_entry_url(url)
    parsed = urlsplit(url)
    hostname = parsed.hostname
    if hostname is None or hostname not in allowed_hosts:
        raise ValueError("The destination is outside this configured HKU connector.")
    _public_addresses(hostname)


def _public_addresses(hostname: str) -> list[str]:
    try:
        records = socket.getaddrinfo(hostname, 443, type=socket.SOCK_STREAM)
    except OSError:
        raise ValueError("The source hostname could not be resolved.") from None
    addresses = list(dict.fromkeys(record[4][0] for record in records))
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise ValueError("Source hosts must resolve only to public IP addresses.")
    return addresses


async def _collect_hku_page(source: HKUSource, settings: Settings) -> MaterialInput:
    if source not in HKU_SOURCE_LABELS:
        raise HKUCollectionError("Only custom HKU ExamBase and Moodle connectors are available.")
    entries = configured_hku_sources(settings)
    if source not in entries:
        raise HKUCollectionError("The HKU entry URL is not configured. Use manual upload.")
    url = entries[source]
    hostname = urlsplit(url).hostname
    if hostname is None:
        raise HKUCollectionError("The configured HKU entry URL has no hostname.")
    allowed_hosts = (hostname,)
    validate_hku_url(url, allowed_hosts)
    mappings = []
    for host in allowed_hosts:
        addresses = _public_addresses(host)
        address = next((address for address in addresses if ":" not in address), addresses[0])
        target = f"[{address}]" if ":" in address else address
        mappings.append(f"MAP {host} {target}")
    mappings.append("MAP * ~NOTFOUND")
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            args=[
                "--no-proxy-server",
                "--host-resolver-rules=" + ", ".join(mappings),
            ]
        )
        try:
            context = await browser.new_context(
                java_script_enabled=False,
                accept_downloads=False,
                service_workers="block",
            )
            page = await context.new_page()
            session = await context.new_cdp_session(page)
            request_count = 0
            received_bytes = 0

            async def guard(event: dict) -> None:
                nonlocal request_count
                request_count += 1
                try:
                    validate_hku_url(event["request"]["url"], allowed_hosts)
                    if (
                        event["resourceType"] != "Document"
                        or event["request"]["method"] != "GET"
                        or request_count > 12
                    ):
                        raise ValueError("Request is outside the collection policy.")
                except ValueError:
                    await session.send(
                        "Fetch.failRequest",
                        {
                            "requestId": event["requestId"],
                            "errorReason": "BlockedByClient",
                        },
                    )
                    return
                await session.send("Fetch.continueRequest", {"requestId": event["requestId"]})

            async def count_bytes(event: dict) -> None:
                nonlocal received_bytes
                received_bytes += event["dataLength"]
                if received_bytes > settings.max_file_bytes:
                    await session.send("Page.stopLoading")

            session.on("Fetch.requestPaused", guard)
            session.on("Network.dataReceived", count_bytes)
            await session.send("Network.enable")
            await session.send(
                "Fetch.enable",
                {
                    "patterns": [
                        {"urlPattern": "*", "requestStage": "Request"},
                    ]
                },
            )
            page.set_default_timeout(settings.collection_timeout_seconds * 1000)
            response = await page.goto(url, wait_until="domcontentloaded")
            if received_bytes > settings.max_file_bytes:
                raise ValueError("The page exceeds the download size limit.")
            validate_hku_url(page.url, allowed_hosts)
            if response is not None and response.status in {401, 403}:
                raise HKUCollectionError(
                    "HKU authentication is deferred. Upload an authorized copy."
                )
            if response is None or response.status >= 400:
                raise HKUCollectionError("The configured HKU source did not return a usable page.")
            if "text/html" not in response.headers.get("content-type", ""):
                raise HKUCollectionError(
                    "This HKU adapter currently supports configured public HTML pages only. "
                    "Exam PDF downloads and source-specific navigation are deferred."
                )
            if (
                await page.locator("input[type=password]").count()
                or "/login/" in urlsplit(page.url).path.casefold()
            ):
                raise HKUCollectionError(
                    "HKU authentication is deferred. Upload an authorized copy."
                )
            text = await page.locator("body").inner_text()
            if not text.strip() or len(text) > settings.max_document_characters:
                raise HKUCollectionError(
                    "The HKU page is empty or exceeds the extracted text limit."
                )
            return MaterialInput(
                filename=f"{source}.txt",
                content=text.encode("utf-8"),
                source="playwright",
                source_connector=source,
                source_url=page.url,
            )
        finally:
            await browser.close()


def collect_hku_page(source: HKUSource, settings: Settings) -> MaterialInput:
    loop_factory = getattr(asyncio, "ProactorEventLoop", asyncio.new_event_loop)
    try:
        with asyncio.Runner(loop_factory=loop_factory) as runner:
            return runner.run(
                asyncio.wait_for(
                    _collect_hku_page(source, settings),
                    timeout=settings.collection_timeout_seconds + 10,
                )
            )
    except (PlaywrightError, TimeoutError):
        raise HKUCollectionError(
            "HKU collection failed. Authentication, site navigation and PDF downloads are "
            "deferred; use manual upload or check the configured public HKU entry."
        ) from None
