"""Application-owned connectors; Playwright is restricted to HKU."""
