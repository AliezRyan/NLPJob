"""Upload parsing and application-controlled browser connectors."""
