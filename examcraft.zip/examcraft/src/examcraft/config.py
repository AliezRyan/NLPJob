from pathlib import Path

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from examcraft.ingestion.hku_policy import validate_hku_entry_url

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env", env_file_encoding="utf-8", extra="ignore"
    )

    openrouter_api_key: SecretStr = SecretStr("")
    openrouter_model: str = "openai/gpt-4.1-mini"
    model_timeout_seconds: int = Field(default=45, ge=5, le=120)
    max_output_tokens: int = Field(default=1200, ge=100, le=4000)
    max_prompt_characters: int = Field(default=16_000, ge=1000, le=40_000)
    max_planning_steps: int = Field(default=4, ge=2, le=8)
    max_collection_steps: int = Field(default=3, ge=1, le=4)
    max_processing_steps: int = Field(default=3, ge=2, le=5)
    max_ai_requests: int = Field(default=24, ge=1, le=100)
    max_ai_tokens: int = Field(default=100_000, ge=1000, le=2_000_000)
    max_retrieval_requests: int = Field(default=2, ge=1, le=4)
    retrieval_chunk_characters: int = Field(default=1200, ge=200, le=4000)
    retrieval_limit: int = Field(default=8, ge=1, le=40)
    min_page_characters: int = Field(default=50, ge=1, le=1000)
    max_files: int = Field(default=10, ge=1, le=20)
    max_file_bytes: int = Field(default=10 * 1024 * 1024, ge=1, le=20 * 1024 * 1024)
    max_pdf_pages: int = Field(default=100, ge=1, le=200)
    max_document_characters: int = Field(default=100_000, ge=1, le=100_000)
    hku_exambase_entry_url: str | None = None
    hku_moodle_entry_url: str | None = None
    collection_timeout_seconds: int = Field(default=20, ge=1, le=60)

    @field_validator("hku_exambase_entry_url", "hku_moodle_entry_url")
    @classmethod
    def check_hku_entry(cls, value: str | None) -> str | None:
        if value is None or not value.strip():
            return None
        return validate_hku_entry_url(value.strip())
