from typing import Literal, Self

from pydantic import Field, model_validator

from examcraft.schemas.models import Blueprint, Contract, DocumentMetadata, ExamRequest


class SourceChunk(Contract):
    chunk_id: str
    document_id: str
    page_number: int = Field(ge=1)
    text: str = Field(min_length=1, max_length=4000)


class SourceSummary(Contract):
    document_id: str
    filename: str
    page_count: int = Field(ge=1)
    processing_warnings: list[str]
    proposed_metadata: DocumentMetadata | None = None
    processing_mode: Literal["unclassified", "demo", "ai"] = "unclassified"


class PlanningContext(Contract):
    request: ExamRequest
    sources: list[SourceSummary]
    evidence: list[SourceChunk]
    feedback: list[str]
    remaining_steps: int = Field(ge=0)
    remaining_retrievals: int = Field(ge=0)


class PlanningDecision(Contract):
    action: Literal["retrieve", "draft", "stop"]
    reason: str = Field(min_length=1, max_length=500)
    query: str | None = Field(max_length=300)
    blueprint: Blueprint | None

    @model_validator(mode="after")
    def check_action_fields(self) -> Self:
        if self.action == "draft" and self.blueprint is None:
            raise ValueError("A draft decision requires a blueprint.")
        if self.action != "draft" and self.blueprint is not None:
            raise ValueError("Only a draft decision may contain a blueprint.")
        if self.action != "retrieve" and self.query is not None:
            raise ValueError("Only a retrieval decision may contain a query.")
        if not self.reason.strip() or (self.query is not None and not self.query.strip()):
            raise ValueError("Decision reasons and search queries cannot be blank.")
        return self


class PlannerTurn(Contract):
    decision: PlanningDecision
    input_tokens: int | None = Field(ge=0)
    output_tokens: int | None = Field(ge=0)


class RunEvent(Contract):
    stage: Literal["collection", "processing", "planner", "retrieval", "validation", "stop"]
    outcome: str
    elapsed_ms: float | None = Field(default=None, ge=0)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
