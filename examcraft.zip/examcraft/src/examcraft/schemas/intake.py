from dataclasses import dataclass
from hashlib import sha256
from typing import Generic, Literal, Self, TypeVar

from pydantic import Field, model_validator

from examcraft.ingestion.hku_policy import HKUSource
from examcraft.schemas.models import Contract, DocumentMetadata, SourcePage

DecisionT = TypeVar("DecisionT", bound=Contract)


@dataclass(frozen=True)
class MaterialInput:
    filename: str
    content: bytes
    source: Literal["upload", "playwright", "sample"] = "upload"
    source_connector: HKUSource | None = None
    source_url: str | None = None

    @property
    def content_hash(self) -> str:
        return sha256(self.content).hexdigest()


@dataclass(frozen=True)
class AgentTurn(Generic[DecisionT]):
    decision: DecisionT
    input_tokens: int | None
    output_tokens: int | None


class CollectionContext(Contract):
    course_code: str
    requested: list[HKUSource]
    available: list[HKUSource]
    attempted: list[HKUSource]
    observations: list[str]
    remaining_steps: int = Field(ge=0)


class CollectionDecision(Contract):
    action: Literal["collect", "finish"]
    connector: HKUSource | None
    reason: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def check_connector(self) -> Self:
        if not self.reason.strip():
            raise ValueError("A collection decision requires a non-blank reason.")
        if (self.action == "collect") != (self.connector is not None):
            raise ValueError("Only a collect decision requires an HKU connector.")
        return self


class ProcessingContext(Contract):
    filename: str
    media_type: Literal["pdf", "text"]
    extracted: bool
    page_excerpts: list[SourcePage]
    warnings: list[str]
    feedback: list[str]
    remaining_steps: int = Field(ge=0)


class ProcessingDecision(Contract):
    action: Literal["extract", "finish", "stop"]
    tool: Literal["pymupdf", "utf8", "ocr"] | None
    metadata: DocumentMetadata | None
    reason: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def check_action(self) -> Self:
        if not self.reason.strip():
            raise ValueError("A processing decision requires a non-blank reason.")
        if (self.action == "extract") != (self.tool is not None):
            raise ValueError("Only extraction decisions require a tool.")
        if (self.action == "finish") != (self.metadata is not None):
            raise ValueError("Only finish decisions require classification metadata.")
        return self
