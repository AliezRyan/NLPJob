"""Shared contracts; coordinate changes with downstream module owners."""
