from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from examcraft.ingestion.hku_policy import HKUSource


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SourcePage(Contract):
    number: int = Field(ge=1)
    text: str = Field(max_length=100_000)


class DocumentMetadata(Contract):
    document_type: Literal[
        "lecture_notes", "past_exam", "mark_scheme", "syllabus", "other", "unknown"
    ]
    title: str | None = Field(max_length=200)
    author: str | None = Field(max_length=200)
    year: int | None = Field(ge=1, le=9999)
    topics: list[str] = Field(max_length=12)
    summary: str = Field(max_length=1200)


class SourceDocument(Contract):
    document_id: str
    filename: str = Field(min_length=1, max_length=255)
    content_hash: str
    pages: list[SourcePage] = Field(min_length=1)
    source: Literal["upload", "playwright", "sample"] = "upload"
    source_url: str | None = None
    source_connector: HKUSource | None = None
    metadata: DocumentMetadata | None = None
    processing_mode: Literal["unclassified", "demo", "ai"] = "unclassified"
    processing_warnings: list[str] = Field(default_factory=list)


class ExamRequest(Contract):
    course_code: str = Field(min_length=1, max_length=100)
    duration_minutes: int = Field(default=60, ge=5, le=240)
    total_marks: int = Field(default=100, ge=1, le=300)


class Blueprint(Contract):
    title: str = Field(min_length=1, max_length=200)
    topics: list[str] = Field(min_length=1, max_length=12)
    objective_marks: int = Field(ge=0)
    analytical_marks: int = Field(ge=0)
    source_document_ids: list[str] = Field(min_length=1)
    notes: str = Field(max_length=2000)

    def validate_against(self, request: ExamRequest, selected_ids: list[str]) -> None:
        if self.objective_marks + self.analytical_marks != request.total_marks:
            raise ValueError("Blueprint marks must equal the requested total.")
        if set(self.source_document_ids) != set(selected_ids):
            raise ValueError("Blueprint sources must match the selected materials.")


class WriterTask(Contract):
    role: Literal["writer_objective", "writer_analytical"]
    marks: int = Field(ge=0)
    question_types: list[str]
    source_document_ids: list[str]
    status: Literal["not_implemented"] = "not_implemented"
