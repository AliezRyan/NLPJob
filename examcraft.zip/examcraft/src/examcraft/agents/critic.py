from examcraft.graph.state import WorkflowState


def review_questions(state: WorkflowState) -> dict:
    """Extension point: add independent solving and structured pass/repair/reject decisions."""
    return {"review_status": "not_implemented"}
