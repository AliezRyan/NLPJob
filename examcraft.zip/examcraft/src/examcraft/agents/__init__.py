"""Logical agent roles; deterministic controls remain outside model prompts."""
