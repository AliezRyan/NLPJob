from examcraft.graph.state import WorkflowState


def assemble_exams(state: WorkflowState) -> dict:
    """Extension point: repair versioned questions and assemble only approved versions."""
    return {"ready_for_export": False, "status": "baseline_ready"}
