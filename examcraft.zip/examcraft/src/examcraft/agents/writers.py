from examcraft.graph.state import WorkflowState
from examcraft.schemas.models import WriterTask


def write_objective(state: WorkflowState) -> dict:
    """Extension point: replace task handoff with grounded objective question generation."""
    return {
        "writer_tasks": [
            WriterTask(
                role="writer_objective",
                marks=state["blueprint"].objective_marks,
                question_types=["multiple_choice", "true_false", "short_answer"],
                source_document_ids=state["selected_ids"],
            )
        ]
    }


def write_analytical(state: WorkflowState) -> dict:
    """Extension point: replace task handoff with grounded analytical question generation."""
    return {
        "writer_tasks": [
            WriterTask(
                role="writer_analytical",
                marks=state["blueprint"].analytical_marks,
                question_types=["essay", "calculation", "case_study"],
                source_document_ids=state["selected_ids"],
            )
        ]
    }
