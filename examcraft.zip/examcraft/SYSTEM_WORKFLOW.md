# ExamCraft full system workflow

ExamCraft helps a teacher or student turn permitted course materials into a
source-grounded exam, review it, and use it for temporary self-study practice.
This document shows who requests, proposes, validates and approves each action.

<!-- workflow-status: AI intake and planning roles are implemented. Playwright collection is HKU ExamBase/Moodle only. Entry URLs remain unconfigured; authentication, site navigation and exam-PDF downloads are deferred. Question generation, final approval, exam export and practice remain planned. -->

**Visual version:** [Open the offline workflow diagrams](SYSTEM_WORKFLOW.html).  
**Delivery roadmap:** [12-step implementation plan](plan.md).

## 1. Read this distinction first

- **Current:** early consent, queued manual uploads, bounded Source Collector and
  Document Processor roles, registered parser tools, proposed metadata, source review,
  bounded planning/retrieval, draft gates, blueprint download, traces and reset/cleanup.
- **HKU collection boundary:** only custom ExamBase/Moodle connectors may use
  Playwright. Other sources are manual-upload only. Entry URLs are deliberately blank;
  authentication, live site navigation and exam-PDF downloads will be designed later.
- **Target:** the complete workflow below includes question generation, independent
  critique, repair, final approval, exam export and practice. These are not yet
  implemented; Writer/Critic/Editor nodes remain placeholders.
- **Demo is not an AI model:** it deterministically chooses configured HKU connectors,
  selects PDF/TXT parsers and preserves unknown semantic metadata, then requests an
  overview and drafts a fixed allocation. OpenRouter uses models for all three roles.
- Passing the current blueprint gate does not establish factual correctness.
  Every current terminal path has `ready_for_export=False`.

### Authority and ownership

| Participant | Owns or decides | Must not do |
| --- | --- | --- |
| Human teacher/student | Material permissions, selected sources, request settings, provider-sharing consent, final acceptance, practice answers and closing the run | Override a failed hard gate or make generated material an official assessment merely by approving it |
| AI roles | Propose collection intent, metadata, plans, questions, independent solutions, critiques, permitted repairs, assembly choices and optional learning feedback | Change permissions, source eligibility, budgets, retry limits, deterministic marks or objective scores |
| System runtime and tools | Validate proposals, execute allowlisted tools, preserve state/evidence, route decisions, enforce limits, render artifacts, enforce time and compute objective marks | Treat model output as trusted authorization or expose an answer key in student-facing content |
| Independent evaluator/instructor | Label evaluation cases, review correctness/support, calibrate rubrics and assess measured results | Use the application's own Critic as the only reference for its quality claims |

The UI carries human actions to the runtime. An AI-to-system arrow is a proposed
action, not direct permission to execute a browser, shell, file operation or export.
AI roles may share a model; they do not require separate commercial models.

## 2. Full target overview

**Blue = HUMAN, purple = AI, green = SYSTEM, red = controlled stop.**
Color represents responsibility, not implementation status. All downstream exam
and practice stages in this overview are target behavior.

<!-- mermaid-checked: no \n, no em-dash/en-dash, no {} in labels, subgraphs are id["label"], arrows are -->|"label"|, all subgraphs closed by end, ids unique -->
```mermaid
flowchart TD
    subgraph TvMaterials["1 Materials and human consent"]
        direction LR
        TvInputs["H1 Queue files or request HKU and give consent"]
        TvHku["S Check HKU configuration and execute allowed tools"]
        TvCollect["AI Source Collector chooses HKU connector"]
        TvProcess["AI Document Processor chooses tools and metadata"]
        TvIntake["S1 Extract validate and preserve source evidence"]
        TvReview["H2 Review evidence and confirm selected scope"]
        TvInputs -->|"manual upload"| TvProcess
        TvInputs -->|"HKU request"| TvHku
        TvHku -->|"configured connector catalog"| TvCollect
        TvCollect -->|"typed HKU action"| TvHku
        TvHku -->|"usable material"| TvProcess
        TvHku -->|"no entry or login required"| TvInputs
        TvProcess -->|"extract or finish request"| TvIntake
        TvIntake -->|"tool observations"| TvProcess
        TvIntake -->|"validated canonical data"| TvReview
    end
    subgraph TvConstruction["2 Evidence and agentic exam construction"]
        direction LR
        TvContext["S2 Select evidence and enforce run budgets"]
        TvGenerate["A1 Planner and two Writers propose content"]
        TvQuestionGates["S3 Check question contracts and hard rules"]
        TvReviewLoop["A2 Critic and Editor review repair and assemble"]
        TvContext --> TvGenerate --> TvQuestionGates --> TvReviewLoop
        TvGenerate -->|"retrieve evidence"| TvContext
        TvReviewLoop -->|"repair and validate again"| TvQuestionGates
        TvReviewLoop -->|"replace or replan"| TvGenerate
    end
    subgraph TvApprovalStage["3 Final audit and human approval"]
        direction LR
        TvExamGates["S4 Check assembled exam hard rules"]
        TvFinalAudit["A3 Critic independently audits the whole exam"]
        TvRank["S5 Rank passing exams from validated inputs"]
        TvApprove["H3 Review audited exams and decide"]
        TvExamGates --> TvFinalAudit --> TvRank --> TvApprove
    end
    subgraph TvPracticeStage["4 Approved delivery and temporary practice"]
        direction LR
        TvExport["S6 Export separate student and answer files"]
        TvPractice["H4 Select a practice exam and answer"]
        TvGrade["S7 Enforce deadline and grade objective answers"]
        TvFeedback["A4 Optional formative learning feedback"]
        TvExport --> TvPractice --> TvGrade
        TvGrade -.->|"optional"| TvFeedback
    end
    subgraph TvFinishStage["5 Outcome review and cleanup"]
        direction LR
        TvFinish["H5 Read the outcome and close the run"]
        TvCleanup["S8 Delete owned run data and checkpoints"]
        TvFinish --> TvCleanup
    end
    TvStop["STOP Report failure without approving an exam"]
    TvMaterials -->|"selected sources and consent"| TvConstruction
    TvConstruction -->|"eligible assembled candidates"| TvApprovalStage
    TvApprovalStage -->|"audited exam and human approval"| TvPracticeStage
    TvPracticeStage -->|"results and feedback or fallback"| TvFinishStage
    TvConstruction -->|"unrecoverable failure or limits"| TvStop
    TvApprovalStage -->|"unrecoverable failure or rejection"| TvStop
    TvStop --> TvFinishStage
    classDef tvHuman fill:#dbeafe,stroke:#2563eb,color:#172554
    classDef tvAi fill:#f3e8ff,stroke:#9333ea,color:#3b0764
    classDef tvSystem fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef tvStopped fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    class TvInputs,TvReview,TvApprove,TvPractice,TvFinish tvHuman
    class TvCollect,TvProcess,TvGenerate,TvReviewLoop,TvFinalAudit,TvFeedback tvAi
    class TvHku,TvIntake,TvContext,TvQuestionGates,TvExamGates,TvRank,TvExport,TvGrade,TvCleanup tvSystem
    class TvStop tvStopped
```

The overview groups the journey by phase to keep ownership handoffs readable.
The detailed sequences below include final-audit correction, targeted regeneration,
optional collection and feedback fallback without crossing the overview with every
exception arrow. The runtime owns every loop and branch. Repair returns to validation;
rejection requests a replacement from the original Writer; broader failures return
to the Planner. Assembly never edits a question. Any stage may stop or be cancelled;
no failure route may bypass approval or deliver an unchecked exam.

## 3. Stage-by-stage interaction and implementation status

| Stage | Human interaction | AI contribution | System action and output | Status |
| --- | --- | --- | --- | --- |
| 1. Queue and authorize | Queue uploads, optionally request HKU sources and authorize external AI intake before it starts | No external call before consent | Create run/workspace and check HKU connector configuration | Available; URLs intentionally unconfigured and login deferred |
| 2. Collect and process | Supply uploads when HKU is unavailable; inspect originals and warnings | Source Collector chooses a configured HKU connector; Document Processor requests parsers and proposes metadata | Execute only HKU public-entry tools or PDF/TXT parsers; store canonical data/provenance | Bounded agents and parsing available; live HKU navigation/PDF downloads and OCR deferred |
| 3. Review and confirm | Select processed materials and confirm the planning-sharing scope | None required | Pause at review; validate selected IDs; restrict later context | Available; richer exam settings planned |
| 4. Plan and retrieve | Observe progress or start a new run | Choose retrieve, draft or stop from observations and feedback | Execute selected-source retrieval; validate drafts; enforce planning/retrieval limits | Available planning foundation |
| 5. Generate and correct | No approval needed for each internal revision | Writers generate; Critic solves independently; Editor repairs criticized fields | Merge versions; run hard gates; route pass/repair/reject/replan under shared budgets | Planned; existing nodes are placeholders |
| 6. Assemble and approve | Inspect coverage, evidence, audits and warnings; approve/reject/request one regeneration | Editor assembles; Critic audits whole papers | Validate combinations, rank passing exams and block approval of failed papers | Planned |
| 7. Export | Download approved student paper and separate key | No executable AI-generated layout | Produce versioned JSON and controlled-template PDFs; validate artifacts | Only draft blueprint JSON available; exam export blocked |
| 8. Practice and results | Choose exam, save answers, submit, read feedback | Optional post-submission formative feedback | Enforce server deadline; freeze answers; grade objective items; separate pending review marks | Planned |
| 9. Finish and clean up | Finish/cancel/reset after downloads/results | No retention decision or extra permission | Remove run-owned files, thread and active-attempt state; expire abandoned runs | Explicit reset/close available; completion/TTL/supervisor lifecycle planned |

## 4. Detailed target interaction sequences

These are logical components inside the proposed application, not separate
microservices or a requirement to add a database/message broker.

### 4.1 Intake, source review and sharing consent

The Source Collector and Document Processor now exist. External-model consent is
checked before collection planning or classification, not after those calls.
Every non-HKU source uses manual upload. The two HKU entry URLs remain unconfigured,
so no live HKU collection occurs until approved values are prepared. Authentication
is deferred; no sign-in/MFA step or credential handling is implemented.

<!-- mermaid-checked: every participant uses `participant Id as "Label"`, no \n in aliases/messages/notes, every alt/opt/loop closed by end, no `:` inside any alias -->
```mermaid
sequenceDiagram
    participant InHuman as "HUMAN - teacher or student"
    participant InUi as "SYSTEM - user interface"
    participant InRuntime as "SYSTEM - run controller"
    participant InTools as "SYSTEM - permitted processing tools"
    participant InCollectAi as "AI - Source Collector"
    participant InProcessAi as "AI - Document Processor"
    participant InStore as "SYSTEM - temporary workspace"
    InHuman->>InUi: Queue permitted files and optionally request HKU sources
    InUi->>InRuntime: Start one temporary run
    InRuntime->>InStore: Create isolated run workspace
    opt External AI mode
        InUi->>InHuman: Explain intake data sharing and request consent
        InHuman->>InUi: Authorize sharing queued inputs with the provider
        InUi->>InRuntime: Check consent before any external model call
    end
    opt HKU ExamBase or Moodle requested
        InRuntime->>InTools: Check the configured HKU connector catalog
        InTools-->>InRuntime: Return available entries or not-configured status
        opt A requested HKU entry is configured
            InRuntime->>InCollectAi: Supply course requested connectors and observations
            InCollectAi-->>InRuntime: Choose a registered HKU connector or finish
            InRuntime->>InTools: Validate and execute only that HKU connector
            InTools-->>InRuntime: Return public material or explicit upload fallback
        end
        opt Missing entry or authentication-required page
            InRuntime-->>InUi: Offer upload fallback
            InHuman->>InUi: Upload permitted source files
            InUi->>InRuntime: Queue inputs for the next intake attempt
        end
    end
    loop Bounded processing decisions for each queued input
        InRuntime->>InProcessAi: Supply file type excerpts feedback and remaining limits
        alt Extract
            InProcessAi-->>InRuntime: Request an approved parser or OCR
            InRuntime->>InTools: Check tool and run parser or report unavailable OCR
            InTools-->>InRuntime: Return original page evidence and quality warnings
        else Finish
            InProcessAi-->>InRuntime: Propose normalized classification metadata
            InRuntime->>InTools: Validate extraction exists and check metadata shape
            InTools-->>InRuntime: Return canonical material or rejection feedback
        else Stop
            InProcessAi-->>InRuntime: Explain why another upload is required
        end
    end
    alt At least one usable document remains
        InRuntime->>InStore: Save canonical evidence with provenance
        InRuntime-->>InUi: Pause and show source review
        InUi->>InHuman: Show previews warnings and request settings
        InHuman->>InUi: Select processed sources and confirm planning scope
        InUi->>InRuntime: Validate selection and resume the same thread
        InRuntime->>InStore: Record selected evidence scope
    else No usable evidence remains
        InRuntime-->>InUi: Request replacement input or stop explicitly
    end
```

### 4.2 Planning, parallel generation and correction

Question-level decisions belong to the Critic; execution authority belongs to the
runtime. A repair creates a new version and re-enters hard gates. A replan exits the
local review cycle and returns to the planning/generation phase with failure evidence.

<!-- mermaid-checked: every participant uses `participant Id as "Label"`, no \n in aliases/messages/notes, every alt/opt/loop closed by end, no `:` inside any alias -->
```mermaid
sequenceDiagram
    participant GenRuntime as "SYSTEM - graph runtime"
    participant GenSources as "SYSTEM - selected-source retrieval"
    participant GenPlanner as "AI - Planner"
    participant GenWriterA as "AI - objective Writer"
    participant GenWriterB as "AI - analytical Writer"
    participant GenGates as "SYSTEM - deterministic validators"
    participant GenCritic as "AI - independent Critic"
    participant GenEditor as "AI - Editor Selector"
    loop Bounded planning decisions
        GenRuntime->>GenPlanner: Supply selected context observations feedback and limits
        alt Retrieve
            GenPlanner-->>GenRuntime: Propose an evidence query
            GenRuntime->>GenSources: Validate scope and execute retrieval
            GenSources-->>GenRuntime: Return cited chunks or a no-match observation
        else Draft
            GenPlanner-->>GenRuntime: Propose blueprint and task allocation
            GenRuntime->>GenGates: Check allocation and evidence requirements
            GenGates-->>GenRuntime: Accept or return validation feedback
        else Stop
            GenPlanner-->>GenRuntime: Explain insufficient evidence
        end
    end
    Note over GenRuntime,GenPlanner: Accepted drafts exit to validation and stop exits to controlled failure
    alt Blueprint accepted and budgets remain
        par Objective branch
            GenRuntime->>GenWriterA: Supply assigned tasks and relevant evidence
            GenWriterA-->>GenRuntime: Return proposed objective questions and answers
        and Analytical branch
            GenRuntime->>GenWriterB: Supply assigned tasks and relevant evidence
            GenWriterB-->>GenRuntime: Return proposed analytical questions and rubrics
        end
        loop Bounded question validation and review
            GenRuntime->>GenGates: Check candidate versions references marks and duplicates
            GenGates-->>GenRuntime: Return hard-gate results
            alt Hard gates pass
                GenRuntime->>GenCritic: Supply question and evidence without proposed answer
                GenCritic-->>GenRuntime: Return independent solution
                GenRuntime->>GenCritic: Compare independent solution and Writer answer
                GenCritic-->>GenRuntime: Propose pass repair reject or replan
            else Hard gates fail
                Note over GenRuntime,GenGates: Route deterministic defects without claiming semantic approval
            end
            alt Repair
                GenRuntime->>GenEditor: Supply failed version and allowed repair fields
                GenEditor-->>GenRuntime: Return a new version for validation
            else Reject and replace
                alt Original task was objective
                    GenRuntime->>GenWriterA: Request a replacement within existing limits
                    GenWriterA-->>GenRuntime: Return replacement candidate
                else Original task was analytical
                    GenRuntime->>GenWriterB: Request a replacement within existing limits
                    GenWriterB-->>GenRuntime: Return replacement candidate
                end
            else Replan
                GenRuntime->>GenPlanner: Supply aggregated unsupported-task failures
                GenPlanner-->>GenRuntime: Propose revised allocation without lowering gates
                Note over GenRuntime,GenPlanner: Resume broader generation rather than approving the failed version
            else Pass
                GenRuntime->>GenRuntime: Add the approved version to the pool
            end
        end
        GenRuntime->>GenEditor: Assemble only approved question versions
        GenEditor-->>GenRuntime: Return eligible exam candidates or an explicit shortfall
    else No accepted blueprint or remaining budget
        GenRuntime->>GenRuntime: Stop without approving an exam
    end
```

The target question workflow permits at most two generation rounds and two repairs
per question. Assembly gets one retry; targeted regeneration gets one human request.
All also consume the shared token/cost/deadline budget planned in the roadmap.
These are target question limits, not the current planner's four-turn/two-retrieval limits.

### 4.3 Final approval, delivery, practice and cleanup

This sequence starts only when eligible assembled candidates exist. Export uses
the exact approved versions; grading uses an immutable answer-key snapshot. The
optional feedback agent cannot alter awarded objective marks.

<!-- mermaid-checked: every participant uses `participant Id as "Label"`, no \n in aliases/messages/notes, every alt/opt/loop closed by end, no `:` inside any alias -->
```mermaid
sequenceDiagram
    participant OutHuman as "HUMAN - teacher or student"
    participant OutUi as "SYSTEM - user interface"
    participant OutSystem as "SYSTEM - runtime and services"
    participant OutCritic as "AI - final Critic"
    participant OutFeedback as "AI - optional learning feedback"
    participant OutStore as "SYSTEM - temporary workspace"
    OutSystem->>OutSystem: Check complete-exam hard gates
    alt Hard gates pass
        OutSystem->>OutCritic: Audit complete paper coverage evidence and leakage
        OutCritic-->>OutSystem: Propose pass repair reassemble or replan
        alt Final audit passes
            OutSystem->>OutSystem: Rank only passing exams
            OutSystem-->>OutUi: Pause for final human approval
            OutUi->>OutHuman: Show papers audits references repairs and warnings
            alt Human approves an eligible version
                OutHuman->>OutUi: Approve the selected paper
                OutUi->>OutSystem: Validate approval against the audited version
                OutSystem->>OutStore: Write separate validated student and answer artifacts
                OutStore-->>OutSystem: Return validated artifacts and hashes
                OutSystem-->>OutUi: Offer separate student and answer-key downloads
                OutHuman->>OutUi: Select a student exam for practice
                OutUi->>OutSystem: Start an immutable attempt with a server deadline
                OutSystem-->>OutUi: Render answer-free exam and informational countdown
                loop While the attempt remains active
                    OutHuman->>OutUi: Enter or save answers
                    OutUi->>OutSystem: Check question membership and server deadline
                    OutSystem->>OutStore: Atomically save accepted answers
                end
                alt Manual submission before deadline
                    OutHuman->>OutUi: Submit attempt
                    OutUi->>OutSystem: Freeze answers and record manual closure
                else Server deadline expires
                    OutSystem->>OutSystem: Supervisor freezes saved answers as expired
                end
                OutSystem->>OutSystem: Grade objective answers and separate pending review marks
                opt Feedback is enabled and budget permits
                    OutSystem->>OutFeedback: Supply graded results rubric and source evidence
                    OutFeedback-->>OutSystem: Return formative comments or a failure
                end
                OutSystem-->>OutUi: Show scores and feedback or labeled answer-key fallback
                OutUi->>OutHuman: Present results and non-official learning feedback
            else Human rejects or requests regeneration
                OutHuman->>OutUi: Reject or request one targeted regeneration
                OutUi->>OutSystem: Stop or return to bounded planning
                Note over OutUi,OutSystem: Regeneration exits delivery and must pass audit and approval again
            end
        else Final audit fails
            OutSystem->>OutSystem: Route bounded repair reassembly or replanning
        end
    else Complete-exam hard gates fail
        OutSystem->>OutSystem: Route bounded correction without requesting approval
    end
    OutHuman->>OutUi: Finish or cancel when ready
    OutUi->>OutSystem: Close the run after downloads and results
    OutSystem->>OutStore: Delete owned run files and thread state
    OutStore-->>OutSystem: Return cleanup outcome
```

Supervisor-driven expiry continues after a client disconnect but not after server
loss in the temporary-storage design. Expiry closes an attempt; it does not pretend
the student manually submitted it. Reconnection, grading and feedback must respect
the frozen attempt. Downloads can be completed without continuing practice; closing
or cancelling still follows the cleanup path.

## 5. Actual working workflow today

This diagram follows the current source, not the unimplemented target stages.
The graph now executes collection and processing before its review interrupt.
Manual uploads are queued in memory first, and external sharing is authorized
before upstream AI runs. Configured-entry HKU adapter code is available for offline
fixtures, but both live entry URLs remain blank and login is deferred.

<!-- mermaid-checked: no \n, no em-dash/en-dash, no {} in labels, subgraphs are id["label"], arrows are -->|"label"|, all subgraphs closed by end, ids unique -->
```mermaid
flowchart LR
    CvInput["H Queue uploads or request HKU sources"]
    CvConsent["H Give external AI consent before intake"]
    CvCollection["AI Source Collector chooses HKU connector"]
    CvHku["S HKU-only tool or explicit upload fallback"]
    CvProcessing["AI Document Processor chooses tools and metadata"]
    CvIntake["S Parse original evidence and return warnings"]
    CvCanonical["S Validate and store canonical data"]
    CvPause["S Pause at material review"]
    CvSelect["H Review processed sources and confirm planning scope"]
    CvContext["S Build selected context and check turn limits"]
    CvPlanner["AI Planner or Demo chooses retrieve draft or stop"]
    CvRetrieve["S Retrieve selected evidence with page and chunk IDs"]
    CvGate["S Check marks sources and evidence presence"]
    CvStubs["S Writer handoffs then placeholder Critic and Editor"]
    CvDraft["S Show draft and private planning trace"]
    CvRead["H Read or download draft blueprint only"]
    CvStop["STOP No exam is approved"]
    CvReadStop["H Read stop reason and trace"]
    CvReset["H Choose New run"]
    CvCleanup["S Delete owned workspace and graph thread"]
    CvInput --> CvConsent
    CvConsent -->|"manual files"| CvProcessing
    CvConsent -->|"HKU requested"| CvHku
    CvHku -->|"configured requested source"| CvCollection
    CvCollection -->|"typed connector choice"| CvHku
    CvHku -->|"collected or queued material"| CvProcessing
    CvHku -->|"no entry and no usable upload"| CvStop
    CvProcessing -->|"approved extraction request"| CvIntake
    CvIntake -->|"evidence and tool feedback"| CvProcessing
    CvProcessing -->|"finish with proposed metadata"| CvCanonical
    CvCanonical -->|"usable documents remain"| CvPause
    CvCanonical -->|"no usable documents"| CvStop
    CvPause --> CvSelect
    CvSelect --> CvContext
    CvContext --> CvPlanner
    CvPlanner -->|"retrieve"| CvRetrieve
    CvRetrieve -->|"evidence or no-match feedback"| CvContext
    CvPlanner -->|"draft"| CvGate
    CvGate -->|"rejected draft feedback"| CvContext
    CvGate -->|"accepted allocation only"| CvStubs
    CvStubs --> CvDraft
    CvDraft --> CvRead
    CvPlanner -->|"stop or provider failure"| CvStop
    CvContext -->|"turn limit"| CvStop
    CvRetrieve -->|"quota repeat or no turn left"| CvStop
    CvGate -->|"invalid at final turn"| CvStop
    CvStop --> CvReadStop
    CvRead --> CvReset
    CvReadStop --> CvReset
    CvReset --> CvCleanup
    CvCleanup --> CvInput
    classDef cvHuman fill:#dbeafe,stroke:#2563eb,color:#172554
    classDef cvSystem fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef cvDecision fill:#f3e8ff,stroke:#9333ea,color:#3b0764
    classDef cvStopped fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    class CvInput,CvConsent,CvSelect,CvRead,CvReadStop,CvReset cvHuman
    class CvHku,CvIntake,CvCanonical,CvPause,CvContext,CvRetrieve,CvGate,CvStubs,CvDraft,CvCleanup cvSystem
    class CvCollection,CvProcessing,CvPlanner cvDecision
    class CvStop cvStopped
```

Current defaults: three collection decisions, three processing decisions per input,
four planner decisions, two executed retrieval requests and a 16,000-character
evidence allowance. All external roles share 24 HTTP attempts and 100,000 accounted
tokens. One transient retry is allowed and consumes another attempt; SDK retries
are disabled. Failed/missing usage keeps a conservative reservation.
An identical retrieval request is not repeated. The final planner turn cannot
start retrieval that would leave no turn to use its result.

## 6. Business rules, decisions and recovery

| Rule | Enforcement owner | Required outcome |
| --- | --- | --- |
| Material permission and provider consent | Human choice checked by system | No provider request before sharing consent; no model access to credentials |
| HKU-only browser scope | System, implemented | Only configured ExamBase/Moodle connector names may launch Playwright; other sources are manual uploads |
| Source eligibility | System | Filter selected/authorized evidence before ranking; keep held-out benchmarks out of generation |
| Evidence provenance | System and AI proposal contract | Preserve document/page/chunk links; cited evidence must support its nearby claim |
| Current draft gate | System, implemented | Exact total marks, matching selected IDs and evidence presence; no semantic approval claim |
| Question and exam hard gates | System, planned | Reject invalid marks/options/references/versions, duplicates and answer leakage before approval |
| Semantic review | AI Critic plus independent evaluation | Solve before seeing Writer answer; assess support, ambiguity, difficulty and rubric sufficiency |
| Repair authority | AI proposal checked by system | Change only criticized fields, increment version, and repeat validation/review |
| Limits and cost | System | Shared request/token accounting and stage limits apply now; currency checks and an overall deadline remain planned |
| Human final approval | System validates human decision | Approval applies only to a passing audited version; one targeted regeneration is allowed |
| Practice scoring | System | Deterministic objective/numeric marks; unsupported essays remain pending review |
| Feedback fallback | System | Failed or unavailable AI feedback cannot change scores; show labeled validated-key guidance |
| Run closure | System after human finish/cancel or expiry policy | Clean only owned artifacts; report cleanup failures and preserve no permanent user history |

Recovery behavior:

- **No usable document:** request another input; do not generate from empty evidence.
- **No search match:** return an observation and let the Planner refine or stop.
- **Invalid draft/question:** return exact gate feedback to the appropriate bounded route.
- **Provider failure:** one transient retry may occur through the shared ledger.
  Intake records an explicit per-file/source warning; if usable inputs remain,
  review can continue. Planning stops explicitly on provider/budget failure.
- **HKU unavailable:** missing entry URLs never launch a browser. Authentication,
  unsupported downloads or denied redirects produce manual-upload guidance.
- **Rejected question:** ask the original Writer for a replacement, not an Editor
  override. Repeated unsupported tasks may require broader replanning.
- **Invalid final exam:** reassemble once, repair or replan; never rank/export a failure.
- **Too few approved questions:** produce only eligible papers or explain why none can
  be produced; do not fill the paper with weak questions.
- **Export failure:** retain the approved immutable exam and allow one bounded export
  retry; do not silently regenerate different content.
- **Late/duplicate submission:** reject late answer changes; repeated submission
  returns the existing result rather than awarding marks again.
- **Restart/disconnect:** current in-memory runs do not survive restart, and current
  reconnection is not guaranteed. Target practice expiry is supervisor-controlled;
  startup/periodic abandoned-workspace cleanup remains planned.

## 7. Domain artifacts and data visibility

| Artifact | Business meaning and relationships | Who may see it |
| --- | --- | --- |
| Source documents and chunks | Evidence supporting extraction, blueprint and questions | Consented bounded excerpts from queued inputs may enter processing before selection; only selected materials enter later planning/generation |
| Proposed source metadata | Classification, topics and summary inferred from bounded extracted evidence | Human review and planning context; marked demo/AI and not treated as verified source evidence |
| Blueprint and tasks | Allocation connecting source coverage to Writer responsibilities | Human, runtime and relevant AI roles |
| Candidate question versions | Proposed questions with answers and marking guidance | System, assigned Writer, Critic comparison pass and permitted Editor repair |
| Independent solution and critique | Review evidence used to approve or correct a version | Runtime, Critic and permitted repair/approval views |
| Approved exam | Immutable references to approved question versions | Runtime and final human reviewer |
| Student exam | Answer-free projection for download and practice | Student browser and permitted rendering services |
| Answer key | Separate answers, explanations, tolerances and rubrics | Authorized teacher/reviewer and server-side grading; never embedded in pre-submission student content |
| Practice attempt and result | Temporary answers, deadline, closure and scoring outcome | Student and system; only needed evidence enters optional feedback context |
| Trace and evaluation evidence | Run decisions/usage versus separate authorized experimental results | Current run owner; authorized independent evaluators for retained benchmark results |

Current storage uses in-memory checkpoints and temporary canonical JSON. It still
checkpoints full document objects; moving large content to references is planned.
No permanent user-history database is needed. A teacher/reviewer may download an
answer key; the student practice view must still exclude answer fields before submission.

## 8. Independent evaluation is a separate workflow

This is planned course-project evidence, not the production Critic approving itself:

1. **Human evaluator:** authorize data, freeze development/held-out splits, and label
   correctness/support with a reviewable rubric.
2. **System harness:** run matched cases through single-prompt, retrieval-only and
   Critic/repair configurations with versioned settings and comparable budgets.
3. **AI systems:** produce answers/questions and traces; their judgments are outputs,
   not the sole ground truth.
4. **System metrics:** aggregate hard-gate success, correctness/support judgments,
   Critic detection precision/recall, latency, calls, tokens, cost and uncertainty.
5. **Human evaluator:** inspect disagreements and failures, accept or reject a design
   change, and explain limitations in the final report.

Only authorized experiment artifacts may be retained. That does not change the
temporary-user-session privacy policy.

## 9. Source and roadmap mapping

| Responsibility | Current code or planned roadmap |
| --- | --- |
| Human screens and consent | [UI](src/examcraft/ui/app.py), [run session](src/examcraft/services/session.py) |
| Upstream AI and permitted tools | [Source Collector](src/examcraft/agents/source_collection.py), [Document Processor](src/examcraft/agents/document_processing.py), [intake runtime](src/examcraft/services/intake.py) |
| HKU-only boundary | [HKU policy](src/examcraft/ingestion/hku_policy.py), [custom connector](src/examcraft/ingestion/connectors/hku.py) |
| Typed proposals and evidence context | [Planning contracts](src/examcraft/schemas/planning.py), [Planner](src/examcraft/agents/planner.py) |
| Model transport | [OpenRouter adapter](src/examcraft/providers/openrouter.py) |
| Evidence tool and current hard gate | [Retrieval](src/examcraft/retrieval/evidence.py), [draft validator](src/examcraft/validators/planning.py) |
| Execution authority and state | [Workflow](src/examcraft/graph/workflow.py), [routing](src/examcraft/graph/routing.py), [state](src/examcraft/graph/state.py) |
| Temporary evidence ownership | [Workspace](src/examcraft/services/workspace.py) |
| Real Writers, Critic and repair | [Plan Steps 3-6](plan.md#step-3-define-versioned-questions-and-deterministic-gates) |
| Approval, export and practice | [Plan Steps 7-9](plan.md#step-7-assemble-audit-rank-and-obtain-human-approval) |
| Evaluation, lifecycle and submission | [Plan Steps 10-12](plan.md#step-10-run-reproducible-quality-and-robustness-experiments) |

The Mermaid blocks are the editable diagram source. The offline HTML is a rendered
view of those same five diagrams, with no external scripts, fonts or network calls.
