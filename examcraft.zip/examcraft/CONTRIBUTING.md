# Group Contribution Guide

## Suggested workstreams

| Workstream | Primary modules | Next deliverables |
| --- | --- | --- |
| A: UI and practice | `ui/`, `services/session.py` | Material review UX, approval screen, student-safe practice, timer, autosave |
| B: Sources and retrieval | `agents/source_collection.py`, `agents/document_processing.py`, `ingestion/`, `retrieval/`, `services/intake.py` | HKU-only custom navigation after URLs are supplied, extraction quality/OCR, structural chunking and retrieval evaluation |
| C: Generation and models | `agents/planner.py`, `agents/writers.py`, `providers/` | Blueprint task detail, grounded objective/analytical questions, provider usage and budget accounting |
| D: Quality and delivery | `validators/`, `agents/critic.py`, `agents/editor_selector.py` | Independent solving, question/exam gates, versioned repairs, assembly, ranking, JSON/PDF export, evaluation |

`schemas/`, `graph/`, configuration and the dependency manifest are shared integration surfaces.
Choose one integration owner per change and obtain review from affected workstreams.
The table defines responsibilities, not fixed assignments to named members.

## Contracts and boundaries

- Ingestion returns `SourceDocument`; preserve document IDs, page numbers and provenance.
- Source collection is HKU ExamBase/Moodle only. Other sources must use manual upload.
  Never reintroduce a generic URL textbox, configurable non-HKU allowlist or model browser code.
  HKU entry URLs remain unconfigured; authentication and exam-PDF navigation/downloads
  are deferred. Configured-entry HTML fixture support is not a live institutional integration.
- Collection and processing agents propose typed decisions. The graph's intake nodes
  call bounded runners; only registered connectors/parsers execute those decisions.
- Require external-sharing consent before any collection/classification AI request,
  not just after material selection. All queued inputs may be processed before review.
  Mark AI metadata as proposed, preserve raw extracted pages, and keep unknown facts null.
- The internal Planner contract is now `decide(PlanningContext) -> PlannerTurn`, replacing
  `plan(documents, request) -> Blueprint`. Both demo and OpenRouter implement it.
  Context contains only selected-source metadata, bounded evidence, feedback and remaining limits.
- Planner decisions are `retrieve`, `draft` or `stop`. Only graph routing executes tools.
  Never let a model change limits or call unregistered browser/filesystem operations.
- `retrieval/` filters selected document IDs before ranking and preserves page/chunk provenance.
  The current search is keyword overlap, not BM25, embeddings or semantic verification.
- `validators/` owns deterministic rules. The draft gate checks allocation and evidence
  presence, not the truth or completeness of a source-grounded exam.
- The graph owns workflow decisions. UI code calls `RunSession` and displays progress;
  it must not call model APIs directly or edit graph checkpoints manually.
- Current Writer outputs are `WriterTask` handoffs, not questions. Define a versioned
  question contract in `schemas/` before implementing generation. Share it with quality/UI owners.
- Writers run in parallel. The state reducer must preserve both outputs; keep the join
  before Critic. Add bounded routing only alongside tests for convergence and retry limits.
- Providers handle transport, secrets, schemas and limits. Do not pass course text into
  system instructions or grant models generic filesystem, shell or browser execution.
- Collection, processing and planning must reuse the same `OpenRouterClient`.
  Every transient retry consumes its shared request/token allowance; missing usage
  retains reservations. Currency budgets and an overall deadline remain future work.
- Trace events stay inside the run and record outcomes, measured timing and known usage;
  never introduce permanent logs of source text or keys as a debugging shortcut.
- Critic/Editor currently cannot approve anything. Preserve the default-deny export boundary
  until real question validation, final audit and human approval exist.
- Future practice must use a separate student projection, never the answer-key object.
  Objective scoring belongs in deterministic code; AI feedback cannot modify marks.

## A small contribution workflow

1. Agree on a bounded task and the owning workstream.
2. Update shared contracts first if required, with a short compatibility note in the PR.
3. Implement inside the owning module, without adding Streamlit imports to domain code.
4. Extend a nearby existing test. Mock model requests; use fixture responses for connectors.
5. Run pytest, Ruff lint and formatting checks from the README.
6. Ask another workstream to review integration changes before merging.

Do not commit `.venv`, `.env`, real course uploads, browser state, generated exams or credentials.
Do not change the two source specification documents while implementing a module.
Avoid broad refactors in feature PRs; keep shared graph changes small to reduce merge conflicts.

## Recommended next slices

Follow [plan.md](plan.md), including dependencies and acceptance checks.
Freeze evaluation cases early; implement shared budgets before activating Writers.
The intake/planning foundation is delivered, but question contracts, semantic review, exam
delivery, practice and runnable quality evaluation remain unfinished.

The graph is intentionally incomplete at the end of this baseline. Never relabel a scaffold
node as implemented, or permit export, just to make the workflow appear complete.