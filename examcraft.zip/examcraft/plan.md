# ExamCraft implementation plan

**Date:** 2026-10-27  
**Scope:** Complete the proposed exam generator from the runnable agentic intake/planning foundation.  
**Status:** Foundations below are implemented; unchecked T001-T036 milestones remain incomplete.

## Summary and design inputs

Keep Streamlit, LangGraph, Pydantic and temporary per-run storage. Complete one
evidence-grounded exam end to end before broadening collection or producing many
ranked papers. Model decisions propose actions; deterministic Python enforces
permissions, arithmetic, retries, budgets, approval and scoring.

This plan consumes:

- [Course project guideline](../COMP7608B_LLM_Project_Guideline.pdf), especially
  working agentic execution, evaluation, runnable code and limitations.
- [Group proposal](../%5BGroup%207%5D%20ExamCraft%20-%20Agentic%20AI%20exam%20generator.pdf)
  and [technical specification](../ExamCraft%20Tech%20Spec.html).
- [Lecture 3](../Lecture_3_Training_and_Learning.pdf), evaluation/verifier limitations;
  [Lecture 4](../COMP7608B_Lec04.pdf), agent/harness responsibilities;
  [Lecture 5](../COMP7608B_Lec05.pdf), context/tools;
  [Lecture 6](../COMP7608B_Lecture_06.pdf), memory/retrieval and matched comparisons.
- The source review summarized in [README.md](README.md) and integration boundaries
  in [CONTRIBUTING.md](CONTRIBUTING.md).

REQ-001 through REQ-012 below are **local planning labels**, not official course
rubric IDs. No separate machine-readable feature spec, constitution or topology
artifact was supplied. This is a direct project roadmap, not a modernization
workflow or a claim that external assessment gates have passed. Final course
evaluation/report details are still TBA; revise the acceptance plan when announced.

## Technical context and constraints

- Python 3.11+ source; Python 3.13 is the current tested environment.
- Existing pinned dependencies remain sufficient for the delivered foundation.
  Add OCR, retrieval or rendering packages only in the step that needs them.
- UI: Streamlit. Orchestration: LangGraph. Shared contracts: Pydantic.
- Temporary storage: run-owned directory and in-memory graph checkpoints.
  No SQL/Redis/permanent user-history store is required.
- OpenRouter is an optional approved provider, not a requirement for a particular model.
  No fine-tuning, MCP service, skill marketplace or GraphRAG is required.
- Existing tests use pytest, Streamlit AppTest and offline Playwright fixtures.
  Paid model experiments are separate, explicitly authorized evaluation runs.
- The current source allowance is character-based, not a tokenizer-specific input limit.
- Intake/planning roles share a consented attempt/token ledger. Currency budgets
  and an overall run deadline are still future work.
- Source collection is custom HKU ExamBase/Moodle only; every other source is manual
  upload. Entry URLs will be supplied later; authentication, site-specific search and
  PDF downloads remain deferred. Current fixture support reads configured public HTML.

### Constraint check

| Principle | Required behavior throughout the plan |
| --- | --- |
| Default-deny exam delivery | Do not enable exam export until gates, final audit and human approval exist. |
| Evidence and permissions | Filter selected/authorized documents before retrieval; never treat document text as instructions. |
| Temporary user data | Keep uploads, answers, checkpoints and traces scoped to a run; clean up owned artifacts. |
| Honest capability labels | Demo is deterministic; schema validity is not semantic correctness; a blueprint is not an exam. |
| Deterministic authority | Models cannot change marks arithmetic, limits, permissions or objective grading results. |
| Team integration | Shared contracts and graph changes require cross-workstream review. |

### Applied guidance

Use the lectures' observe-decide-act loop, runtime-checked tools, context selection,
scoped state, bounded recovery and independent evaluation. There is no framework
migration here, so migration transformation guidelines are not applicable.

## Delivered foundation, not future tasks

- Early external-sharing consent, queued in-memory uploads and explicit collection/
  processing graph nodes before the material-review interrupt.
- Bounded Source Collector and Document Processor roles, deterministic demo policies,
  typed tool choices, proposed metadata and immutable extracted page evidence.
- HKU-only backend policy with configured-entry connectors, no generic web collection,
  no browser launch for missing URLs, and upload fallback instead of authentication.
- A shared provider attempt/token ledger across all three model roles, with explicit
  transient retry accounting and unknown-usage reservations.
- Typed `PlanningContext`, `PlanningDecision`, `PlannerTurn`, evidence and trace contracts.
- `Planner.decide`: retrieve, draft or stop; demo and OpenRouter implementations.
- Selected-source, page-aware fixed-size chunks and deterministic keyword-overlap retrieval.
- Bounded evidence context, validation feedback, conditional routes and controlled stops.
- Allocation/source/evidence-presence gates before the two Writer handoffs.
- Per-run planner/retrieval limits, SDK request limits, usage reporting when available.
- Visible low-text extraction warnings and a planning trace in the UI.
- Explicit checkpoint serializer type allowlist and regression coverage.

Live HKU site navigation/PDF retrieval, OCR, Writers, semantic Critic, repair/assembly,
exams, approval, exports, practice and
quality evaluation remain incomplete. The foundation does not prove that the
agentic approach improves generated exams.

## Execution order and ownership

Owners are suggested workstreams, not assignments to named students:
A = UI/practice, B = sources/retrieval, C = generation/providers,
D = quality/delivery/evaluation. Choose an integration owner for shared contracts.

```text
1 Scope and evaluation cases
  -> 2 Sources/retrieval ----+
  -> 3 Contracts/gates -----+-> 5 Writers -> 6 Critic/repair -> 7 Approval -> 8 Export
  -> 4 Provider/budgets ----+                                      |
                                                                 +-> 9 Practice
8 + 9 -> 10 Evaluation
4 + 8 + 9 -> 11 Lifecycle/hardening
9 + 10 + 11 -> 12 Submission/handoff
```

Steps 2, 3 and 4 can proceed in parallel after Step 1, provided changes to
configuration/shared contracts are integrated deliberately. Steps 10 and 11 can
proceed in parallel after their prerequisites. Freeze evaluation cases in Step 1;
do not wait until Step 10 to decide how success will be measured.

## Implementation steps and task breakdown

### Step 1: Freeze the first use case and evaluation contract

**Plan item:** 1.1  
**Requirements:** REQ-001, REQ-002, REQ-009, REQ-012  
**Depends on:** none. **Owner:** integration owner + D.

Resolve the proposal's Cambridge/HKU scope ambiguity by choosing one first
subject/course, syllabus/version, paper format and authorized source set. Keep
generation inputs separate from held-out papers/mark schemes. The published course
guideline does not define numerical quality thresholds; label project thresholds
as provisional until instructor review.

- [ ] T001 [Plan:1.1] Record the first subject, scope, source permissions and generation/held-out roles in `README.md` and `evaluation/manifest.json`.
- [ ] T002 [Plan:1.1] Create authorized development and held-out examples in `evaluation/cases.jsonl`, including valid, wrong, ambiguous, unsupported and duplicate questions with source/page references.
- [ ] T003 [Plan:1.1] Define provisional correctness, support, clarity, coverage, cost and latency checks in `evaluation/rubric.json`, including independent human-review instructions.

**Acceptance:** Every example has an ID, source role and split; held-out benchmark
documents cannot enter generation retrieval. An instructor/reviewer can interpret
the rubric without consulting the application's Critic. Document permissions and
limited HKU benchmark availability rather than inventing missing mark schemes.

### Step 2: Improve extraction quality and selected-source retrieval

**Plan item:** 2.1  
**Requirements:** REQ-002, REQ-003  
**Depends on:** 1.1. **Owner:** B.

The processing agent and HKU connector policy now exist. Keep entry URLs blank
until approved values are prepared. Custom ExamBase/Moodle navigation and PDF
downloads are follow-up design work, not generic browser access. Authentication
remains deferred; other sources always use manual upload.

Extend the working lexical baseline only where measured failures justify it.
Preserve headings/paragraphs and complete rules when chunking; retain page,
document, source revision and chunk provenance. Consider BM25 before more costly
dense/hybrid retrieval. Keep originals accessible for authorized review when OCR
or visual evidence is required.

- [ ] T004 [Plan:2.1] Extend metadata and quality checks in `src/examcraft/schemas/models.py` and `src/examcraft/ingestion/documents.py`; align parser and `.streamlit/config.toml` upload limits without removing safeguards.
- [ ] T005 [Plan:2.1] Improve `src/examcraft/retrieval/evidence.py` with structural boundaries, source-role filtering, retrieval failure observations and a measured ranking strategy.
- [ ] T006 [Plan:2.1] Add permitted OCR/layout handling or explicit upload fallback and cover scanned, mixed, table/diagram, late-page and excluded-source cases in `tests/test_ingestion.py` and `tests/test_retrieval.py`.

**Acceptance:** A late-page fact can be retrieved; excluded/held-out material never
appears in context. Poor extraction is visible. Derivatives resolve to originals.
Report retrieval recall/source support on labeled examples and account for added
latency. Raising the Lecture 3 limits alone does not count as OCR support.

### Step 3: Define versioned questions and deterministic gates

**Plan item:** 3.1  
**Requirements:** REQ-002, REQ-004, REQ-006  
**Depends on:** 1.1. **Owner:** integration owner + C/D.

Agree contracts before implementing Writers and Critic independently. Use
discriminated question types rather than arbitrary dictionaries. Extend the
blueprint to express topic/type/difficulty/cognitive allocations, task IDs,
per-question marks, estimated time and required pool size.

- [ ] T007 [Plan:3.1] Add `src/examcraft/schemas/questions.py` with stable IDs, versions, citations, objective answers, numeric tolerances and essay/calculation rubrics.
- [ ] T008 [Plan:3.1] Add `src/examcraft/validators/questions.py` for answer formats, marks, options, citation resolution, selected-source membership and exact duplicates.
- [ ] T009 [Plan:3.1] Extend blueprint/task contracts in `src/examcraft/schemas/models.py` and cover allocations, question-type rules and invalid references in `tests/test_questions.py`.

**Acceptance:** Invalid answers/options/marks/references cannot become approved
questions. Every generated question belongs to a stable task. Repairs can create
new versions without overwriting the reviewed object. Schema checks are not
presented as proof of factual correctness.

### Step 4: Introduce shared provider budgets and structured outcomes

**Plan item:** 4.1  
**Requirements:** REQ-010, REQ-011, REQ-012  
**Depends on:** 1.1. **Owner:** C.

Partial foundation delivered: one consented `OpenRouterClient` now shares attempt/
token accounting across collection, processing and planning. The tasks below remain
unchecked because pricing, overall deadlines, provider-neutral contracts/versioning
and richer errors are not complete.

Do this before activating multiple model roles. Centralize request execution,
usage, role configuration and deadlines, rather than copying the current
planner-only adapter into every agent. Preserve the existing consent boundary.

- [ ] T010 [Plan:4.1] Extract shared provider request/result contracts from `src/examcraft/providers/openrouter.py` into `src/examcraft/providers/client.py`, recording model/prompt versions and known usage.
- [ ] T011 [Plan:4.1] Add `src/examcraft/services/budget.py` and typed settings for shared tokens, estimated currency cost, model/tool attempts and an overall deadline; reserve capacity before calls and reconcile afterward.
- [ ] T012 [Plan:4.1] Define structured stage/error outcomes in `src/examcraft/schemas/planning.py` and extend provider/session tests for timeouts, missing usage, exhausted budgets and consent without logging keys or source text.

**Acceptance:** No role bypasses the common wrapper. Unknown usage is conservatively
accounted for, not assumed free. Retries consume the same budget. An exhausted
budget or deadline returns an explicit controlled stop/valid partial-result
summary. Do not retry permanent input/authentication errors unchanged.

### Step 5: Generate a grounded question pool

**Plan item:** 5.1  
**Requirements:** REQ-001, REQ-002, REQ-004, REQ-006  
**Depends on:** 2.1, 3.1, 4.1. **Owner:** C.

Replace Writer handoffs with actual task-specific generation. Each Writer receives
only assigned tasks and relevant selected-source evidence, not the other Writer's
pending questions or answers. Keep parallel work only where dependencies permit.

- [ ] T013 [US1] [Plan:5.1] Implement objective and analytical generation in `src/examcraft/agents/writers.py` using shared budgets, role-specific instructions and task-filtered retrieval.
- [ ] T014 [US1] [Plan:5.1] Extend `src/examcraft/graph/state.py` to merge idempotent versioned question outputs, citations and insufficient-evidence outcomes by stable task/question IDs.
- [ ] T015 [US1] [Plan:5.1] Integrate cheap gates before semantic review in `src/examcraft/graph/workflow.py` and test parallel merge, malformed output and shortfall cases in `tests/test_writers.py`.

**Acceptance:** Both branches produce valid question contracts without lost or
duplicated results. Questions include answers, explanations and marking guidance
where required. Insufficient evidence requests replanning or reports a shortfall;
it never authorizes answering from model memory.

### Step 6: Implement independent Critic decisions and bounded repair

**Plan item:** 6.1  
**Requirements:** REQ-001, REQ-002, REQ-004, REQ-005, REQ-006, REQ-010  
**Depends on:** 5.1. **Owner:** D + C.

Use a blind solution pass, then compare against the Writer's proposal. Keep
semantic judgments distinct from deterministic checks. The Critic proposes
pass/repair/reject/replan; the graph enforces legal routes and remaining limits.

- [ ] T016 [US1] [Plan:6.1] Implement critique/independent-solution contracts in `src/examcraft/schemas/critique.py` and two-pass review in `src/examcraft/agents/critic.py`.
- [ ] T017 [US1] [Plan:6.1] Implement restricted-field repair in `src/examcraft/agents/editor_selector.py`, preserving prior versions and recording replacements plus review evidence.
- [ ] T018 [US1] [Plan:6.1] Extend `src/examcraft/graph/routing.py` and workflow tests for pass, repair, replacement, replanning, two generation rounds and at most two repairs per question under shared budgets.

**Acceptance:** Demonstrate success, a repaired defect and an explicit limit stop.
Repaired versions pass deterministic and semantic review again. Replanning cannot
lower quality requirements or raise limits. If too few valid questions remain,
produce fewer eligible exams or stop with an explanation.

### Step 7: Assemble, audit, rank and obtain human approval

**Plan item:** 7.1  
**Requirements:** REQ-005, REQ-006, REQ-007  
**Depends on:** 6.1. **Owner:** D + A.

Initially assemble one complete exam; expand toward up to ten varied papers only
after a single paper is reliable. Rank passing exams only. Proposed rubric weights
remain provisional until calibrated on instructor-reviewed examples.

- [ ] T019 [US1] [Plan:7.1] Add `src/examcraft/schemas/exams.py` and deterministic coverage/combination checks in `src/examcraft/validators/exams.py`; assemble approved versions in `src/examcraft/agents/editor_selector.py`.
- [ ] T020 [US1] [Plan:7.1] Add final Critic audit and reproducible ranking from validated inputs, checking duplication, answer leakage, marks, duration and coverage in `tests/test_exams.py`.
- [ ] T021 [US1] [Plan:7.1] Add final approval/reject/one-targeted-regeneration interrupts to `src/examcraft/graph/workflow.py`, `src/examcraft/services/session.py` and `src/examcraft/ui/app.py`.

**Acceptance:** No rejected version or failed hard gate can reach export, even
after a user approves. The UI shows evidence, warnings, audit and repair history.
User acceptance does not turn the paper into an official verified assessment.

### Step 8: Export separated student and answer-key artifacts

**Plan item:** 8.1  
**Requirements:** REQ-006, REQ-007, REQ-011  
**Depends on:** 7.1. **Owner:** D + A.

Use one immutable approved exam as the source for all exports. No model-generated
HTML/JavaScript is executed. Introduce PDF dependencies only with rendering checks
on the supported development/deployment platforms.

- [ ] T022 [US1] [Plan:8.1] Add versioned student/answer-key projections in `src/examcraft/schemas/exams.py` and `src/examcraft/services/export.py`, rejecting answer fields in student artifacts.
- [ ] T023 [US1] [Plan:8.1] Add controlled student/answer templates under `src/examcraft/templates/`, atomic JSON/PDF writes and artifact hashes; reopen and validate generated files.
- [ ] T024 [US1] [Plan:8.1] Wire approved downloads into `src/examcraft/ui/app.py` and test artifact shape, PDF page count, exact marks and one bounded export retry in `tests/test_export.py`.

**Acceptance:** Student JSON/PDF contain no hidden answers, rubrics or explanations.
The answer key remains separate. Partial files are never offered for download.
A rendering failure preserves the approved exam and does not trigger regeneration.

### Step 9: Complete temporary timed practice and grading

**Plan item:** 9.1  
**Requirements:** REQ-008, REQ-011  
**Depends on:** 8.1. **Owner:** A.

Keep practice within the temporary run. Use immutable student/answer-key versions,
server deadlines and deterministic scoring. AI essay feedback is formative, not an
official mark. This remains part of the proposal unless a scope change is agreed.

- [ ] T025 [US2] [Plan:9.1] Add `src/examcraft/schemas/practice.py` and `src/examcraft/services/practice.py` for snapshots, UTC deadlines, answer validation and atomic autosave.
- [ ] T026 [US2] [Plan:9.1] Implement canonical objective/numeric grading and separate pending-review marks; test exact answers, tolerances, malformed/late answers and idempotent submission in `tests/test_practice.py`.
- [ ] T027 [US2] [Plan:9.1] Add supervisor-driven expiry, practice/result interrupts and optional budgeted feedback in `src/examcraft/agents/practice_feedback.py` and the UI, including a labeled answer-key fallback.

**Acceptance:** Refresh preserves active-session answers. Server time rejects late
changes. Disconnected attempts expire without becoming manual submissions.
Repeated submission returns the same result. Feedback failure cannot change marks
or block deterministic results. Restart persistence is not promised.

### Step 10: Run reproducible quality and robustness experiments

**Plan item:** 10.1  
**Requirements:** REQ-009, REQ-010  
**Depends on:** 8.1, 9.1 for the complete submitted product. **Owner:** D + all.

Use the frozen cases from Step 1. Compare single-prompt, retrieval-only and
Critic/repair configurations only when the corresponding implementation exists.
Separate development tuning from final held-out evaluation.

- [ ] T028 [Plan:10.1] Implement `evaluation/run.py` and versioned configurations to replay identical authorized cases with model, prompt, source, sampling and budget metadata.
- [ ] T029 [Plan:10.1] Implement `evaluation/metrics.py` for correctness/support, coverage, duplicates, valid artifacts, Critic precision/recall, success, p50/p95 latency, calls, tokens and cost; repeat runs and report uncertainty.
- [ ] T030 [Plan:10.1] Produce independent instructor-reviewed judgments and failure analysis in `evaluation/results/`, reporting contamination checks, ablations, dataset limits and redacted representative traces.

**Acceptance:** Another group member can reproduce the procedure and aggregate
results without reconstructing UI sessions. JSON/schema success is not reported as
answer correctness. The system's own Critic is not the sole judge. Keep retained
experiment data authorized and distinct from ephemeral user-session data.

### Step 11: Finish lifecycle, privacy and deployment boundaries

**Plan item:** 11.1  
**Requirements:** REQ-003, REQ-010, REQ-011  
**Depends on:** 4.1, 8.1, 9.1. **Owner:** B + integration owner.

Preserve local-only operation until deployment controls are validated. Collection
login/OCR are advanced scope: implement approved deterministic connectors or
explicitly keep upload fallback; do not broaden model permissions.

- [ ] T031 [Plan:11.1] Add run manifests, schema versions and large-content references in `src/examcraft/services/workspace.py` and `src/examcraft/graph/state.py`, reducing repeated checkpoint copies.
- [ ] T032 [Plan:11.1] Add safe owned-workspace TTL cleanup and browser/thread/attempt cleanup on completion, cancellation and expiry, with race-safe tests in `tests/test_lifecycle.py`.
- [ ] T033 [Plan:11.1] Validate upload isolation, parser/resource limits, HKU-only custom connector behavior and deployment authentication/egress policy; defer HKU sign-in until approved URLs/authentication design are supplied and keep other sources manual-upload only.

**Acceptance:** Ending/resetting a run removes its artifacts and checkpoint.
Cleanup never deletes unrelated paths or active runs. No credentials, original
uploads or permanent user traces enter source control. The system remains
localhost-only if public deployment requirements cannot be demonstrated.

### Step 12: Deliver a reproducible submission and defensible demonstration

**Plan item:** 12.1  
**Requirements:** REQ-009, REQ-012  
**Depends on:** 9.1, 10.1, 11.1. **Owner:** integration owner + all.

The published weighting is proposal 20%, report/code 50%, presentation 30%;
detailed final report/presentation requirements are still TBA. Confirm the latest
instructions rather than inventing a grading rubric or a final deadline.

- [ ] T034 [Plan:12.1] Add a reproducible dependency lock strategy and supported-Python checks; adapt `.github/workflows/ci.yml` to the actual Git root and verify clean-environment setup.
- [ ] T035 [Plan:12.1] Update `README.md` and `CONTRIBUTING.md` with final capabilities, experiment commands, design trade-offs, limitations, data permissions and actual group contributions.
- [ ] T036 [Plan:12.1] Prepare approved demonstration cases for success, repair and controlled failure, plus practice if claimed; link measured results and artifacts in the final report/presentation per announced requirements.

**Acceptance:** A reviewer can install and run the code, distinguish mock/demo from
real model results, inspect one decision-changing observation, and locate the
evidence supporting quality/cost claims. Every promised feature is implemented or
explicitly reported as a limitation/agreed scope change.

## Validation strategy

- **Current foundation:** pytest routing/provider/retrieval/ingestion tests and
  Streamlit AppTest; Playwright uses offline fulfilled responses. No paid calls.
- **Critical journeys:** source review and retrieval; successful draft; validation
  feedback and retry; empty evidence and explicit stop; later approved exam/export;
  timed practice/manual submit/expiry; reset/cleanup.
- **Future model evaluation:** real approved provider calls only through the budget
  wrapper, with fixed authorized cases and independent labels.
- **Data isolation:** unique run/thread IDs, synthetic unit fixtures, controlled
  clocks for timers, owned temporary paths and explicit cleanup.
- **Known gaps:** offline/mocked tests cannot verify provider availability, semantic
  exam quality, OCR or PDF-runtime compatibility. AppTest does not replace a final
  browser/manual demonstration of the completed user journey.
- **Commands now:** use the pytest/Ruff commands in [README.md](README.md).
  A runnable evaluation command will be documented when T028 is implemented.

## Requirement mapping

| Requirement | Meaning | Plan items | Planned completion evidence |
| --- | --- | --- | --- |
| REQ-001 | User-oriented agentic decisions and completed exam task | 1.1, 5.1, 6.1 | Frozen scope, generated questions, decision-changing Critic routes |
| REQ-002 | Selected-source grounding and provenance | 1.1, 2.1, 3.1, 5.1, 6.1 | Source roles, retrieval tests, citations and independent source checks |
| REQ-003 | Bounded inputs and visible extraction limitations | 2.1, 11.1 | Quality warnings, parser limits, OCR/fallback and lifecycle tests |
| REQ-004 | Typed, versioned blueprint/question/task contracts | 3.1, 5.1, 6.1 | Question schemas, stable IDs and immutable repair versions |
| REQ-005 | Independent review and bounded correction | 6.1, 7.1 | Blind solution, critiques, repair history and final audit |
| REQ-006 | Deterministic question/exam hard gates | 3.1, 5.1, 6.1, 7.1, 8.1 | Validators, citation/marks checks, no failed approved versions |
| REQ-007 | Human approval and separated exam exports | 7.1, 8.1 | Approval interrupt, versioned student/key JSON and validated PDFs |
| REQ-008 | Timed practice, deterministic grading and labeled feedback | 9.1 | Deadline/idempotency tests and separate objective/pending marks |
| REQ-009 | Reproducible, independent system evaluation | 1.1, 10.1, 12.1 | Frozen splits, baseline comparisons, metrics and failure analysis |
| REQ-010 | Shared budgets, deadlines, errors and diagnostics | 4.1, 6.1, 10.1, 11.1 | Budget wrapper, bounded routes and measured usage/latency |
| REQ-011 | Consent, temporary data and lifecycle isolation | 4.1, 8.1, 9.1, 11.1 | Consent tests, projection boundary, manifests and owned cleanup |
| REQ-012 | Runnable, documented and reviewable group delivery | 1.1, 4.1, 12.1 | Setup/CI, versioned experiment settings and contribution evidence |

The files under [checkpoints/](checkpoints/) describe this plan's traceability,
not implementation completion and not LangGraph runtime checkpoints.
