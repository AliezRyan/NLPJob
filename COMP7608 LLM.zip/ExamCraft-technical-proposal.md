# ExamCraft: Technical Proposal

## 1. Executive summary

ExamCraft is a web application for HKU course users to collect authorized
course materials, select sources, and generate ranked mock examinations.
Users can download exams as PDF and JSON, then take a selected exam in a
timed practice mode.

The proposed MVP is a one-off workflow built as a Streamlit application with
LangGraph orchestrating multiple AI components. Playwright and document
processing libraries are exposed as tools that AI agents can invoke. The
agents decide when to request a tool operation; the tools perform bounded
operations and return results to the agent. The system does not run a fixed,
unattended collection-and-extraction pipeline.

The MVP keeps workflow state and files temporarily. It does not use SQL or
retain historical exams, answers, or attempts. User uploads provide a
fallback when authorized automated retrieval is unavailable.

## 2. Goals and scope

### Goals

- Accept an HKU course code through a web interface.
- Collect relevant material from approved HKU sources using
  AI-directed Playwright tool calls.
- Provide a user-upload route as a fallback.
- Extract and classify material, including scanned PDFs.
- Allow users to review and select materials before generation.
- Generate multiple source-grounded mock exam candidates, evaluate and rank
  them, and export approved exams as PDF and JSON.
- Let users take an exam in a timed practice mode and receive results.
- Remove temporary data at the end of a run or after its expiry.

### Scope assumptions

- The initial product is for practice and study, not high-stakes assessment
  or proctoring.
- Automated access to Moodle or ExamBase is conditional on HKU and
  rights-holder approval.
- User uploads remain available if an authorized automated source connector
  cannot be used.
- An application restart can end a run because the MVP uses in-memory state.

## 3. Proposed architecture

```text
Student / instructor
        |
        v
Streamlit application
        |
        v
LangGraph workflow and AI components
        |
        +--> AI A --tool call--> Playwright tool
        |                         +--> HKU Moodle, if authorized
        |                         +--> HKU ExamBase, if authorized
        |
        +--> User-upload fallback
        |
        +--> AI B --tool calls--> Docling / PyMuPDF / OCR tools
        |
        v
Temporary parsed materials and source references
        |
        v
User reviews and selects materials
        |
        v
Blueprint -> candidate generation -> validation -> review and ranking
        |
        +--> PDF exam
        +--> Structured JSON exam
        |
        v
Timed practice -> score and feedback
        |
        v
Temporary state and files are deleted
```

### Important distinction: AI tool use and automation

Playwright is a browser-automation library, but ExamCraft should use it as
an explicit tool available to an AI agent. The agent requests permitted
operations; the tool executes only those bounded operations and returns
results. Similarly, Docling, PyMuPDF, OCRmyPDF, and Tesseract are processing
tools called by an AI agent, not autonomous agents running a separate
fixed pipeline.

The tools should enforce allowlisted domains, file types and size limits,
timeouts, output directories, and access restrictions. The AI must not be
able to bypass authentication, change tool permissions, execute arbitrary
code, or navigate to unapproved targets.

## 4. Technology choices

| Layer | Proposed resource | Use |
|---|---|---|
| User interface | Streamlit | Course entry, collection status, material selection, exam downloads, practice mode |
| Agent orchestration | LangGraph | Workflow state, tool routing, pauses for user selection, bounded retries |
| In-run state | LangGraph `InMemorySaver` | Active graph state and resumable user-selection checkpoint while the process runs |
| Browser tool | Playwright for Python | Browser operations requested by the collection agent |
| Document tools | Docling and PyMuPDF | Text, layout, table, and page extraction requested by the processing agent |
| OCR tools | OCRmyPDF and Tesseract | OCR for scanned or poorly extracted documents |
| Schema validation | Pydantic | Material, question, exam, and export data validation |
| PDF export | WeasyPrint | Render consistent PDFs from a controlled template |
| Temporary files | Per-run temporary workspace | Originals, parsed output, intermediate artifacts, and exports |
| AI model access | Approved hosted provider or local model | Supplies the model endpoints used by agent nodes, subject to data-handling approval |

The initial design needs no SQL database, Redis queue, permanent object
storage, or permanent vector database. For a modest amount of material,
retrieval can use temporary chunks and in-memory search. Add a temporary
semantic index only if testing shows that direct retrieval is insufficient;
delete it with the run.

## 5. AI components

The labels identify distinct components or roles in the workflow. They do
not require a different commercial model for every label; multiple agents
may use the same approved model provider with different prompts, tools, and
structured output schemas.

| Component | Workflow position |
|---|---|
| AI A | Authorized source collection using the Playwright tool |
| AI B | Document processing using Docling, PyMuPDF, and OCR tools |
| AI C | Material classification and metadata |
| AI D | Exam blueprint |
| AI E | Candidate generation |
| AI F | Candidate generation |
| AI G | Quality review |
| AI H | Quality review |
| AI I (optional) | Past-paper pattern insights |
| AI J (optional) | Post-submission practice feedback |

The deterministic application code remains responsible for enforcing
schemas, permissions, output paths, retry limits, cleanup, and objective
answer scoring. AI outputs must be treated as proposals until they pass
validation.

## 6. Workflow details

### 6.1 Course entry and source access

The user enters a course code. The app validates the input and starts a
LangGraph run with a unique thread ID. The collection agent may use the
Playwright tool to search and retrieve relevant files from authorized
sources. Source domains and permitted actions must be explicitly allowlisted.

The user may instead upload materials. Upload is also the fallback if an
approved source is unavailable, requires unsupported authentication, or
returns no relevant material.

### 6.2 Document extraction and classification

The document-processing agent receives authorized retrieved or uploaded
files and invokes processing tools as needed:

1. Check file type, file size, and processing limits.
2. Use Docling/PyMuPDF for text, page structure, tables, and layout.
3. Request OCRmyPDF/Tesseract when text extraction is absent or poor.
4. Return extracted content and processing warnings to the workflow.
5. Validate normalized results with Pydantic and save them temporarily as
   canonical JSON, with Markdown generated for readable review.

Suggested material metadata:

```text
document_id
course_code
filename
title
source_system
document_type
author                 # nullable if unknown
document_year          # nullable if unknown
exam_year              # separate from processing year
retrieved_at
language
page_count
summary
topics
content_hash
page_references
processing_warnings
```

Do not infer missing authors, dates, or other metadata without evidence.
Keep page-level references and provenance so generated questions can be
traced to authorized sources.

### 6.3 User review and material selection

Present a selectable list with filename, source, type, author/year when
known, brief summary, and processing warnings. LangGraph pauses for the
user's selection using an interrupt and resumes with selected document
IDs. Configure an in-memory checkpointer for this pause/resume behavior;
the run will not survive an app restart.

### 6.4 Blueprint, generation, and evaluation

Create an exam blueprint for the selected materials and requested exam
parameters. It should cover topics, question types, difficulty, total
marks, marks per question, duration, and any requested cognitive-level
distribution.

Generate more candidate papers than the desired final number where
practical. Validate the candidates against:

- Required JSON schema and fields
- Answer keys, explanations, and marking guidance
- Per-question marks and total marks
- Topic and question-type coverage
- Traceable source references
- Clarity and requested difficulty
- Duplicate or near-duplicate questions

Use independent quality-review components and a fixed ranking rubric.
Rank only candidates that pass required checks. If fewer than ten meet the
threshold, report that result and offer regeneration instead of silently
including weak papers. Keep retries bounded to control latency and cost.

Past-paper pattern insights are optional. If provided, describe observed
patterns in the authorized sample, state the sample size and period, and
avoid presenting those observations as predictions.

### 6.5 Export

Use the same validated exam object for both formats:

- **PDF:** printable exam paper, optionally with an answer key or marking
  guide in a separate file.
- **JSON:** versioned machine-readable exam data for downstream use.

Example question fields:

```text
question_id
type
prompt
options
correct_answer
explanation
marks
difficulty
bloom_level
topic
source_references
grading_rubric
```

Use a fixed, application-controlled HTML layout for PDF generation. Do not
ask an AI component to generate executable HTML or JavaScript.

### 6.6 Timed practice

Render the selected exam in the Streamlit interface from validated JSON.
Do not expose the answer key in the pre-submission exam view. Maintain
attempt answers and timing only for the active run.

Auto-grade objective question types such as multiple-choice and
true/false. Numeric answers need explicit tolerances. Essay answers should
be reviewed by a human or receive clearly labelled AI-assisted feedback.
The practice timer is suitable for self-study, not proctored or
high-stakes assessment.

## 7. Temporary data, privacy, and security

The MVP does not retain historical exams or attempts:

- Use a unique in-memory graph thread for each run.
- Put files in a per-run temporary workspace.
- Delete uploaded, collected, parsed, and generated files at completion or
  after a configured expiry.
- Clear in-memory graph state when the run ends.
- Avoid logging source content, answer keys, or user answers.
- Tell users that a restart or session loss can interrupt their run.

For HKU access:

- Confirm permission for automated access, downloading, processing, and
  reuse with HKU and relevant rights holders before enabling source tools.
- Do not embed shared/preloaded HKU credentials.
- Use only approved authentication flows; do not bypass MFA or access
  controls.
- Do not retain browser profiles, cookies, or session state after a run.
- Keep automated access scoped to the signed-in user's authorized
  materials.

For model access:

- Confirm whether protected materials may be sent to a hosted LLM provider.
- Use a provider or local deployment approved for the data classification.
- Do not expose source text or secrets in application logs or traces.
- Treat retrieved documents as untrusted input; their contents must not
  override system instructions or expand tool permissions.

## 8. Quality evaluation

Test with a small, permissioned collection containing text PDFs, scanned
PDFs, and other representative course documents. Measure:

- Extraction completeness and OCR errors
- Metadata accuracy and correct handling of unknown values
- Correct source and page references
- Topic coverage and blueprint adherence
- Question factuality and grounding
- Answer-key, marks, and total-score correctness
- Difficulty and question-type distribution
- Duplicate-question rate
- PDF and JSON validity
- Correct scoring for supported objective question types
- Cleanup of temporary artifacts and state

Include human review of generated questions and papers. Model-based
reviews are useful quality signals but are not a substitute for evidence
checks or human evaluation.

## 9. Implementation plan

1. **Permission and access proof:** Confirm HKU access conditions and
   supported authentication. Prototype the Playwright tool against an
   approved source and keep upload fallback available.
2. **Agent-tool workflow:** Implement the LangGraph collection agent,
   Playwright tool interface, document-processing agent, and bounded
   Docling/PyMuPDF/OCR tool interfaces.
3. **Material review:** Add Pydantic metadata, temporary Markdown/JSON,
   material summaries, and the user-selection interrupt.
4. **Exam generation:** Add the blueprint, candidate generation,
   validation, multi-agent review, ranking, and PDF/JSON exports.
5. **Practice and cleanup:** Add the exam template, timed practice,
   scoring, optional feedback, expiry cleanup, and user-facing notices.
6. **Evaluation and hardening:** Test representative documents, tool
   failures, malformed files, unauthorized targets, concurrent sessions,
   process restarts, and cleanup behavior.

## 10. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Automated source access is not permitted or supported | Confirm authorization first; retain user-upload fallback |
| Agent tool calls navigate to unsuitable targets | Restrict domains, actions, file types, timeouts, and output paths in tool code |
| OCR or parsing errors contaminate generated questions | Preserve warnings and page references; validate and expose uncertain extraction |
| Generated questions are unsupported by source material | Require citations and source-based review before ranking |
| AI review gives overconfident rankings | Use explicit rubric, independent reviews, deterministic checks, and human evaluation |
| Credentials or protected materials leak | Avoid shared credentials, minimize retention, restrict logs, and obtain model-provider approval |
| App restart loses the current run | Disclose the limitation; add persistent temporary storage only if restart recovery becomes a requirement |
| Fewer than ten candidates pass | Return the passing count and offer bounded regeneration rather than lowering quality gates |

## 11. Future extensions

Only add infrastructure when a demonstrated requirement calls for it:

- Persistent checkpointing if runs must survive restarts.
- A background task queue if collection or generation blocks the UI for
  too long.
- SQL if user accounts, history, or durable records become necessary.
- A temporary semantic index if larger source sets need better retrieval.
- Additional source connectors only after their access and reuse are
  approved.
- More formal assessment support only after adding appropriate security,
  accessibility, and reliability controls.

