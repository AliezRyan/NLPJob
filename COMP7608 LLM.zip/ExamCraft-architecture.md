# ExamCraft Architecture

This diagram shows a simple, one-off ExamCraft workflow. AI agents control
Playwright and document-processing tools through bounded tool calls for
authorized HKU sources. User uploads are the fallback. The app keeps run
state and files temporarily and does not use SQL or retain historical exams
or attempts.

The workflow uses multiple separately labeled AI components. They may use
the same or different approved model providers; the labels identify distinct
AI components in the workflow, not a requirement to deploy separate model
products. Playwright, Docling, PyMuPDF, and OCR tools perform bounded
operations when invoked; they do not independently run the workflow.

### AI components in workflow

| AI component | Workflow position |
|---|---|
| AI A | Collection |
| AI B | Document processing |
| AI C | Material classification |
| AI D | Exam blueprint |
| AI E, AI F | Candidate generation |
| AI G, AI H | Quality review |
| AI I (optional) | Past-paper pattern insights |
| AI J (optional) | Post-submission practice feedback |

```mermaid
flowchart TB
    User["Student / instructor"]

    subgraph App["Single-process Streamlit application"]
        UI["Streamlit UI<br/>Course code · material selection<br/>progress · downloads · timed exam"]
        Temp[("Temporary per-run workspace<br/>Delete files and state after completion / expiry")]
        UI --> Temp
    end

    User --> UI

    subgraph Graph["LangGraph workflow"]
        Start["Validate course and request"]
        Access["Resolve authorized sources"]
        A["AI A · Collection agent"]
        BrowserTool["Playwright tool<br/>Bounded browser actions"]
        B["AI B · Document processing agent"]
        ParseTool["Docling + PyMuPDF tools<br/>Document parsing and extraction"]
        OCR{"Scanned or poor text?"}
        OCRTool["OCRmyPDF + Tesseract tools"]
        C["AI C · Material classification"]
        Normalize["Pydantic-validated metadata<br/>Markdown + canonical JSON"]
        Index["Chunk and index with source/page references"]
        Select["Pause for user material selection<br/>LangGraph interrupt"]
        Blueprint["Build exam blueprint<br/>Topics · types · difficulty · marks · duration"]
        D["AI D"]
        Generate["Generate candidate papers<br/>Ground questions in selected sources"]
        E["AI E"]
        F["AI F"]
        Validate["Validate schema, marks, coverage,<br/>answer keys, citations, duplicates"]
        Critique["Independent rubric-based critique"]
        G["AI G"]
        H["AI H"]
        I["AI I (optional)"]
        Retry{"Candidates pass quality gates?"}
        Rank["Score and rank passing papers<br/>Select top 10"]
        Export["Export versioned exam JSON<br/>and PDF via WeasyPrint"]

        Start --> Access --> A
        A -->|"AI tool call"| BrowserTool
        BrowserTool -->|"Retrieved files / page data"| A
        A --> B
        B -->|"AI tool call"| ParseTool
        ParseTool -->|"Extracted text / structure"| B
        B --> OCR
        OCR -->|"No"| C
        OCR -->|"Yes · AI tool call"| OCRTool -->|"OCR text"| B --> C
        C --> Normalize --> Index --> Select
        Select --> Blueprint --> D --> Generate
        E --> Generate
        F --> Generate
        Generate --> Validate --> Critique
        G --> Critique
        H --> Critique
        Critique --> Retry
        Retry -->|"No: bounded regeneration"| Generate
        Retry -->|"Yes"| Rank --> Export
        Rank -.-> I
        I -. "Optional insights" .-> Export
        G -. "Optional insights" .-> Export
    end

    UI --> Start
    Select -. "Show list / collect user selection" .-> UI
    UI -. "Resume same graph thread with selected IDs" .-> Select
    Export --> UI

    subgraph Sources["Source acquisition (permission required)"]
        Moodle["HKU Moodle"]
        ExamBase["HKU ExamBase"]
        Upload["User-uploaded files<br/>Fallback if automated retrieval is unavailable"]
        Access --> Moodle
        Access --> ExamBase
        Moodle --> A
        ExamBase --> A
        Access --> Upload
        Upload --> B
    end

    subgraph Ephemeral["Temporary run state"]
        Checkpoint["LangGraph InMemorySaver<br/>Pause / resume while app process is running"]
        Context["Selected source text and exam data<br/>Held in graph state or temporary workspace"]
    end
    Select <--> Checkpoint
    Normalize --> Context
    Index --> Context
    Generate --> Context
    Export --> Temp
    Upload --> Temp
    BrowserTool --> Temp
    ParseTool --> Temp

    AIProvider["Approved LLM provider(s) or local model(s)<br/>Use only under approved data-handling terms"]
    A -.-> AIProvider
    B -.-> AIProvider
    C -.-> AIProvider
    D -.-> AIProvider
    E -.-> AIProvider
    F -.-> AIProvider
    G -.-> AIProvider
    H -.-> AIProvider
    I -.-> AIProvider

    subgraph Practice["Interactive practice in Streamlit"]
        Chosen["User chooses an exam"]
        Attempt["Attempt API<br/>Issue exam without answer key"]
        Timer["Client timer + server-recorded start / submit times"]
        Submit["Submit answers"]
        J["AI J (optional)"]
        Grade["Server-side grading<br/>Objective answers; rubric / review for essays"]
        Chosen --> Attempt --> Timer --> Submit --> Grade
        J -.-> Grade
    end
    J -.-> AIProvider
    UI --> Chosen
    Export --> Chosen
    Attempt --> Context
    Grade --> Context
    Grade -->|"Score and feedback"| UI

    classDef optional stroke-dasharray: 5 5
    class Moodle,ExamBase optional
```
