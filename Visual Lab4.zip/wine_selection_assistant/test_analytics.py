import unittest

import pandas as pd

from src.analytics import (
    ALL, SORT, FlavorIndex, country_summary, export_frame, get_data, get_flavors,
    metric_values, normalize_preferences, select_wines, shortlist_page,
)


class AnalyticsTests(unittest.TestCase):
    def test_default_data_and_denominator(self):
        dataframe = get_data()
        affordable, qualified = select_wines(dataframe, {})
        self.assertEqual(len(dataframe), 129971)
        self.assertEqual(dataframe.id.nunique(), len(dataframe))
        self.assertEqual((len(affordable), len(qualified)), (73455, 14516))
        self.assertEqual(metric_values(affordable, qualified), {"count": "14,516", "price": "$24", "rating": "90.8", "share": "19.8%"})

    def test_country_and_category_context(self):
        dataframe = get_data()
        selected, _ = select_wines(dataframe, {"country": "Portugal", "category": "red"})
        comparison, _ = select_wines(dataframe, {"country": "Portugal", "category": "red"}, include_country=False)
        distribution, _ = select_wines(dataframe, {"country": "Portugal", "category": "red"}, include_category=False)
        self.assertTrue(selected.country_display.eq("Portugal").all())
        self.assertGreater(comparison.country_display.nunique(), 1)
        self.assertGreater(distribution.category.nunique(), 1)
        summary = country_summary(comparison, 90)
        self.assertNotIn("Unknown", summary.country_display.tolist())
        self.assertTrue(summary.share.between(0, 100).all())

    def test_binary_phrases_boundaries_and_or_matching(self):
        index = FlavorIndex(pd.Series(["Cherry cherry and black cherry, vanilla.", "Peppercorn and oakwood.", "Oak, lemon.", ""]))
        counts = index.counts([0, 1, 2, 3]).set_index("term")
        self.assertEqual(counts.loc["cherry", "reviews"], 1)
        self.assertEqual(counts.loc["black cherry", "reviews"], 1)
        self.assertEqual(index.matches([0, 1, 2, 3], ["cherry", "lemon"]).tolist(), [True, False, True, False])
        self.assertEqual(index.matches([1], ["oak", "pepper"]).tolist(), [False])
        self.assertEqual(index.terms_for(3), [])

    def test_flavors_filter_numerator_and_denominator(self):
        dataframe = get_data()
        index = get_flavors()
        base, _ = select_wines(dataframe, {})
        affordable, qualified = select_wines(dataframe, {"flavors": ["cherry"]}, use_flavors=True, flavor_index=index)
        self.assertLess(len(affordable), len(base))
        self.assertTrue(index.matches(affordable.index.to_numpy(), ["cherry"]).all())
        self.assertTrue(qualified.points.ge(90).all())
        self.assertTrue(set(qualified.id).issubset(set(affordable.id)))

    def test_normalization_cleared_and_invalid_preferences(self):
        self.assertEqual(normalize_preferences({"budget": None})["budget"], 30)
        self.assertEqual(normalize_preferences({"budget": float("nan")})["budget"], 30)
        self.assertEqual(normalize_preferences({"rating": 200})["rating"], 100)
        self.assertEqual(normalize_preferences({"country": None})["country"], ALL)
        self.assertEqual(normalize_preferences({"flavors": ["cherry", "unknown", "cherry"]})["flavors"], ["cherry"])

    def test_empty_pagination_and_sorting(self):
        dataframe = get_data()
        _, qualified = select_wines(dataframe, {})
        records, pages, current = shortlist_page(qualified, 0, SORT)
        self.assertEqual((len(records), pages, current), (10, 1452, 0))
        self.assertEqual(records[0]["points"], 96)
        self.assertIn("id", records[0])
        self.assertEqual(shortlist_page(qualified.iloc[:0], 99), ([], 0, 0))
        self.assertEqual(shortlist_page(qualified.head(1), 999)[2], 0)

    def test_export_includes_all_matches_and_safe_text(self):
        _, qualified = select_wines(get_data(), {})
        exported = export_frame(qualified)
        self.assertEqual(len(exported), 14516)
        self.assertIn("description", exported)
        self.assertIn("country", exported)
        example = qualified.head(1).copy()
        example["title"] = "=SUM(1,2)"
        self.assertTrue(export_frame(example).iloc[0]["title"].startswith("'="))

    def test_map_codes_and_figure_coverage(self):
        from src.analytics import iso_country
        from src.figures import category_distribution, country_map, country_ranking, flavor_frequency, price_rating
        dataframe = get_data()
        affordable, qualified = select_wines(dataframe, {})
        summary = country_summary(affordable, 90)
        self.assertTrue(all(iso_country(name) for name in summary.country_display))
        self.assertEqual(iso_country("England"), "GBR")
        scatter = price_rating(affordable, normalize_preferences())
        self.assertEqual(sum(int(row[0]) for trace in scatter.data for row in trace.customdata), len(affordable))
        counts = get_flavors().counts(qualified.index.to_numpy())
        figures = [country_map(summary, 30, "Portugal"), country_ranking(summary, 30, ALL), category_distribution(affordable, ALL), flavor_frequency(counts, len(qualified), [])]
        for figure in figures:
            self.assertGreater(len(figure.data), 0)
            figure.to_json()


if __name__ == "__main__":
    unittest.main()