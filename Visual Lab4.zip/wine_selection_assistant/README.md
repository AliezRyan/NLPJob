# Wine Selection Assistant - Lab 4

Independent two-page Plotly Dash application, copied from Lab 2's Wine Value Atlas. The original `example_dashboard` project is not modified. This folder has its own source, data, assets, tests, virtual environment, and VS Code workspace.

Open `Wine Selection Assistant.code-workspace` to work on Lab 4 separately. The default selection is $30 or less and 90+ points.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows PowerShell, from this folder:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Put both `wine_category.csv` and `winemag-data-with-year.csv` under `data/`.

## Run

```bash
python app.py
```

Then open the local URL shown by Dash in your browser.

On Windows, run `.\.venv\Scripts\python.exe app.py` without activating the environment. The default URL is http://127.0.0.1:8051/. Set `PORT` to another port if needed. Run commands from this folder, not from Lab 2.

## What the dashboard does

- **Discover Value (`/`):** clickable world map, qualifying-share country ranking, and category distribution. Map/ranking compare all countries, with an adjustable minimum review count and a separate insufficient-sample color.
- **Find My Bottle (`/find`):** price-rating bubble chart, flavor-frequency bars, sortable/paginated shortlist, and original review details selected by review ID.
- Filters by budget, minimum rating, country, all six categories, and variety. Session preferences persist across pages and refreshes without mutable per-user server globals.
- Flavor filters match any selected descriptor (OR). Selecting a flavor bar toggles that descriptor; selecting a map country, ranking bar, or category bar updates the corresponding filter.
- Flavor frequency counts each descriptor once per review, using qualifying reviews before flavor filtering. Original descriptions and matched terms remain available as evidence.
- Summary metrics show qualifying review count, median price, average rating, and qualifying share. Flavor filters affect these metrics only on Find My Bottle.
- CSV export includes all qualifying reviews, full descriptions, and stable IDs, with text values escaped against spreadsheet formula injection.
- Responsive desktop/mobile layouts, reset-all and clear-country controls, explicit empty results, and a local map asset with a missing-asset fallback.

## Data notes

- `data/winemag-data-with-year.csv` contains the main wine review records.
- `data/wine_category.csv` maps varieties to broad wine categories.
- Year values outside a plausible range are ignored during cleaning.
- Reviews with missing or nonpositive prices, or missing ratings, are excluded from price comparisons.
- Qualifying share divides reviews meeting the rating target by **all** priced reviews within the budget and selected filters, including lower-rated reviews.
- Country comparisons ignore the country selection but respect budget, category, and variety. The minimum sample size applies to map eligibility and country rankings, not the shortlist.
- Category distribution ignores the category selection and rating target so all categories remain comparable; it respects country, budget, and variety.
- Flavor mentions use a fixed 40-term unigram/bigram vocabulary through scikit-learn's binary `CountVectorizer`. Whole-word matching avoids matching `oak` inside `oakwood`; terms such as `cherry` and `black cherry` may overlap. Negation and sentiment are not inferred.
- Flavor-share numerators and denominators use the same descriptor match. Frequency bars intentionally remain based on the pre-flavor qualifying selection and use nonempty descriptions for mention shares.
- Prices are historical USD values, not current retail offers. These are critic reviews, not a representative consumer survey; review coverage varies by country.

## Checks

```bash
python -m unittest discover -p "test_*.py" -v
```

On Windows, replace `python` with `.\.venv\Scripts\python.exe`.

## Visual Assets

The copied wine photograph is stored locally in `assets/wine.jpg` ([Unsplash](https://images.unsplash.com/photo-1510812431401-41d2bd2722f3)). The map uses a local copy of [Plotly's world topology](https://cdn.plot.ly/world_110m.json) in `assets/world_110m.json`. Fonts use Google Fonts; Lucide icons load through Iconify. Those optional visual services require internet access; review data and chart calculations stay local.
