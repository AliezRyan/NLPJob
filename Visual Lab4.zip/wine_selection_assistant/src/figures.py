from __future__ import annotations

import plotly.express as px
import plotly.graph_objects as go

from src.analytics import CATEGORIES, iso_country


GREEN = "#167055"
ROSE = "#a84260"
INK = "#263a33"
GRAPH_CONFIG = {"displayModeBar": False, "topojsonURL": "/assets/"}


def style_figure(figure, height=320):
    figure.update_layout(
        template="plotly_white", height=height, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="DM Sans, sans-serif", size=12, color=INK),
        margin=dict(l=8, r=26, t=12, b=42),
        hoverlabel=dict(bgcolor="white", font_color=INK),
        legend=dict(title_text="", orientation="h", y=1.15, x=0),
    )
    figure.update_xaxes(gridcolor="#e8eeea", zeroline=False, automargin=True)
    figure.update_yaxes(gridcolor="#e8eeea", zeroline=False, automargin=True)
    return figure


def empty_figure(message):
    figure = style_figure(go.Figure())
    figure.add_annotation(text=message, x=0.5, y=0.5, xref="paper", yref="paper", showarrow=False, font=dict(size=13, color="#65776f"))
    figure.update_xaxes(visible=False)
    figure.update_yaxes(visible=False)
    return figure


def country_map(summary, minimum, selected):
    if summary.empty:
        return empty_figure("No country reviews within this budget.")
    summary = summary.copy()
    summary["iso"] = summary["country_display"].map(iso_country)
    summary = summary.dropna(subset=["iso"])
    eligible = summary.loc[summary["reviews"].ge(minimum)]
    insufficient = summary.loc[summary["reviews"].lt(minimum)]
    figure = go.Figure()
    if len(insufficient):
        figure.add_trace(go.Choropleth(
            locations=insufficient["iso"], z=[0] * len(insufficient),
            colorscale=[[0, "#d1d7d2"], [1, "#d1d7d2"]], showscale=False,
            customdata=insufficient[["country_display", "qualified", "reviews", "share"]].to_numpy(),
            hovertemplate="<b>%{customdata[0]}</b><br>Insufficient sample<br>%{customdata[2]:,} budget reviews<extra></extra>",
            marker_line_color="white", marker_line_width=0.5,
        ))
    if len(eligible):
        figure.add_trace(go.Choropleth(
            locations=eligible["iso"], z=eligible["share"], zmin=0, zmax=100,
            colorscale=[[0, "#ecf0d2"], [0.5, "#6ba783"], [1, "#12634d"]],
            colorbar=dict(title="Qualifying %", thickness=10, len=0.65, ticksuffix="%", outlinewidth=0),
            customdata=eligible[["country_display", "qualified", "reviews", "share"]].to_numpy(),
            hovertemplate="<b>%{customdata[0]}</b><br>%{z:.1f}% meet target<br>%{customdata[1]:,} of %{customdata[2]:,} budget reviews<extra></extra>",
            marker_line_color="white", marker_line_width=0.6,
        ))
    chosen = summary.loc[summary["country_display"].eq(selected)]
    if len(chosen):
        figure.add_trace(go.Choropleth(
            locations=chosen["iso"], z=[0], colorscale=[[0, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0)"]],
            showscale=False, marker_line_color=ROSE, marker_line_width=2,
            customdata=chosen[["country_display", "qualified", "reviews", "share"]].to_numpy(),
            hovertemplate="<b>%{customdata[0]} (selected)</b><br>%{customdata[2]:,} budget reviews<extra></extra>",
        ))
    style_figure(figure)
    figure.update_layout(margin=dict(l=0, r=5, t=0, b=0), geo=dict(
        projection_type="natural earth", showframe=False, showcoastlines=False,
        showland=True, landcolor="#f1f3ef", showcountries=True, countrycolor="white",
        bgcolor="rgba(0,0,0,0)", lataxis_range=[-60, 85],
    ))
    return figure


def country_ranking(summary, minimum, selected):
    top = summary.loc[summary["reviews"].ge(minimum)].head(10)
    if top.empty:
        return empty_figure("No countries meet the minimum review count.")
    figure = go.Figure(go.Bar(
        x=top["share"], y=top["country_display"], orientation="h",
        marker_color=[ROSE if name == selected else GREEN for name in top["country_display"]],
        text=[f"{share:.1f}%" for share in top["share"]], textposition="outside", cliponaxis=False,
        customdata=top[["country_display", "qualified", "reviews"]].to_numpy(),
        hovertemplate="<b>%{y}</b><br>%{x:.1f}% meet target<br>%{customdata[1]:,} / %{customdata[2]:,} budget reviews<extra></extra>",
    ))
    style_figure(figure)
    figure.update_layout(bargap=0.4, margin=dict(l=8, r=40, t=8, b=40))
    figure.update_xaxes(title="Qualifying review share (%)", ticksuffix="%", range=[0, min(110, max(10, top["share"].max() * 1.2))])
    figure.update_yaxes(autorange="reversed", showgrid=False)
    return figure


def category_distribution(affordable, selected):
    if affordable.empty:
        return empty_figure("No category reviews within this budget.")
    counts = affordable["category"].value_counts()
    figure = go.Figure(go.Bar(
        x=counts.values, y=[CATEGORIES.get(name, name.title()) for name in counts.index], orientation="h",
        marker_color=[ROSE if name == selected else GREEN for name in counts.index],
        customdata=[[name] for name in counts.index],
        text=[f"{count:,}" for count in counts.values], textposition="outside", cliponaxis=False,
        hovertemplate="<b>%{y}</b><br>%{x:,} budget reviews<extra></extra>",
    ))
    style_figure(figure)
    figure.update_layout(bargap=0.5, margin=dict(l=8, r=45, t=8, b=40))
    figure.update_xaxes(title="Budget reviews (all ratings)", range=[0, counts.max() * 1.22])
    figure.update_yaxes(autorange="reversed", showgrid=False)
    return figure


def price_rating(affordable, preferences):
    if affordable.empty:
        return empty_figure("No priced reviews match these preferences.")
    bubbles = affordable.groupby(["price", "points"], as_index=False).size().rename(columns={"size": "reviews"})
    bubbles["target"] = bubbles["points"].ge(preferences["rating"]).map({True: "Meets target", False: "Below target"})
    figure = px.scatter(
        bubbles, x="price", y="points", size="reviews", size_max=24, color="target",
        color_discrete_map={"Meets target": GREEN, "Below target": "#c0cbc5"},
        category_orders={"target": ["Meets target", "Below target"]}, custom_data=["reviews"],
        labels={"price": "Historical price ($)", "points": "Rating (points)"},
    )
    figure.update_traces(marker=dict(opacity=0.7, line=dict(width=0.5, color="white")), hovertemplate="$%{x:,.0f}<br>%{y} points<br>%{customdata[0]:,} reviews<extra></extra>")
    figure.add_hline(y=preferences["rating"], line_dash="dot", line_color=ROSE, line_width=1.5)
    style_figure(figure)
    figure.update_xaxes(range=[0, preferences["budget"] * 1.05])
    figure.update_yaxes(range=[79, 101], dtick=5)
    return figure


def flavor_frequency(counts, denominator, selected):
    if counts.empty:
        return empty_figure("No flavor descriptors in qualifying reviews.")
    top = counts.head(10)
    figure = go.Figure(go.Bar(
        x=top["reviews"], y=top["term"], orientation="h",
        marker_color=[ROSE if term in selected else GREEN for term in top["term"]],
        customdata=[[term, count / denominator * 100 if denominator else 0] for term, count in zip(top["term"], top["reviews"])],
        hovertemplate="<b>%{y}</b><br>%{x:,} reviews<br>%{customdata[1]:.1f}% of nonempty descriptions<extra></extra>",
    ))
    style_figure(figure)
    figure.update_layout(bargap=0.35)
    figure.update_xaxes(title="Qualifying reviews mentioning each term")
    figure.update_yaxes(autorange="reversed", showgrid=False)
    return figure