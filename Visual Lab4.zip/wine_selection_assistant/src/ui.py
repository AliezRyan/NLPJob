from __future__ import annotations

import re

from dash import dash_table, dcc, html
from dash.dash_table.Format import Format, Scheme, Symbol
from dash_iconify import DashIconify

from src.analytics import SORT
from src.figures import GRAPH_CONFIG, GREEN, INK


def icon(name, size=18):
    return DashIconify(icon=f"lucide:{name}", width=size, height=size)


def page_heading(step, title, subtitle, action=None):
    return html.Div(className="application-heading", children=[
        html.Div([html.P(step, className="eyebrow"), html.H1(title), html.P(subtitle, className="subtitle")]),
        action,
    ])


def chart_section(number, title, graph_id, caption, caption_id=None, class_name=""):
    return html.Section(className=f"chart-section {class_name}", children=[
        html.Div(className="section-heading", children=[html.Div([
            html.P(number, className="section-kicker"), html.H3(title),
        ])]),
        html.P(caption, id=caption_id, className="chart-caption") if caption_id else html.P(caption, className="chart-caption"),
        dcc.Loading(dcc.Graph(id=graph_id, config=GRAPH_CONFIG, responsive=True), color=GREEN, delay_show=300),
    ])


def wine_table():
    return dash_table.DataTable(
        id="wine-table", columns=[
            {"name": "Wine", "id": "title"}, {"name": "Country", "id": "country_display"},
            {"name": "Variety", "id": "variety"}, {"name": "Winery", "id": "winery"},
            {"name": "Vintage", "id": "year"},
            {"name": "Points", "id": "points", "type": "numeric"},
            {"name": "Price", "id": "price", "type": "numeric", "format": Format(precision=0, scheme=Scheme.fixed, symbol=Symbol.yes, symbol_prefix="$")},
        ], data=[], page_action="custom", page_current=0, page_size=10, page_count=0,
        sort_action="custom", sort_mode="multi", sort_by=SORT,
        cell_selectable=True,
        style_table={"overflowX": "auto", "width": "100%"},
        style_cell={"fontFamily": "DM Sans, sans-serif", "fontSize": 12, "textAlign": "left", "padding": "12px", "border": "none", "borderBottom": "1px solid #e8eeea", "color": INK, "backgroundColor": "white", "minWidth": "75px", "maxWidth": "260px", "whiteSpace": "normal", "height": "auto", "cursor": "pointer"},
        style_header={"fontWeight": 600, "fontSize": 11, "backgroundColor": "#f3f6f4", "color": "#65776f", "borderBottom": "1px solid #dce5df"},
        style_cell_conditional=[{"if": {"column_id": "title"}, "minWidth": "230px", "fontWeight": 500}, {"if": {"column_id": "points"}, "fontWeight": 700, "color": GREEN}],
        style_data_conditional=[{"if": {"state": "active"}, "backgroundColor": "#edf6f1", "border": "1px solid #167055"}],
        css=[{"selector": ".show-hide", "rule": "display:none"}],
    )


def review_detail(record, terms, selected_terms):
    year = str(int(record["year"])) if record["year"] == record["year"] else "Unknown vintage"
    pattern = r"\b(" + "|".join(re.escape(term).replace(r"\ ", r"[\s-]+") for term in sorted(terms, key=len, reverse=True)) + r")\b" if terms else None
    description = record.get("description") or "No description is available for this review."
    pieces = re.split(pattern, description, flags=re.IGNORECASE) if pattern else [description]
    return html.Div([
        html.Div(className="review-heading", children=[
            html.Div([html.P(f"REVIEW {int(record['id']):,}", className="section-kicker"), html.H3(record["title"])]),
            html.Div(className="review-score", children=[html.Strong(f"{record['points']:.0f}"), html.Span("POINTS")]),
        ]),
        html.P(f"{record['winery']} | {record['country_display']} | {record['variety']}", className="review-origin"),
        html.Div(className="review-meta", children=[html.Span(f"${record['price']:,.0f} historical price"), html.Span(year)]),
        html.P([html.Mark(piece) if index % 2 else piece for index, piece in enumerate(pieces)], className="review-description"),
        html.Div(className="descriptor-tags", children=[html.Span(term, className="descriptor-tag selected" if term in selected_terms else "descriptor-tag") for term in terms]),
        html.P("Descriptor mentions are reviewer language, not a measurement of flavor intensity.", className="review-disclaimer"),
    ])