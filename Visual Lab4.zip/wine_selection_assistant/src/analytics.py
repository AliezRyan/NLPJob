from __future__ import annotations

import math
from functools import lru_cache

import numpy as np
import pandas as pd
import pycountry
from sklearn.feature_extraction.text import CountVectorizer

from src.data_loader import load_wine_data


ALL = "__all__"
CATEGORIES = {"red": "Red", "white": "White", "sparkling": "Sparkling", "rose": "Rose", "dessert": "Dessert", "other": "Other"}
DEFAULTS = {"budget": 30, "rating": 90, "country": ALL, "category": ALL, "variety": ALL, "minimum_reviews": 30, "flavors": []}
DESCRIPTORS = (
    "apple", "apricot", "black cherry", "black fruit", "blackberry", "blueberry", "butter",
    "caramel", "cedar", "cherry", "chocolate", "citrus", "coffee", "cranberry", "earth",
    "fig", "floral", "grapefruit", "herb", "honey", "leather", "lemon", "lime", "mineral",
    "oak", "orange", "peach", "pear", "pepper", "pineapple", "plum", "raspberry",
    "red fruit", "rose", "smoke", "spice", "strawberry", "tobacco", "tropical fruit", "vanilla",
)
SORT = [{"column_id": "points", "direction": "desc"}, {"column_id": "price", "direction": "asc"}]
TABLE_FIELDS = ["id", "title", "country_display", "variety", "winery", "year", "points", "price"]


def normalize_preferences(values=None):
    values = values or {}
    result = {**DEFAULTS, **{key: value for key, value in values.items() if key in DEFAULTS}}
    for key, lower, upper in [("budget", 4, 3300), ("rating", 80, 100), ("minimum_reviews", 1, 100000)]:
        try:
            number = float(result[key])
            if not math.isfinite(number):
                raise ValueError
        except (TypeError, ValueError):
            number = DEFAULTS[key]
        result[key] = max(lower, min(upper, number))
    result["minimum_reviews"] = int(result["minimum_reviews"])
    for key in ["country", "category", "variety"]:
        if not isinstance(result[key], str) or not result[key]:
            result[key] = ALL
    result["flavors"] = list(dict.fromkeys(term for term in (result.get("flavors") or []) if term in DESCRIPTORS))
    return result


@lru_cache(maxsize=1)
def get_data():
    dataframe = load_wine_data().reset_index(drop=True)
    if dataframe["id"].duplicated().any():
        raise ValueError("Review IDs must be unique.")
    return dataframe


class FlavorIndex:
    def __init__(self, descriptions):
        self.vectorizer = CountVectorizer(vocabulary=list(DESCRIPTORS), ngram_range=(1, 2), binary=True, strip_accents="unicode")
        self.matrix = self.vectorizer.fit_transform(descriptions.fillna("").astype(str))
        self.terms = self.vectorizer.get_feature_names_out()

    def matches(self, rows, terms):
        if not terms:
            return np.ones(len(rows), dtype=bool)
        columns = [self.vectorizer.vocabulary_[term] for term in terms if term in self.vectorizer.vocabulary_]
        if not columns:
            return np.zeros(len(rows), dtype=bool)
        return np.asarray(self.matrix[rows][:, columns].sum(axis=1)).ravel() > 0

    def counts(self, rows):
        counts = np.asarray(self.matrix[rows].sum(axis=0)).ravel()
        return pd.DataFrame({"term": self.terms, "reviews": counts}).loc[lambda frame: frame["reviews"].gt(0)].sort_values(["reviews", "term"], ascending=[False, True])

    def terms_for(self, position):
        return self.terms[self.matrix[position].indices].tolist()


@lru_cache(maxsize=1)
def get_flavors():
    return FlavorIndex(get_data()["description"])


def select_wines(dataframe, preferences, include_country=True, include_category=True, use_flavors=False, flavor_index=None):
    preferences = normalize_preferences(preferences)
    mask = dataframe["price"].gt(0) & dataframe["price"].le(preferences["budget"]) & dataframe["points"].notna()
    fields = [("variety", "variety", True), ("country_display", "country", include_country), ("category", "category", include_category)]
    for column, key, enabled in fields:
        if enabled and preferences[key] != ALL:
            mask &= dataframe[column].eq(preferences[key])
    affordable = dataframe.loc[mask]
    if use_flavors and preferences["flavors"]:
        flavor_index = flavor_index or get_flavors()
        affordable = affordable.loc[flavor_index.matches(affordable.index.to_numpy(), preferences["flavors"])]
    return affordable, affordable.loc[affordable["points"].ge(preferences["rating"])]


def country_summary(affordable, rating):
    known = affordable.loc[affordable["country_display"].ne("Unknown")].copy()
    known["qualifies"] = known["points"].ge(rating)
    summary = known.groupby("country_display", as_index=False).agg(reviews=("points", "size"), qualified=("qualifies", "sum"))
    summary["share"] = summary["qualified"] / summary["reviews"] * 100
    return summary.sort_values(["share", "qualified", "country_display"], ascending=[False, False, True])


def iso_country(name):
    name = {"England": "GBR", "Macedonia": "MKD", "Turkey": "TUR"}.get(name, name)
    try:
        return pycountry.countries.lookup(name).alpha_3
    except LookupError:
        return None


def metric_values(affordable, qualified):
    return {
        "count": f"{len(qualified):,}",
        "price": f"${qualified['price'].median():,.0f}" if len(qualified) else "-",
        "rating": f"{qualified['points'].mean():.1f}" if len(qualified) else "-",
        "share": f"{len(qualified) / len(affordable) * 100:.1f}%" if len(affordable) else "-",
    }


def shortlist_page(qualified, current=0, sort_by=None, size=10):
    valid_sort = [item for item in (sort_by or SORT) if item["column_id"] in TABLE_FIELDS]
    if valid_sort:
        qualified = qualified.sort_values([item["column_id"] for item in valid_sort], ascending=[item["direction"] == "asc" for item in valid_sort], kind="stable")
    pages = math.ceil(len(qualified) / size)
    current = max(0, min(int(current or 0), max(0, pages - 1)))
    rows = qualified.iloc[current * size:(current + 1) * size][TABLE_FIELDS].copy()
    rows["year"] = rows["year"].map(lambda value: str(int(value)) if pd.notna(value) else "-")
    return rows.astype(object).where(pd.notna(rows), None).to_dict("records"), pages, current


def export_frame(qualified):
    columns = ["id", "title", "winery", "country_display", "variety", "category", "year", "points", "price", "description"]
    exported = qualified.sort_values(["points", "price"], ascending=[False, True])[columns].copy().rename(columns={"country_display": "country"})
    for column in ["title", "winery", "country", "variety", "category", "description"]:
        exported[column] = exported[column].map(lambda value: "'" + value if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")) else value)
    return exported