import dash
from dash import Input, Output, State, callback, ctx, dcc, html

from src.analytics import export_frame, get_data, get_flavors, normalize_preferences, select_wines, shortlist_page
from src.figures import flavor_frequency, price_rating
from src.ui import chart_section, icon, page_heading, review_detail, wine_table


dash.register_page(__name__, path="/find", name="Find My Bottle", title="Find My Bottle | Wine Value Atlas")

layout = html.Div([
    dcc.Store(id="selected-review", storage_type="session"),
    page_heading("02 / FIND MY BOTTLE", "Find your next good bottle.", "A thoughtful shortlist, with the review behind every rating.",
        dcc.Link([icon("arrow-left", 16), "Explore origins"], href="/", className="secondary-link")),
    html.Div(className="chart-grid", children=[
        chart_section("PRICE AND QUALITY", "Your budget, in perspective", "price-chart", "Bubble area represents review count; lower-rated reviews remain visible."),
        chart_section("THE REVIEW VOCABULARY", "What reviewers taste", "flavor-chart", "", "flavor-caption"),
    ]),
    html.Section(className="shortlist-section", children=[
        html.Div(className="section-heading", children=[html.Div([html.P("THE MATCHING REVIEWS", className="section-kicker"), html.H3("Your shortlist"), html.P(id="shortlist-caption", className="chart-caption")]),
            html.Button([icon("download", 16), "Export CSV"], id="export-button", className="export-button", title="Download all qualifying reviews")]),
        html.Div(id="table-empty", className="empty-message"),
        dcc.Loading(wine_table(), color="#167055", delay_show=300),
    ]),
    html.Section(className="review-section", children=[html.Div(className="section-heading", children=[html.Div([html.P("IN THE REVIEWER'S WORDS", className="section-kicker"), html.H3("Beyond the score")])]), html.Div(id="review-detail")]),
    dcc.Download(id="shortlist-download"),
])


@callback(
    Output("price-chart", "figure"), Output("flavor-chart", "figure"), Output("flavor-caption", "children"),
    Output("wine-table", "data"), Output("wine-table", "page_count"), Output("wine-table", "page_current"),
    Output("shortlist-caption", "children"), Output("table-empty", "children"), Output("export-button", "disabled"),
    Input("preferences", "data"), Input("wine-table", "page_current"), Input("wine-table", "sort_by"),
)
def update_find(values, current_page, sort_by):
    preferences = normalize_preferences(values)
    dataframe = get_data()
    index = get_flavors()
    _, before_flavor = select_wines(dataframe, preferences)
    affordable, qualified = select_wines(dataframe, preferences, use_flavors=True)
    counts = index.counts(before_flavor.index.to_numpy())
    denominator = int(before_flavor["description"].str.strip().ne("").sum())
    page = current_page if "wine-table.page_current" in ctx.triggered_prop_ids else 0
    records, pages, current = shortlist_page(qualified, page, sort_by)
    return (
        price_rating(affordable, preferences), flavor_frequency(counts, denominator, preferences["flavors"]),
        f"Before flavor filtering: {denominator:,} qualifying reviews with descriptions. Each term counts once per review.",
        records, pages, current, f"{len(qualified):,} qualifying reviews | Highest rating, then lowest price by default.",
        "No matching reviews for this combination." if qualified.empty else "", qualified.empty,
    )


@callback(
    Output("review-detail", "children"), Output("selected-review", "data"),
    Input("preferences", "data"), Input("wine-table", "active_cell"), Input("wine-table", "data"),
    State("selected-review", "data"),
)
def update_review(values, active_cell, rows, selected_id):
    preferences = normalize_preferences(values)
    _, qualified = select_wines(get_data(), preferences, use_flavors=True)
    if "wine-table.active_cell" in ctx.triggered_prop_ids and active_cell:
        selected_id = active_cell.get("row_id")
    elif not ctx.triggered_id and selected_id is None and len(qualified):
        selected_id = int(qualified.sort_values(["points", "price"], ascending=[False, True]).iloc[0]["id"])
    match = qualified.loc[qualified["id"].eq(selected_id)] if selected_id is not None else qualified.iloc[:0]
    if match.empty:
        return html.P("No review selected." if len(qualified) else "No qualifying review is available for this selection.", className="review-empty"), None
    record = match.iloc[0]
    return review_detail(record, get_flavors().terms_for(int(match.index[0])), preferences["flavors"]), int(record["id"])


@callback(Output("shortlist-download", "data"), Input("export-button", "n_clicks"), State("preferences", "data"), prevent_initial_call=True)
def export_shortlist(clicks, values):
    _, qualified = select_wines(get_data(), values, use_flavors=True)
    return dcc.send_data_frame(export_frame(qualified).to_csv, "wine-selection-shortlist.csv", index=False)