from pathlib import Path

import dash
from dash import Input, Output, callback, dcc, html

from src.analytics import ALL, country_summary, get_data, normalize_preferences, select_wines
from src.figures import category_distribution, country_map, country_ranking, empty_figure
from src.ui import chart_section, icon, page_heading


dash.register_page(__name__, path="/", name="Discover Wine Value", title="Discover Wine Value | Wine Value Atlas")

layout = html.Div([
    dcc.Store(id="explore-ready", data=True),
    page_heading("01 / DISCOVER WINE VALUE", "A world of value awaits.", "Compare origins. Find the possibilities within your budget.",
        dcc.Link(["Find matching wines", icon("arrow-right", 16)], href="/find", className="primary-link")),
    html.Div(id="explore-insight", className="insight-band"),
    html.Section(className="chart-section map-section", children=[
        html.Div(className="section-heading", children=[html.Div([html.P("THE GLOBAL PICTURE", className="section-kicker"), html.H3("Where your budget goes further")]), html.Span(id="map-coverage", className="chart-tag")]),
        html.P(id="map-caption", className="chart-caption"),
        dcc.Loading(dcc.Graph(id="country-map", config={"displayModeBar": False, "topojsonURL": "/assets/"}, responsive=True), color="#167055", delay_show=300),
        html.Div(className="map-key", children=[html.Span([html.I(className="swatch sample"), "Insufficient sample"]), html.Span([html.I(className="swatch no-data"), "No budget reviews"]), html.Span([html.I(className="swatch selection"), "Selected country"])]),
    ]),
    html.Div(className="chart-grid", children=[
        chart_section("COMPARE ORIGINS", "The value ranking", "country-chart", "All countries; minimum sample size applies.", "ranking-caption"),
        chart_section("EXPLORE THE MIX", "Wine categories", "category-chart", "", "category-caption"),
    ]),
])


@callback(
    Output("country-map", "figure"), Output("country-chart", "figure"), Output("category-chart", "figure"),
    Output("explore-insight", "children"), Output("map-coverage", "children"),
    Output("map-caption", "children"), Output("ranking-caption", "children"), Output("category-caption", "children"),
    Input("preferences", "data"), Input("explore-ready", "data"),
)
def update_explore(values, ready):
    preferences = normalize_preferences(values)
    dataframe = get_data()
    comparison, _ = select_wines(dataframe, preferences, include_country=False)
    distribution, _ = select_wines(dataframe, preferences, include_category=False)
    summary = country_summary(comparison, preferences["rating"])
    eligible = summary.loc[summary["reviews"].ge(preferences["minimum_reviews"])]
    if len(eligible) and eligible.iloc[0]["qualified"] > 0:
        leader = eligible.iloc[0]
        title = f"{leader['country_display']} leads this budget comparison."
        detail = f"{leader['share']:.1f}% meet your rating target: {int(leader['qualified']):,} of {int(leader['reviews']):,} budget reviews. Rankings describe this archive, not all wines."
    else:
        title = "No country meets both targets in this comparison."
        detail = "The sample-size threshold applies to country comparisons, not to your wine shortlist."
    map_asset = Path(__file__).resolve().parents[1] / "assets" / "world_110m.json"
    figure = country_map(summary, preferences["minimum_reviews"], preferences["country"]) if map_asset.exists() else empty_figure("Map unavailable; country ranking remains available.")
    scope = "All countries" if preferences["country"] == ALL else preferences["country"]
    return (
        figure, country_ranking(summary, preferences["minimum_reviews"], preferences["country"]),
        category_distribution(distribution, preferences["category"]),
        [html.Span(icon("sparkles", 20), className="insight-icon"), html.Div([html.Strong(title), html.P(detail)])],
        f"{len(eligible)} eligible countries",
        f"Share of priced reviews at ${preferences['budget']:,.0f} or less scoring {preferences['rating']:g}+. Same category and variety across all countries.",
        f"Qualifying share; at least {preferences['minimum_reviews']:,} budget reviews per country.",
        f"{scope}; all categories and ratings, within your budget and variety.",
    )