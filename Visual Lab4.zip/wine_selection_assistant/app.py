from __future__ import annotations

import os
from pathlib import Path

import dash
from dash import Dash, Input, Output, State, ctx, dcc, html, no_update

from src.analytics import ALL, CATEGORIES, DEFAULTS, DESCRIPTORS, get_data, get_flavors, metric_values, normalize_preferences, select_wines
from src.data_loader import get_country_options, get_variety_options
from src.ui import icon


data = get_data()
get_flavors()
CONTROL_IDS = ["budget-input", "rating-slider", "country-dropdown", "category-dropdown", "variety-dropdown", "minimum-reviews", "flavor-dropdown"]
CONTROL_KEYS = ["budget", "rating", "country", "category", "variety", "minimum_reviews", "flavors"]
app = Dash(__name__, use_pages=True, pages_folder=str(Path(__file__).parent / "pages"), suppress_callback_exceptions=True, title="Wine Selection Assistant", update_title="Updating selection...")
server = app.server


def metric(label, value_id, note_id, accent=False):
    return html.Div(className="metric metric-accent" if accent else "metric", children=[html.Span(label, className="metric-label"), html.Strong(id=value_id), html.Span(id=note_id, className="metric-note")])


app.layout = html.Div([
    dcc.Location(id="url", refresh=False),
    dcc.Store(id="preferences", storage_type="session", data=DEFAULTS),
    html.Header(className="topbar", children=[
        dcc.Link([html.Span(icon("wine", 24), className="brand-mark"), "Wine Value Atlas"], href="/", className="brand"),
        html.Nav(className="page-nav", children=[dcc.Link([icon("compass", 16), "Discover Value"], href="/", id="explore-link"), dcc.Link([icon("glass-water", 16), "Find My Bottle"], href="/find", id="find-link")]),
        html.Span("LAB 04 / WINE SELECTION", className="source-label"),
    ]),
    html.Div(className="workspace application-workspace", children=[
        html.Aside(className="filters", children=[
            html.Div(className="filter-heading", children=[html.H2("Your preferences"), html.Button(icon("rotate-ccw"), id="reset-filters", title="Reset all preferences", **{"aria-label": "Reset all preferences"}, className="icon-button")]),
            html.Div(className="filter-field", children=[html.Label("Maximum price", htmlFor="budget-input"), html.Div(className="money-input", children=[html.Span("$"), dcc.Input(id="budget-input", type="number", min=4, max=3300, step=1, value=30, debounce=0.4)])]),
            html.Div(className="filter-field", children=[html.Div(className="label-row", children=[html.Label("Minimum rating", htmlFor="rating-slider"), html.Strong(id="rating-label")]), dcc.Slider(id="rating-slider", min=80, max=100, step=1, value=90, marks={80: "80", 85: "85", 90: "90", 95: "95", 100: "100"})]),
            html.Div(className="filter-field", children=[html.Div(className="label-row", children=[html.Label("Country", htmlFor="country-dropdown"), html.Button(icon("x", 13), id="reset-country", title="Clear country selection", **{"aria-label": "Clear country selection"}, className="clear-country")]), dcc.Dropdown(id="country-dropdown", options=get_country_options(data), value=ALL, clearable=False)]),
            html.Div(className="filter-field", children=[html.Label("Wine category", htmlFor="category-dropdown"), dcc.Dropdown(id="category-dropdown", options=[{"label": "All categories", "value": ALL}] + [{"label": label, "value": key} for key, label in CATEGORIES.items()], value=ALL, clearable=False)]),
            html.Div(className="filter-field", children=[html.Label("Grape variety", htmlFor="variety-dropdown"), dcc.Dropdown(id="variety-dropdown", options=get_variety_options(data, limit=data.variety.nunique()), value=ALL, clearable=False)]),
            html.Div(id="sample-control", className="filter-field sample-field", children=[html.Label("Minimum country reviews", htmlFor="minimum-reviews"), dcc.Input(id="minimum-reviews", type="number", min=1, max=100000, value=30, step=1, debounce=0.4)]),
            html.Div(id="flavor-control", className="filter-field sample-field", style={"display": "none"}, children=[html.Label("Flavor mentions (any selected)", htmlFor="flavor-dropdown"), dcc.Dropdown(id="flavor-dropdown", options=[{"label": term.title(), "value": term} for term in DESCRIPTORS], value=[], multi=True, placeholder="Any flavor", clearable=True), html.P("Based on terms mentioned in critic reviews.", className="field-note")]),
            html.Figure(className="wine-image", children=[html.Img(src="/assets/wine.jpg", alt="Glasses of red wine raised around a table"), html.Figcaption("Good taste. Thoughtful spending.")]),
            html.Div(className="archive-note", children=[icon("info", 16), html.P("Historical USD prices, not current retail offers. Critic-review coverage differs by country.")]),
        ]),
        html.Main(className="results", children=[
            html.Div(className="selection-heading application-selection", children=[html.Span(id="selection-title"), html.Span(id="selection-scope")]),
            html.Div(className="metrics", children=[metric("Qualifying reviews", "kpi-count", "note-count", True), metric("Median price", "kpi-price", "note-price"), metric("Average rating", "kpi-rating", "note-rating"), metric("Qualifying share", "kpi-share", "note-share")]),
            dash.page_container,
            html.Details(className="methodology", children=[html.Summary("Data & methodology"), html.P(
                f"Source: Wine Enthusiast archive, {len(data):,} review records. Each row is a review, not a unique bottle or consumer preference. "
                "Price comparisons exclude missing/nonpositive prices and missing ratings. Qualifying share divides reviews meeting the rating target "
                "by all budget reviews under the same active filters, including lower-rated reviews. Country comparisons ignore the selected country; "
                "the category distribution ignores the selected category. Sample thresholds apply only to country comparisons. "
                "Flavor filters apply on Find My Bottle only, with OR matching. Frequency bars use qualifying reviews before flavor filtering, counting each descriptor once per review. "
                "Overlapping terms such as cherry and black cherry can both be counted. Mentions do not measure intensity or sentiment; negation requires reading the original review. "
                "Prices are historical USD values and are not inflation-adjusted. Rankings describe this unevenly reviewed archive, not current stock or country-wide wine quality."
            )]),
        ]),
    ]),
    html.Footer([html.Span("WINE VALUE ATLAS / LAB 04"), html.Span("A little research. A better bottle.")]),
])


@app.callback(
    Output("preferences", "data"), *[Output(identifier, "value") for identifier in CONTROL_IDS],
    Input("preferences", "modified_timestamp"), *[Input(identifier, "value") for identifier in CONTROL_IDS],
    Input("reset-filters", "n_clicks"), Input("reset-country", "n_clicks"),
    Input("country-map", "clickData", allow_optional=True), Input("country-chart", "clickData", allow_optional=True),
    Input("category-chart", "clickData", allow_optional=True), Input("flavor-chart", "clickData", allow_optional=True),
    State("preferences", "data"),
)
def sync_preferences(timestamp, budget, rating, country, category, variety, minimum, flavors, resets, country_resets, map_click, ranking_click, category_click, flavor_click, stored):
    preferences = normalize_preferences(stored)
    current_values = [budget, rating, country, category, variety, minimum, flavors]
    trigger = ctx.triggered_id
    if trigger == "reset-filters":
        preferences = normalize_preferences()
    elif trigger == "reset-country":
        preferences["country"] = ALL
    elif trigger in CONTROL_IDS:
        preferences[CONTROL_KEYS[CONTROL_IDS.index(trigger)]] = current_values[CONTROL_IDS.index(trigger)]
    elif trigger in ["country-map", "country-chart", "category-chart", "flavor-chart"]:
        click = {"country-map": map_click, "country-chart": ranking_click, "category-chart": category_click, "flavor-chart": flavor_click}[trigger]
        points = (click or {}).get("points", [])
        custom = points[0].get("customdata", []) if points else []
        if len(custom):
            value = custom[0]
            if trigger in ["country-map", "country-chart"] and value in data.country_display.values:
                preferences["country"] = value
            elif trigger == "category-chart" and value in CATEGORIES:
                preferences["category"] = value
            elif trigger == "flavor-chart" and value in DESCRIPTORS:
                preferences["flavors"] = [term for term in preferences["flavors"] if term != value] if value in preferences["flavors"] else preferences["flavors"] + [value]
    preferences = normalize_preferences(preferences)
    outputs = [preferences if preferences != stored else no_update]
    outputs += [preferences[key] if current != preferences[key] else no_update for current, key in zip(current_values, CONTROL_KEYS)]
    return outputs


@app.callback(
    Output("kpi-count", "children"), Output("kpi-price", "children"), Output("kpi-rating", "children"), Output("kpi-share", "children"),
    Output("note-count", "children"), Output("note-price", "children"), Output("note-rating", "children"), Output("note-share", "children"),
    Output("selection-title", "children"), Output("selection-scope", "children"), Output("rating-label", "children"),
    Output("explore-link", "className"), Output("find-link", "className"), Output("flavor-control", "style"), Output("sample-control", "style"),
    Input("preferences", "data"), Input("url", "pathname"),
)
def update_summary(values, pathname):
    preferences = normalize_preferences(values)
    finding = (pathname or "/").rstrip("/") == "/find"
    affordable, qualified = select_wines(data, preferences, use_flavors=finding)
    metrics = metric_values(affordable, qualified)
    scope = "All countries" if preferences["country"] == ALL else preferences["country"]
    if preferences["category"] != ALL:
        scope += f" / {CATEGORIES.get(preferences['category'], preferences['category'])}"
    if finding and preferences["flavors"]:
        scope += f" / {len(preferences['flavors'])} flavor(s)"
    return (
        metrics["count"], metrics["price"], metrics["rating"], metrics["share"],
        f"{preferences['rating']:g}+ points within budget", "among qualifying reviews", "among qualifying reviews", f"of {len(affordable):,} budget reviews",
        f"${preferences['budget']:,.0f} or less / {preferences['rating']:g}+ points", scope, f"{preferences['rating']:g} pts",
        "nav-link" if finding else "nav-link active", "nav-link active" if finding else "nav-link",
        {} if finding else {"display": "none"}, {"display": "none"} if finding else {},
    )


@app.callback(Output("flavor-dropdown", "options"), Input("preferences", "data"))
def flavor_options(values):
    preferences = normalize_preferences(values)
    _, qualified = select_wines(data, preferences)
    counts = get_flavors().counts(qualified.index.to_numpy())
    options = [{"label": f"{row.term.title()} ({int(row.reviews):,})", "value": row.term} for row in counts.itertuples()]
    available = set(counts.term)
    options += [{"label": f"{term.title()} (0)", "value": term} for term in preferences["flavors"] if term not in available]
    return options


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8051")), debug=False, use_reloader=False)