import io
import unittest

import pandas as pd

from app import CONTROL_IDS, app, flavor_options, update_summary
from src.analytics import ALL, DEFAULTS, SORT, get_data, normalize_preferences


class ApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = app.server.test_client()
        cls.client.get("/")

    def post_callback(self, key_contains, inputs, states=None, changed=None):
        key = next(key for key in app.callback_map if key_contains in key)
        output = app.callback_map[key]["output"]
        outputs = [{"id": item.component_id, "property": item.component_property} for item in output] if isinstance(output, list) else {"id": output.component_id, "property": output.component_property}
        response = self.client.post("/_dash-update-component", json={"output": key, "outputs": outputs, "inputs": inputs, "state": states or [], "changedPropIds": changed or []})
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True)[:500])
        return response.get_json()["response"]

    def test_routes_and_registered_pages(self):
        import dash
        self.assertEqual({page["path"] for page in dash.page_registry.values()}, {"/", "/find"})
        self.assertNotIn("selected-review", self.client.get("/_dash-layout").get_data(as_text=True))
        for route in ["/", "/find", "/_dash-layout", "/_dash-dependencies", "/assets/wine.jpg"]:
            with self.client.get(route) as response:
                self.assertEqual(response.status_code, 200)

    def test_page_specific_metrics_and_independent_preferences(self):
        selected = normalize_preferences({"country": "Portugal", "flavors": ["cherry"]})
        explore = update_summary(selected, "/")
        finding = update_summary(selected, "/find")
        self.assertGreater(int(explore[0].replace(",", "")), int(finding[0].replace(",", "")))
        self.assertEqual(update_summary({}, "/")[0], "14,516")
        self.assertEqual(DEFAULTS["country"], ALL)
        self.assertEqual(DEFAULTS["flavors"], [])

    def test_explore_callback_and_context(self):
        result = self.post_callback("country-map.figure", [{"id": "preferences", "property": "data", "value": {"country": "Portugal"}}, {"id": "explore-ready", "property": "data", "value": True}], changed=["explore-ready.data"])
        self.assertGreater(len(result["country-map"]["figure"]["data"]), 0)
        self.assertIn("Portugal", result["category-caption"]["children"])
        self.assertIn("eligible countries", result["map-coverage"]["children"])

    def test_table_filter_pagination_sort_and_flavors(self):
        preferences = normalize_preferences({"budget": 25, "country": "Portugal", "flavors": ["cherry", "plum", "blackberry"]})
        inputs = [{"id": "preferences", "property": "data", "value": preferences}, {"id": "wine-table", "property": "page_current", "value": 100}, {"id": "wine-table", "property": "sort_by", "value": [{"column_id": "price", "direction": "asc"}]}]
        result = self.post_callback("price-chart.figure", inputs, changed=["preferences.data"])
        table = result["wine-table"]
        self.assertEqual(table["page_current"], 0)
        self.assertTrue(all(row["country_display"] == "Portugal" for row in table["data"]))
        prices = [row["price"] for row in table["data"]]
        self.assertEqual(prices, sorted(prices))
        self.assertIn("Before flavor filtering", result["flavor-caption"]["children"])
        inputs[1]["value"] = 1
        result = self.post_callback("price-chart.figure", inputs, changed=["wine-table.page_current"])
        self.assertEqual(result["wine-table"]["page_current"], 1)

    def test_session_restore_map_selection_and_reset(self):
        stored = normalize_preferences({"budget": 25, "country": "Portugal"})
        inputs = [{"id": "preferences", "property": "modified_timestamp", "value": 1}]
        inputs += [{"id": name, "property": "value", "value": value} for name, value in zip(CONTROL_IDS, [30, 90, ALL, ALL, ALL, 30, []])]
        inputs += [{"id": "reset-filters", "property": "n_clicks", "value": 0}, {"id": "reset-country", "property": "n_clicks", "value": 0}]
        inputs += [{"id": name, "property": "clickData", "value": None} for name in ["country-map", "country-chart", "category-chart", "flavor-chart"]]
        states = [{"id": "preferences", "property": "data", "value": stored}]
        result = self.post_callback("preferences.data", inputs, states, ["preferences.modified_timestamp"])
        self.assertEqual(result["budget-input"]["value"], 25)
        self.assertEqual(result["country-dropdown"]["value"], "Portugal")
        inputs[-4]["value"] = {"points": [{"customdata": ["France", 10, 100, 10]}]}
        result = self.post_callback("preferences.data", inputs, states, ["country-map.clickData"])
        self.assertEqual(result["preferences"]["data"]["country"], "France")
        result = self.post_callback("preferences.data", inputs, states, ["reset-filters.n_clicks"])
        self.assertEqual(result["preferences"]["data"], DEFAULTS)

    def test_review_id_selection_clears_when_filtered(self):
        selected_id = int(get_data().loc[get_data().points.eq(96) & get_data().price.eq(20)].iloc[0].id)
        inputs = [{"id": "preferences", "property": "data", "value": DEFAULTS}, {"id": "wine-table", "property": "active_cell", "value": {"row": 0, "column": 0, "column_id": "title", "row_id": selected_id}}, {"id": "wine-table", "property": "data", "value": []}]
        result = self.post_callback("review-detail.children", inputs, [{"id": "selected-review", "property": "data", "value": None}], ["wine-table.active_cell"])
        self.assertEqual(result["selected-review"]["data"], selected_id)
        inputs[0]["value"] = {"country": "France"}
        result = self.post_callback("review-detail.children", inputs, [{"id": "selected-review", "property": "data", "value": selected_id}], ["preferences.data"])
        self.assertIsNone(result["selected-review"]["data"])

    def test_csv_export_and_empty_results(self):
        preferences = {"country": "Portugal", "flavors": ["cherry"]}
        result = self.post_callback("shortlist-download.data", [{"id": "export-button", "property": "n_clicks", "value": 1}], [{"id": "preferences", "property": "data", "value": preferences}], ["export-button.n_clicks"])
        exported = pd.read_csv(io.StringIO(result["shortlist-download"]["data"]["content"]))
        self.assertTrue(exported.country.eq("Portugal").all())
        self.assertTrue(exported.description.str.contains(r"\bcherry\b", case=False, regex=True).all())
        inputs = [{"id": "preferences", "property": "data", "value": {"budget": 4, "rating": 100}}, {"id": "wine-table", "property": "page_current", "value": 10}, {"id": "wine-table", "property": "sort_by", "value": SORT}]
        result = self.post_callback("price-chart.figure", inputs, changed=["preferences.data"])
        self.assertEqual(result["wine-table"]["data"], [])
        self.assertTrue(result["export-button"]["disabled"])
        self.assertEqual(update_summary({"budget": 4, "rating": 100}, "/find")[0], "0")

    def test_selected_missing_flavor_stays_clearable(self):
        options = flavor_options({"budget": 4, "rating": 100, "flavors": ["cherry"]})
        self.assertIn({"label": "Cherry (0)", "value": "cherry"}, options)


if __name__ == "__main__":
    unittest.main()